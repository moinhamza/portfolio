PROJECT SCREENSHOTS AND CLIPS (Motion Edition)
Drop files here named after the project and they appear automatically on the project cards and the case-study pages:

  shots/dino-bot.webp           (or .jpg / .png)   a picture
  shots/dino-bot.mp4            (or .webm)         a short looping clip, muted, plays only while on screen (keep it under ~2 MB)

Slugs: dino-bot, loyal-bot, ai-chat, ai-tools, discord-automation, portfolio
If both a clip and a picture exist, the clip wins. Recommended size: 1280x720 (16:9), WebP at quality ~80.
Nothing else to edit. Remove a file and the card goes back to the coloured art.
