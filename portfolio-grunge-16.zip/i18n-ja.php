<?php
/* i18n-ja.php — Japanese text for the long copy. lib.php swaps these exact English strings (as written in
   index.php / lib.php) for the Japanese ones when ?lang=ja. Add a line here to translate more:
   'exact English text' => '日本語のテキスト'.  Missing lines simply stay English. */
return [
  'It started on <strong>Discord</strong>. Hours spent in communities, managing servers, discovering how bots worked &mdash; that curiosity became everything.'
    => 'まずは<strong>Discord</strong>から始まりました。コミュニティで過ごした膨大な時間、サーバーの運営、ボットの仕組みを探る日々 &mdash; その好奇心がすべてになりました。',
  'What began as a fascination with bots turned into real programming. I started with <strong>Python</strong>, then moved into <strong>HTML, CSS, JavaScript, and PHP</strong> &mdash; building websites, automation scripts, AI integrations, and Discord bots.'
    => 'ボットへの興味は、やがて本格的なプログラミングへと変わりました。<strong>Python</strong>から始め、<strong>HTML、CSS、JavaScript、PHP</strong>へと広げ &mdash; Webサイト、自動化スクリプト、AI連携、Discordボットを作ってきました。',
  'I built my first <strong>live website</strong> for my own Discord bot, integrated <strong>Groq and Gemini AI APIs</strong>, and shipped real projects that real people use.'
    => '自分のDiscordボットのために初めての<strong>公開Webサイト</strong>を作り、<strong>GroqとGemini AI API</strong>を組み込み、実際に使われるプロジェクトをリリースしました。',
  'Today I focus on <strong>AI, machine learning, web development</strong>, and building things that actually work.'
    => '現在は<strong>AI、機械学習、Web開発</strong>に力を入れ、本当に動くものづくりに取り組んでいます。',
  "I didn't start with a roadmap. I started with Discord, curiosity, and a lot of questions. The code came later &mdash; and it never stopped."
    => 'ロードマップがあったわけではありません。あったのはDiscordと好奇心、そしてたくさんの疑問だけ。コードは後からついてきて &mdash; そして今も止まりません。',
  'Student &mdash; 19 years old<br>Developer from the Discord community'
    => '学生 &mdash; 19歳<br>Discordコミュニティ出身の開発者',
  '<p>Developer from the Discord community</p>'
    => '<p>Discordコミュニティ出身の開発者</p>',
  '<span>Years Coding</span>'
    => '<span>コーディング歴（年）</span>',
  '<span>Primary language</span>'
    => '<span>メイン言語</span>',
  '<span>Frontend logic</span>'
    => '<span>フロントエンドのロジック</span>',
  '<span>Models &amp; APIs</span>'
    => '<span>モデル &amp; API</span>',
  'Full-featured bots with moderation, economy, leveling, AI chat, and custom systems. Built in Python using discord.py.'
    => 'モデレーション、経済、レベリング、AIチャット、カスタムシステムを備えた多機能ボット。discord.pyを使ってPythonで構築。',
  'Responsive dark-themed web apps and portfolios built from scratch using PHP, HTML, CSS, and vanilla JavaScript.'
    => 'PHP、HTML、CSS、素のJavaScriptでゼロから作る、レスポンシブなダークテーマのWebアプリとポートフォリオ。',
  'Connecting Groq, Gemini, and other LLM APIs into web apps and bots for conversational AI and automation.'
    => 'Groq、Gemini、その他のLLM APIをWebアプリやボットに組み込み、対話型AIと自動化を実現。',
  'Python scripts for automating tasks &mdash; monitoring, notifications, file management, and webhook integrations.'
    => '監視、通知、ファイル管理、Webhook連携など、作業を自動化するPythonスクリプト。',
  'Secure PHP/Python backends with validation, authentication, session management, and clean REST endpoints.'
    => '入力検証、認証、セッション管理、クリーンなRESTエンドポイントを備えた安全なPHP/Pythonバックエンド。',
  'Browser-based tools using AI APIs for practical tasks &mdash; chatbots, text tools, and creative experiments.'
    => 'チャットボット、テキストツール、クリエイティブな実験など、AI APIを使った実用的なブラウザツール。',
  'Full-featured Discord bot with moderation, utility, AI chat, image tools, and server management. Built in Python. Has a live website at <strong>dino-bot.gt.tc</strong> &mdash; designed and built by me.'
    => 'モデレーション、ユーティリティ、AIチャット、画像ツール、サーバー管理を備えた多機能Discordボット。Pythonで構築。<strong>dino-bot.gt.tc</strong>に公開サイトがあり &mdash; 私が設計・制作しました。',
  'Feature-rich multi-cog Discord bot with moderation, economy, leveling, music, and AI-powered chat.'
    => 'モデレーション、経済、レベリング、音楽、AIチャットを備えた高機能なマルチCog Discordボット。',
  'Personal portfolio built from scratch. Grunge brutalist theme, CSS-first with a small script for motion and the live clock.'
    => 'ゼロから作った個人ポートフォリオ。グランジ・ブルータリズムのテーマで、CSSを軸に、動きとライブ時計のための小さなスクリプトを添えて構築。',
  'ChatGPT-style interface powered by Groq LLMs. Multi-model, history, markdown rendering.'
    => 'Groq LLMで動くChatGPT風インターフェース。マルチモデル、履歴、Markdown表示に対応。',
  'Collection of browser-based AI tools and experiments using LLM and vision APIs.'
    => 'LLMやビジョンAPIを使った、ブラウザベースのAIツールと実験のコレクション。',
  'Python scripts for Discord automation &mdash; monitoring, scheduled notifications, and webhook pipelines.'
    => '監視、スケジュール通知、Webhookパイプラインなど、Discord自動化のPythonスクリプト。',
  '<div class="step">Origin</div>'
    => '<div class="step">起源</div>',
  '<div class="step">Spark</div>'
    => '<div class="step">火種</div>',
  '<div class="step">First Steps</div>'
    => '<div class="step">はじめの一歩</div>',
  '<div class="step">Now</div>'
    => '<div class="step">現在</div>',
  '<h3>Curiosity Ignites</h3>'
    => '<h3>好奇心に火がつく</h3>',
  'Hours in servers, discovering communities and how digital spaces work.'
    => 'サーバーで過ごした時間の中で、コミュニティやデジタル空間の仕組みを知っていった。',
  'Questions about bots triggered a genuine drive to understand code.'
    => 'ボットへの疑問が、コードを理解したいという本物の意欲に火をつけた。',
  'First scripts in Python. Breaking things, fixing them, learning by doing.'
    => 'Pythonで最初のスクリプトを書いた。壊して、直して、やりながら学ぶ。',
  'Chose Python as home. Automation, APIs, bots &mdash; built it all here.'
    => 'Pythonを拠点に選んだ。自動化、API、ボット &mdash; すべてここで作った。',
  'Moved into the web. Structure, style, backend logic, and databases.'
    => 'Webの世界へ。構造、スタイル、バックエンドのロジック、そしてデータベース。',
  'Shipped Dino Bot &amp; Loyal Bot with live websites people actually use.'
    => 'Dino BotとLoyal Botを、実際に使われる公開サイト付きでリリース。',
  'Integrated LLMs into real tools. Not demos &mdash; shipped applications.'
    => 'LLMを実際のツールに統合。デモではなく &mdash; 本番のアプリケーション。',
  'Building larger, more complex systems across AI, web, and automation.'
    => 'AI、Web、自動化にまたがる、より大きく複雑なシステムを構築中。',
  '<span class="badge b-learning">Learning</span>'
    => '<span class="badge b-learning">学習中</span>',
  '<span class="badge b-exploring">Exploring</span>'
    => '<span class="badge b-exploring">探求中</span>',
  '<span class="badge b-building">Building</span>'
    => '<span class="badge b-building">開発中</span>',
  'Advanced algorithms, design patterns, and complex applications.'
    => '高度なアルゴリズム、デザインパターン、複雑なアプリケーション。',
  'Data analysis, pandas, numpy, and visualization techniques.'
    => 'データ分析、pandas、numpy、可視化の手法。',
  'Neural networks, model training, and practical ML application.'
    => 'ニューラルネットワーク、モデルの学習、機械学習の実践的な応用。',
  'Integrating large language models into real tools and bots.'
    => '大規模言語モデルを実際のツールやボットに組み込む。',
  'Complex full-stack projects and modern frontend patterns.'
    => '複雑なフルスタックのプロジェクトと、モダンなフロントエンドのパターン。',
  'Data pipelines, system connections, and workflow automation.'
    => 'データパイプライン、システム連携、ワークフローの自動化。',
  'Studying and building at the same time. Every project extends what I learn.'
    => '勉強と開発を同時に。プロジェクトのたびに、学べる範囲が広がっていく。',
  'Maintaining Dino Bot &amp; Loyal Bot. Adding features, fixing bugs, shipping updates.'
    => 'Dino BotとLoyal Botを運用中。機能の追加、バグ修正、アップデートのリリースを続けています。',
  'This site is a live project, constantly improved as I grow as a developer.'
    => 'このサイトは進行中のプロジェクトで、開発者としての成長に合わせて常に改良しています。',
  'ML fundamentals, neural networks, and connecting models to real projects.'
    => '機械学習の基礎、ニューラルネットワーク、そしてモデルを実際のプロジェクトにつなぐこと。',
  'Using Groq and Gemini APIs in real applications &mdash; not experiments.'
    => 'GroqとGemini APIを実際のアプリケーションで活用 &mdash; 実験ではなく本番で。',
  'Automation scripts, bot logic, API wrappers &mdash; Python is home.'
    => '自動化スクリプト、ボットのロジック、APIラッパー &mdash; Pythonが拠点です。',
  "<strong>No fake credentials.</strong> I'm a 19-year-old student who started coding out of curiosity on Discord. I don't have corporate experience &mdash; I have real projects, genuine learning, and a drive to build things that work. Every line on this site was written by me."
    => '<strong>偽りの肩書きはありません。</strong>私は19歳の学生で、Discordで好奇心からコーディングを始めました。企業での経験はありません &mdash; あるのは、本物のプロジェクトと、本当の学びと、動くものを作りたいという思いです。このサイトのコードはすべて自分で書きました。',
  "Don't just use technology.<br>Build with it."
    => 'テクノロジーを使うだけじゃない。<br>それで、作ろう。',
  'Full-featured Discord bot with moderation, utility, AI chat, image tools, and server management. Built in Python, with a live website designed and built by me.'
    => 'モデレーション、ユーティリティ、AIチャット、画像ツール、サーバー管理を備えた多機能Discordボット。Pythonで構築し、公開サイトも私が設計・制作しました。',
  'Moderation and server management'
    => 'モデレーションとサーバー管理',
  'Utility commands and image tools'
    => 'ユーティリティコマンドと画像ツール',
  'AI chat powered by Groq and Gemini'
    => 'GroqとGeminiによるAIチャット',
  'Live PHP website at dino-bot.gt.tc'
    => 'dino-bot.gt.tcの公開PHPサイト',
  'Economy and leveling systems'
    => '経済システムとレベリングシステム',
  'Personal portfolio built from scratch. Grunge brutalist theme, CSS-first with a small script for motion and the live clock.'
    => 'ゼロから作った個人ポートフォリオ。グランジ・ブルータリズムのテーマで、CSSを軸に、動きとライブ時計のための小さなスクリプトを添えて構築。',
  'CSS-first design: page transitions, multi-theme switcher, project filter and a full no-script fallback'
    => 'CSSを軸にしたデザイン：ページ遷移、マルチテーマ切り替え、プロジェクトフィルター、スクリプトなしでも動くフォールバック',
  'Scroll-driven motion: split-text reveals, pinned horizontal timeline, parallax, velocity-reactive marquee and tilt cards'
    => 'スクロール連動のモーション：分割テキストの出現、固定された横スクロール年表、パララックス、速度に反応するマーキー、チルトカード',
  'Live digital clock with day and date, 12/24-hour toggle and a day-progress bar'
    => '曜日と日付つきのライブデジタル時計、12／24時間切り替え、1日の進行バー',
  'PHP contact form with honeypot, signed timestamp and rate limiting'
    => 'ハニーポット、署名付きタイムスタンプ、レート制限を備えたPHPお問い合わせフォーム',
  'English / Japanese language switch via cookie'
    => 'Cookieによる英語／日本語の言語切り替え',
  'One PHP page per project, with the content kept in a single data file'
    => 'プロジェクトごとに1つのPHPページ、内容は1つのデータファイルで管理',
  'Designed around free-hosting limits: few requests, no cron jobs, no outside calls that can hang the page'
    => '無料ホスティングの制限に合わせた設計：リクエスト数は少なく、cronジョブなし、ページを固まらせる外部呼び出しなし',
  'Multiple Groq models to choose from'
    => '選べる複数のGroqモデル',
  'Markdown rendering of replies'
    => '返信のMarkdown表示',
  'LLM and vision API experiments'
    => 'LLMとビジョンAPIの実験',
  'Python scripts for Discord automation — monitoring, scheduled notifications, and webhook pipelines.'
    => 'Discord自動化のPythonスクリプト — 監視、スケジュール通知、Webhookパイプライン。',
  'Scheduled notifications'
    => 'スケジュール通知',
  '<h3>Discord Bots</h3>'
    => '<h3>Discordボット</h3>',
  '<h3>Web Applications</h3>'
    => '<h3>Webアプリケーション</h3>',
  '<h3>AI Integrations</h3>'
    => '<h3>AI連携</h3>',
  '<h3>Automation Scripts</h3>'
    => '<h3>自動化スクリプト</h3>',
  '<h3>Backend Development</h3>'
    => '<h3>バックエンド開発</h3>',
  '<h3>AI-Powered Tools</h3>'
    => '<h3>AI搭載ツール</h3>',
  '<h3>Discord Communities</h3>'
    => '<h3>Discordコミュニティ</h3>',
  '<h3>Coding Experiments</h3>'
    => '<h3>コーディングの実験</h3>',
  '<h3>HTML, CSS &amp; PHP</h3>'
    => '<h3>HTML、CSS &amp; PHP</h3>',
  '<h3>Discord Bot Development</h3>'
    => '<h3>Discordボット開発</h3>',
  '<h3>Groq &amp; Gemini APIs</h3>'
    => '<h3>Groq &amp; Gemini API</h3>',
  '<h3>Bigger Projects</h3>'
    => '<h3>より大きなプロジェクト</h3>',
  '<div class="step">Language</div>'
    => '<div class="step">言語</div>',
  '<div class="step">Bots</div>'
    => '<div class="step">ボット</div>',
  '<h3>Data Science</h3>'
    => '<h3>データサイエンス</h3>',
  '<h3>Machine Learning</h3>'
    => '<h3>機械学習</h3>',
  '<h3>AI &amp; LLMs</h3>'
    => '<h3>AI &amp; LLM</h3>',
  '<h3>Advanced Web Dev</h3>'
    => '<h3>高度なWeb開発</h3>',
  '<h3>APIs &amp; Automation</h3>'
    => '<h3>API &amp; 自動化</h3>',
  '<h3>Student</h3>'
    => '<h3>学生</h3>',
  '<h3>Active Discord Dev</h3>'
    => '<h3>Discord開発を継続中</h3>',
  '<h3>Building This Portfolio</h3>'
    => '<h3>このポートフォリオを構築中</h3>',
  '<h3>Learning AI &amp; ML</h3>'
    => '<h3>AI &amp; 機械学習を学習中</h3>',
  '<h3>Integrating LLMs</h3>'
    => '<h3>LLMの統合</h3>',
  '<h3>Writing Python Daily</h3>'
    => '<h3>毎日Pythonを書く</h3>',
  '<span>Structure</span>'
    => '<span>構造</span>',
  '<span>Styling</span>'
    => '<span>スタイリング</span>',
  '<span>Backend</span>'
    => '<span>バックエンド</span>',
  '<span>Bots</span>'
    => '<span>ボット</span>',
  '<span>Integrations</span>'
    => '<span>連携</span>',
  '<span>Scripts</span>'
    => '<span>スクリプト</span>',
  '<span>Full-stack</span>'
    => '<span>フルスタック</span>',
  '<span>Languages</span>'
    => '<span>言語</span>',
  '<span>Projects</span>'
    => '<span>プロジェクト</span>',
  '<span>Curiosity</span>'
    => '<span>好奇心</span>',
  '<li><b>Status</b> Student, 19</li>'
    => '<li><b>ステータス</b> 学生、19歳</li>',
  'Moderation tools'
    => 'モデレーションツール',
  'Music playback'
    => '音楽再生',
  'Multi-cog structure'
    => 'マルチCog構成',
  'Conversation history'
    => '会話履歴',
  'Monitoring'
    => '監視',
  'Webhook pipelines'
    => 'Webhookパイプライン',
  'Portfolio: project pages, light/dark toggle, EN/Japanese switch, bot stats, CV download'
    => 'ポートフォリオ：プロジェクトページ、テーマ切り替え、英語／日本語スイッチ、ボット統計、CVダウンロード',
  'Portfolio: CSS-only scroll animations and page transitions, no-JS contact form'
    => 'ポートフォリオ：CSSのみのスクロールアニメーションとページ遷移、JavaScript不要のお問い合わせフォーム',
  'Portfolio: Japanese translation and multi-theme switcher'
    => 'ポートフォリオ：日本語翻訳とマルチテーマ切り替えを追加',
  'Portfolio: mobile menu button, progress bar, swipe between projects, install-as-app, text size and calm mode'
    => 'ポートフォリオ：モバイル用メニューボタン、進捗バー、プロジェクト間スワイプ、アプリとして追加、文字サイズとカームモード',
  'Command palette, keyboard shortcuts and a reading-progress bar on desktop'
    => 'コマンドパレット、キーボードショートカット、読み進めバー（デスクトップ）',
  'Mobile menu button, swipe between projects, install-as-app, text size and calm mode on phones'
    => 'メニューボタン、プロジェクト間スワイプ、アプリとして追加、文字サイズ、カームモード（スマホ）',
  'Portfolio: live digital clock, advanced scroll-motion engine, navigation fixes'
    => 'ポートフォリオ：ライブデジタル時計、高度なスクロールモーション、ナビゲーションの修正',
];
