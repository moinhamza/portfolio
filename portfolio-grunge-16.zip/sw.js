/* sw.js: offline support for the whole site. Registered only on https (or localhost).
   Pages: network first, last good copy when offline. Static files: instant from cache, refreshed in the background.
   Never touches other sites (fonts etc.), form posts, or the contact endpoint. Bump V to clear old copies. */
const V = 'hamza-v20';
const SHELL = ['offline.html', 'style.css?v=18', 'motion.css?v=20', 'dino-logo.webp', 'dino-logo.jpg', 'icon-192.png'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(V).then(function (c) {
    return Promise.all(SHELL.map(function (u) { return c.add(u).catch(function () {}); }));
  }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) {
    return Promise.all(ks.filter(function (k) { return k !== V; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});

self.addEventListener('fetch', function (e) {
  var r = e.request;
  if (r.method !== 'GET') return;
  var u = new URL(r.url);
  if (u.origin !== location.origin) return;
  if (/motion-contact\.php|stats\.json|stats-cache\.json/.test(u.pathname)) return;

  if (r.mode === 'navigate') {
    e.respondWith(
      fetch(r).then(function (res) {
        if (res && res.ok) { var cp = res.clone(); caches.open(V).then(function (c) { c.put(r, cp); }); }
        return res;
      }).catch(function () {
        return caches.match(r).then(function (m) { return m || caches.match('offline.html'); });
      })
    );
    return;
  }

  e.respondWith(caches.match(r).then(function (hit) {
    var net = fetch(r).then(function (res) {
      if (res && res.ok && res.type === 'basic') { var cp = res.clone(); caches.open(V).then(function (c) { c.put(r, cp); }); }
      return res;
    }).catch(function () { return hit; });
    return hit || net;
  }));
});
