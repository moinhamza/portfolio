<?php
/* motion-lib.php: shared setup for motion.php, motion-project.php and motion-contact.php. Outputs nothing. */
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/contact-config.php';

$MI = require __DIR__ . '/motion-i18n.php';
foreach ($MI as $lg => $arr) { $I18N[$lg] = array_merge($I18N[$lg] ?? [], $arr); }

if (!function_exists('e')) {
    function e($v) { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }
}
/* translated text as plain text (for JS strings and attributes) */
function m_plain($k) { return html_entity_decode(strip_tags(t($k)), ENT_QUOTES, 'UTF-8'); }

/* optional project media: drop shots/<slug>.webp|jpg|png (picture) or shots/<slug>.webm|mp4 (looping clip) next to the site.
   Returns [type, path] or null. */
function m_media($slug) {
    foreach (['webm', 'mp4'] as $x) { if (is_file(__DIR__ . "/shots/$slug.$x")) return ['video', "shots/$slug.$x"]; }
    foreach (['webp', 'jpg', 'jpeg', 'png'] as $x) { if (is_file(__DIR__ . "/shots/$slug.$x")) return ['img', "shots/$slug.$x"]; }
    return null;
}
function m_media_html($slug, $alt = '') {
    $m = m_media($slug);
    if (!$m) return '';
    if ($m[0] === 'video') {
        return '<video class="shot" src="' . e($m[1]) . '" muted loop playsinline preload="none" data-autoplay aria-label="' . e($alt) . '"></video>';
    }
    return '<img class="shot" src="' . e($m[1]) . '" alt="' . e($alt) . '" loading="lazy" decoding="async">';
}

/* strings the browser needs (toasts, demo chat, tabs), as one JSON object */
function m_js_strings() {
    global $I18N, $L;
    $out = [];
    foreach (($I18N[$L] ?? []) + $I18N['en'] as $k => $v) {
        if (strpos($k, 'm.j_') === 0) $out[substr($k, 4)] = html_entity_decode(strip_tags($v), ENT_QUOTES, 'UTF-8');
    }
    foreach (['tab0t', 'tab0p', 'tab1t', 'tab1p', 'tab2t', 'tab2p', 'tab3t', 'tab3p', 'pv_open', 'pv_close', 'ct_ok', 'ct_sending', 'ct_fail'] as $k) { $out[$k] = m_plain('m.' . $k); }
    return json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP);
}

/* the three icons used all over */
const M_ARROW = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';

/* page chrome shared by both Motion pages: $base is '' on motion.php and 'motion.php' for anchors on other pages */
function m_chrome_top($base = '') {
    global $L;
    $other = $L === 'ja' ? 'EN' : '日本語';
    ?>
<a class="skip" href="#main"><?= t('skip') ?></a>
<div class="veil" aria-hidden="true"></div>
<div class="prog" aria-hidden="true"><i></i></div>
<div class="cur" aria-hidden="true"><span></span></div>

<header class="bar">
  <a class="logo" href="motion.php" aria-label="Hamza"><picture><source srcset="dino-logo-192.webp" type="image/webp"><img src="dino-logo.jpg" alt="" width="40" height="40"></picture><span>Hamza</span></a>
  <nav aria-label="Primary">
    <a class="l" href="<?= $base ?>#work"><?= t('m.work') ?></a>
    <a class="l" href="<?= $base ?>#story"><?= t('m.story') ?></a>
    <a class="l" href="<?= $base ?>#capabilities"><?= t('m.cap') ?></a>
    <a class="l" href="<?= $base ?>#contact"><?= t('m.contact') ?></a>
    <a class="pill" href="index.php?e=c" data-leave aria-label="<?= e(m_plain('m.classic') . ' ' . m_plain('m.site')) ?>">&#8617;<span class="sxx"> <?= t('m.classic') ?></span><span class="sx"> <?= t('m.site') ?></span></a>
    <a class="pill lang" href="<?= lang_url() ?>" lang="<?= $L === 'ja' ? 'en' : 'ja' ?>"><?= e($other) ?></a>
    <button class="snd-btn" type="button" aria-pressed="false" aria-label="<?= e(m_plain('m.snd')) ?>" title="<?= e(m_plain('m.snd')) ?>"><i></i><i></i><i></i></button>
    <button class="acc-btn" type="button" aria-label="<?= e(m_plain('m.acc')) ?>" title="<?= e(m_plain('m.acc')) ?>"><i></i></button>
    <button class="burger" type="button" aria-expanded="false" aria-controls="menu" aria-label="<?= e(m_plain('m.j_menu_open')) ?>"><i></i><i></i></button>
  </nav>
</header>

<div class="menu" id="menu" role="dialog" aria-modal="true" aria-label="<?= e(m_plain('m.menu')) ?>">
  <a class="m" href="<?= $base ?>#work" style="--i:0"><span>01</span><?= t('m.work') ?></a>
  <a class="m" href="<?= $base ?>#story" style="--i:1"><span>02</span><?= t('m.story') ?></a>
  <a class="m" href="<?= $base ?>#capabilities" style="--i:2"><span>03</span><?= t('m.cap') ?></a>
  <a class="m" href="<?= $base ?>#contact" style="--i:3"><span>04</span><?= t('m.contact') ?></a>
  <a class="m" href="index.php?e=c" data-leave style="--i:4"><span>&#8617;</span><?= t('m.classic') ?> <?= t('m.site') ?></a>
  <div class="mf"><a class="ul" href="https://github.com/moinhamza" target="_blank" rel="noopener">GitHub</a><a class="ul" href="https://www.instagram.com/epichamzax" target="_blank" rel="noopener">Instagram</a><button class="ul cv-open" type="button"><?= t('m.ct_cv') ?></button></div>
</div>
<?php
}

/* bottom of both pages: toast, CV panel, scripts */
function m_chrome_bottom() {
    ?>
<aside class="cvp" id="cvp" hidden aria-label="<?= e(m_plain('m.cv_t')) ?>">
  <div class="cvp-box" role="dialog" aria-modal="true" aria-label="<?= e(m_plain('m.cv_t')) ?>" tabindex="-1">
    <div class="cvp-top"><b><?= t('m.cv_t') ?></b><span><a class="btn mag" href="cv.pdf" download><?= t('m.ct_dl') ?></a><button class="cvp-x" type="button" aria-label="<?= e(m_plain('m.pv_close')) ?>">&times;</button></span></div>
    <object class="cvp-obj" type="application/pdf" data-src="cv.pdf#toolbar=0&amp;navpanes=0"><p><?= t('m.cv_fb') ?></p></object>
  </div>
</aside>
<div class="toast" role="status" aria-live="polite"></div>
<script>window.MI18N = <?= m_js_strings() ?>;</script>
<script src="motion.js?v=20" defer></script>
<?php
}
