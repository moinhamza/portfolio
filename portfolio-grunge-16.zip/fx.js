/* fx.js — progressive enhancement for the portfolio.
   Nothing here is required: the site is fully usable (and still looks good) without it.

   Always on ........ v17: reading-progress bar, mobile menu button + bottom-sheet palette, keyboard shortcuts (J/K, 1-9, T, G, ?), swipe / arrow keys between projects, install-as-app, text size, calm mode, section-link copy, contact helpers, online/offline toasts, haptics;
                       command palette (Ctrl/Cmd+K or /), click-to-copy handles, form draft + counter, clock greeting, Konami chaos, live digital clock (time + day + date), section spy + side rail, hero name auto-fit, theme-color sync
   Motion (html.fx) .. only when the visitor has NOT asked for reduced motion:
                       split-text headline reveals, staggered 3D reveals, count-up numbers, hero scroll-out + parallax,
                       pinned horizontal "journey", velocity-reactive marquee + skew, tilt cards, magnetic buttons,
                       follower cursor, eased anchor scrolling, scrambling section numbers, footer fill

   Rules this file follows: one requestAnimationFrame loop for everything scroll-driven (reads first, then writes);
   custom properties are written only on the few elements that use them (never on <html>); every module is wrapped in
   try/catch so one failure can never take the page down. */
(function () {
  'use strict';

  var D = document, H = D.documentElement, W = window;
  var FX = H.classList.contains('fx');
  var LANG = (H.lang || 'en').slice(0, 2);
  var FINE = false;
  try { FINE = matchMedia('(hover:hover) and (pointer:fine)').matches; } catch (e) {}
  var HAS_IO = 'IntersectionObserver' in W;

  function $(s, c) { return (c || D).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || D).querySelectorAll(s)); }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function safe(fn, name) { try { fn(); } catch (e) { if (W.console) console.warn('[fx] ' + (name || '') + ':', e); } }
  function debounce(fn, ms) { var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }

  /* ------------------------------------------------------------------ engine */
  var E = { y: 0, vel: 0, sgn: 1, req: false };
  var tasks = [];        // {read(y,dy,now) -> data, write(data,y,dy,now) -> true while still animating}
  var resizeCbs = [];    // run (in order) on resize / load / fonts ready

  function kick() { if (!E.req) { E.req = true; requestAnimationFrame(frame); } }

  function frame(now) {
    E.req = false;
    var y = W.pageYOffset || 0, dy = y - E.y;
    E.y = y;
    E.vel = lerp(E.vel, clamp(dy / 36, -1, 1), 0.22);
    if (Math.abs(E.vel) < 0.004) E.vel = 0;
    if (dy) E.sgn = lerp(E.sgn, dy > 0 ? 1 : -1, 0.15);

    var busy = dy !== 0 || E.vel !== 0, i, data = [];
    for (i = 0; i < tasks.length; i++) { if (tasks[i].read) { try { data[i] = tasks[i].read(y, dy, now); } catch (e) {} } }
    for (i = 0; i < tasks.length; i++) { if (tasks[i].write) { try { if (tasks[i].write(data[i], y, dy, now)) busy = true; } catch (e) {} } }
    if (busy) kick();
  }
  addEventListener('scroll', kick, { passive: true });

  var onResize = debounce(function () {
    resizeCbs.forEach(function (f) { safe(f, 'resize'); });
    kick();
  }, 140);
  addEventListener('resize', onResize);
  addEventListener('orientationchange', onResize);
  addEventListener('load', onResize);
  if (D.fonts && D.fonts.ready) { D.fonts.ready.then(onResize); }

  /* ------------------------------------------------------------------- clock */
  function clock() {
    var minis = $$('[data-clock="mini"]'), chips = $$('[data-clock="chip"]'), big = $('[data-clock="big"]');
    if (!minis.length && !chips.length && !big) return;

    var loc = LANG === 'ja' ? 'ja-JP' : 'en-GB';
    var h12 = null;
    try { var st = localStorage.getItem('clock12'); h12 = st === '1' ? true : st === '0' ? false : null; } catch (e) {}
    if (h12 === null) {
      try { h12 = !!new Intl.DateTimeFormat(navigator.language || 'en', { hour: 'numeric' }).resolvedOptions().hour12; } catch (e) { h12 = false; }
    }

    var DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var MONS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    var fDay, fDate, fShort;
    try {
      fDay = new Intl.DateTimeFormat(loc, { weekday: 'long' });
      fDate = new Intl.DateTimeFormat(loc, { day: 'numeric', month: 'long', year: 'numeric' });
      fShort = new Intl.DateTimeFormat(loc, { weekday: 'short', day: 'numeric', month: 'short' });
    } catch (e) {}
    function dayName(n) { return fDay ? fDay.format(n) : DAYS[n.getDay()]; }
    function dateLong(n) { return fDate ? fDate.format(n) : n.getDate() + ' ' + MONS[n.getMonth()] + ' ' + n.getFullYear(); }
    function dateShort(n) { return fShort ? fShort.format(n) : DAYS[n.getDay()].slice(0, 3) + ' ' + n.getDate() + ' ' + MONS[n.getMonth()].slice(0, 3); }

    var tzCity = '';
    try { tzCity = (Intl.DateTimeFormat().resolvedOptions().timeZone || '').split('/').pop().replace(/_/g, ' '); } catch (e) {}

    var digits = {};
    var ampm = null, cdDay = null, cdDate = null, cdTz = null, fill = null, btxt = null, btn = null, tm = null;
    if (big) {
      $$('[data-d]', big).forEach(function (el) { digits[el.getAttribute('data-d')] = el; });
      ampm = $('.ampm', big); cdDay = $('.cd-day', big); cdDate = $('.cd-date', big); cdTz = $('.cd-tz', big);
      fill = $('.cb-fill', big); btxt = $('.cb-text', big); btn = $('.clock-fmt', big); tm = $('time', big);
    }

    var first = true, lastDay = '', lastMin = -1;
    function setText(el, v) { if (el && el.textContent !== v) el.textContent = v; }
    function setDigit(k, v) {
      var el = digits[k];
      if (!el || el.textContent === v) return;
      el.textContent = v;
      if (FX && !first) { el.classList.remove('tick'); void el.offsetWidth; el.classList.add('tick'); }
    }
    function sync() {
      if (!btn) return;
      btn.textContent = h12 ? '12H' : '24H';
      btn.setAttribute('aria-pressed', h12 ? 'true' : 'false');
    }

    function render() {
      var n = new Date(), hh = n.getHours(), mm = n.getMinutes(), ss = n.getSeconds();
      var h = h12 ? (hh % 12 || 12) : hh, ap = hh >= 12 ? 'PM' : 'AM';
      var hs = pad(h), ms = pad(mm), s2 = pad(ss);
      var tstr = hs + ':' + ms + ':' + s2 + (h12 ? ' ' + ap : '');
      var short = dateShort(n);

      minis.forEach(function (m) { setText($('.nc-time', m), tstr); setText($('.nc-date', m), short); });
      chips.forEach(function (c) { setText(c, short + '  ·  ' + tstr); });

      if (big) {
        setDigit('h1', hs.charAt(0)); setDigit('h2', hs.charAt(1));
        setDigit('m1', ms.charAt(0)); setDigit('m2', ms.charAt(1));
        setDigit('s1', s2.charAt(0)); setDigit('s2', s2.charAt(1));
        if (ampm) { ampm.hidden = !h12; setText(ampm, ap); }

        var dayKey = n.getFullYear() + '-' + n.getMonth() + '-' + n.getDate();
        if (dayKey !== lastDay) { lastDay = dayKey; setText(cdDay, dayName(n)); setText(cdDate, dateLong(n)); }

        if (mm !== lastMin) {
          lastMin = mm;
          var off = -n.getTimezoneOffset(), ao = Math.abs(off);
          setText(cdTz, (tzCity ? tzCity + '  ·  ' : '') + 'UTC' + (off >= 0 ? '+' : '-') + pad(Math.floor(ao / 60)) + ':' + pad(ao % 60));
          if (tm) {
            tm.setAttribute('datetime', n.toISOString());
            tm.textContent = dayName(n) + ', ' + dateLong(n) + ', ' + pad(hh) + ':' + pad(mm);
          }
        }

        var sod = new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime();
        var eod = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1).getTime();
        var pct = clamp((n.getTime() - sod) / (eod - sod), 0, 1);
        if (fill) fill.style.width = (pct * 100).toFixed(2) + '%';
        var whole = Math.floor(pct * 100);
        setText(btxt, LANG === 'ja' ? '今日の ' + whole + '% が経過' : whole + '% of the day done');
      }
      if (first) { first = false; H.classList.add('ck'); }
    }

    if (btn) {
      btn.addEventListener('click', function () {
        h12 = !h12;
        try { localStorage.setItem('clock12', h12 ? '1' : '0'); } catch (e) {}
        sync(); render();
      });
    }
    sync();
    render();
    (function loop() { setTimeout(function () { render(); loop(); }, 1000 - (Date.now() % 1000) + 8); })();
    D.addEventListener('visibilitychange', function () { if (!D.hidden) render(); });
    addEventListener('pageshow', render);
  }

  /* ------------------------------------------------------- theme-color meta */
  function themeColor() {
    var m = $('meta[name="theme-color"]');
    if (!m) return;
    function apply() { var c = getComputedStyle(H).getPropertyValue('--ink').trim(); if (c) m.setAttribute('content', c); }
    apply();
    D.addEventListener('change', function (e) { if (e.target && e.target.name === 'theme') setTimeout(apply, 40); });
  }

  /* ------------------------------------------- hero name: never break a word */
  function fitHero() {
    var h1 = $('.hero h1');
    if (!h1) return;
    var pass, spans = $$('span', h1);
    h1.style.removeProperty('--fit');
    for (pass = 0; pass < 2; pass++) {
      var box = h1.clientWidth, need = 0;
      if (!box) return;
      spans.forEach(function (s) {
        var cs = getComputedStyle(s), ml = parseFloat(cs.marginLeft) || 0;
        var pd = s.style.display, pw = s.style.whiteSpace;
        s.style.display = 'inline-block'; s.style.whiteSpace = 'nowrap';
        need = Math.max(need, s.offsetWidth + ml);
        s.style.display = pd; s.style.whiteSpace = pw;
      });
      if (need <= box) break;
      var cur = parseFloat(h1.style.getPropertyValue('--fit')) || 1;
      h1.style.setProperty('--fit', (cur * box / need * 0.985).toFixed(4));
    }
  }

  /* ------------------------------------------------ section spy + side rail */
  function spy() {
    var list = $$('main > section[id]').filter(function (s) { return $('.head .no', s); });
    if (!list.length) return;

    var links = {};
    $$('.nav-links a').forEach(function (a) {
      var h = a.getAttribute('href') || '';
      if (h.charAt(0) === '#') links[h.slice(1)] = a;
    });

    var hud = D.createElement('nav');
    hud.className = 'hud';
    hud.setAttribute('aria-hidden', 'true');
    var anchors = list.map(function (s) {
      var a = D.createElement('a'), i = D.createElement('i'), sp = D.createElement('span');
      var h2 = $('.head h2', s);
      var label = links[s.id] ? links[s.id].textContent.trim() : ((h2 && (h2.getAttribute('aria-label') || h2.textContent)) || s.id).trim().slice(0, 18);
      a.href = '#' + s.id; a.tabIndex = -1;
      sp.textContent = $('.head .no', s).textContent.trim() + '  ' + label;
      a.appendChild(sp); a.appendChild(i); hud.appendChild(a);
      return a;
    });
    D.body.appendChild(hud);

    var tops = [], cur = -2;
    function measure() {
      var y = W.pageYOffset || 0;
      tops = list.map(function (s) { return s.getBoundingClientRect().top + y; });
    }
    measure();
    resizeCbs.push(measure);

    tasks.push({
      write: function (_, y) {
        var line = y + innerHeight * 0.4, idx = -1, i;
        for (i = 0; i < tops.length; i++) { if (tops[i] <= line) idx = i; }
        if (idx === cur) return false;
        cur = idx;
        anchors.forEach(function (a, k) { a.classList.toggle('on', k === idx); });
        Object.keys(links).forEach(function (id) {
          if (idx > -1 && list[idx].id === id) links[id].setAttribute('aria-current', 'true');
          else links[id].removeAttribute('aria-current');
        });
        var nl = $('.nav-links'), cl = idx > -1 ? links[list[idx].id] : null;
        if (nl && cl && nl.scrollWidth > nl.clientWidth + 4) {       // phones: the link row scrolls sideways, so follow the current section
          var want = cl.getBoundingClientRect().left - nl.getBoundingClientRect().left + nl.scrollLeft - (nl.clientWidth - cl.offsetWidth) / 2;
          try { nl.scrollTo({ left: Math.max(0, want), behavior: FX ? 'smooth' : 'auto' }); } catch (e) { nl.scrollLeft = Math.max(0, want); }
        }
        return false;
      }
    });
    H.classList.add('has-hud');
  }

  /* ======================================================== motion modules */

  /* ---------- split text: wrap words so CSS can slide them up through a mask ---------- */
  var SEG = null;
  try { if (W.Intl && Intl.Segmenter && LANG === 'ja') SEG = new Intl.Segmenter('ja', { granularity: 'word' }); } catch (e) {}

  function splitText(el) {
    if (el.__split) return;
    el.__split = true;
    var label = (el.textContent || '').replace(/\s+/g, ' ').trim();
    var idx = 0;
    function word(txt) {
      var w = D.createElement('span'), i = D.createElement('span');
      w.className = 'w'; w.setAttribute('aria-hidden', 'true');
      i.className = 'wi'; i.style.setProperty('--i', idx++); i.textContent = txt;
      w.appendChild(i);
      return w;
    }
    function walk(node) {
      Array.prototype.slice.call(node.childNodes).forEach(function (k) {
        if (k.nodeType === 3) {
          var txt = k.nodeValue;
          if (!txt) return;
          var parts = [], frag = D.createDocumentFragment();
          if (SEG) { var it = SEG.segment(txt); for (var s of it) parts.push(s.segment); }
          else parts = txt.split(/(\s+)/);
          parts.forEach(function (p) {
            if (!p) return;
            if (/^\s+$/.test(p)) frag.appendChild(D.createTextNode(' '));
            else frag.appendChild(word(p));
          });
          node.replaceChild(frag, k);
        } else if (k.nodeType === 1 && k.nodeName !== 'BR') { walk(k); }
      });
    }
    walk(el);
    el.setAttribute('aria-label', label);
    el.classList.add('sp');
  }

  /* ---------- scramble: section numbers decode when they appear ---------- */
  var GLYPHS = '!<>-_/[]{}=+*^?#0123456789';
  function scramble(el) {
    var txt = el.textContent;
    if (!/^[\w .&\-]+$/.test(txt)) return;
    var n = txt.length, f = 0, total = 14;
    (function step() {
      var out = '', i;
      for (i = 0; i < n; i++) out += (i < (f / total) * n || txt.charAt(i) === ' ') ? txt.charAt(i) : GLYPHS.charAt((Math.random() * GLYPHS.length) | 0);
      el.textContent = out;
      if (++f <= total) setTimeout(step, 38); else el.textContent = txt;
    })();
  }

  /* ---------- reveal: tag elements, reveal once when they enter the viewport ---------- */
  function reveal(pinned) {
    var MAP = [
      ['.head .no', 'stamp'], ['.head h2', 'split'], ['.head p', 'up'],
      ['.stats li', 'pop'],
      ['.about-card', 'left'], ['.about-text > p', 'up'], ['.about-text .quote', 'tilt'],
      ['.g-skills > *', 'pop'], ['.g-cards > *', 'flip'], ['.q-grid > *', 'flip'],
      ['.featured', 'up'], ['.pfilter', 'up'],
      ['.ship h2', 'split'], ['.ship li', 'left'],
      ['.honest', 'clip'], ['.chip', 'pop'],
      ['.big-quote blockquote', 'split'], ['.big-quote cite', 'pop'],
      ['.links .btn', 'pop'], ['.form', 'up'], ['.field', 'left'], ['.notice', 'up'],
      ['.foot-logo', 'up'], ['.foot-nav', 'up'],
      ['.pd-back', 'left'], ['.pd-kind', 'left'], ['.pd-title', 'split'], ['.pd-sum', 'up'], ['.pd .btn-row .btn', 'pop'], ['.share', 'up'],
      ['.pd-body h2', 'split'], ['.pd-list li', 'left'], ['.pd-body .tags', 'up'], ['.shots img', 'flip'], ['.pd-next .btn', 'pop']
    ];
    if (!pinned) MAP.push(['.timeline > *', 'up']);

    var io = new IntersectionObserver(onIO, { threshold: 0.12, rootMargin: '0px 0px -7% 0px' });

    function onIO(entries) {
      var n = 0;
      entries.sort(function (a, b) { return (a.target.compareDocumentPosition(b.target) & 2) ? 1 : -1; });
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        var el = en.target;
        io.unobserve(el);
        var d = Math.min(n++, 8) * 0.075;
        el.style.setProperty('--d', d.toFixed(3) + 's');
        el.classList.add('is-in');
        if (el.classList.contains('no')) scramble(el);
        setTimeout(function () {                    // hand the element back to its normal hover/transition rules
          el.removeAttribute('data-fx'); el.classList.remove('is-in'); el.style.removeProperty('--d');
        }, 1900 + d * 1000);
      });
    }

    MAP.forEach(function (m) {
      $$(m[0]).forEach(function (el) {
        if (el.hasAttribute('data-fx') || el.closest('.hero')) return;
        if (m[1] === 'split') splitText(el);
        el.setAttribute('data-fx', m[1]);
        io.observe(el);
      });
    });
  }

  /* ---------- count-up numbers ---------- */
  function counters() {
    var items = $$('.stats b, .mini b, .botstats b').map(function (el) {
      var m = /^(\d[\d,]*)(.*)$/.exec(el.textContent.trim());
      if (!m) return null;
      return { el: el, to: parseInt(m[1].replace(/,/g, ''), 10), suf: m[2], comma: m[1].indexOf(',') > -1 };
    }).filter(Boolean);
    if (!items.length) return;

    function fmt(it, v) { return (it.comma ? v.toLocaleString('en-US') : '' + v) + it.suf; }
    function finish() { items.forEach(function (it) { it.done = true; it.el.textContent = fmt(it, it.to); }); }
    function run(it) {
      var t0 = 0, dur = 1300 + Math.min(1300, it.to * 1.2);
      (function s(now) {
        if (it.done) return;
        if (!t0) t0 = now;
        var k = clamp((now - t0) / dur, 0, 1), e = k === 1 ? 1 : 1 - Math.pow(2, -10 * k);
        it.el.textContent = fmt(it, Math.round(it.to * e));
        if (k < 1) requestAnimationFrame(s); else it.done = true;
      })(performance.now());
    }

    items.forEach(function (it) { it.el.textContent = fmt(it, 0); });
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (en) {
        if (!en.isIntersecting) return;
        io.unobserve(en.target);
        run(en.target.__c);
      });
    }, { threshold: 0.6 });
    items.forEach(function (it) { it.el.__c = it; io.observe(it.el); });
    addEventListener('beforeprint', finish);
  }

  /* ---------- hero: scroll-out progress (--hp), parallax, pointer tilt ---------- */
  function hero() {
    var hs = $('.hero');
    if (!hs) return;
    var col = $('.collage', hs), hh = hs.offsetHeight || 1;
    var mouse = { x: 0, y: 0, tx: 0, ty: 0 }, lastHp = -1;
    resizeCbs.push(function () { hh = hs.offsetHeight || 1; });

    tasks.push({
      write: function (_, y) {
        var hp = clamp(y / (hh * 0.85), 0, 1);
        if (Math.abs(hp - lastHp) > 0.0005) { lastHp = hp; hs.style.setProperty('--hp', hp.toFixed(4)); }
        mouse.x = lerp(mouse.x, mouse.tx, 0.08);
        mouse.y = lerp(mouse.y, mouse.ty, 0.08);
        if (col && y < hh * 1.3) {
          col.style.setProperty('--py', (-y * 0.14).toFixed(1) + 'px');
          col.style.setProperty('--mx', mouse.x.toFixed(3));
          col.style.setProperty('--my', mouse.y.toFixed(3));
        }
        return Math.abs(mouse.x - mouse.tx) > 0.002 || Math.abs(mouse.y - mouse.ty) > 0.002;
      }
    });
    if (FINE) {
      hs.addEventListener('pointermove', function (e) {
        var r = hs.getBoundingClientRect();
        mouse.tx = ((e.clientX - r.left) / r.width - 0.5) * 2;
        mouse.ty = ((e.clientY - r.top) / r.height - 0.5) * 2;
        kick();
      }, { passive: true });
      hs.addEventListener('pointerleave', function () { mouse.tx = 0; mouse.ty = 0; kick(); });
    }
  }

  /* ---------- per-element scroll progress (--sp), footer fill (--fp), velocity skew (--vel) ---------- */
  function scrollVars() {
    var sp = ['.big-quote', '.featured .browser', '.honest'].map(function (s) { return $(s); }).filter(Boolean).map(function (el) { return { el: el, p: -1 }; });
    var foot = $('.footer'), mega = $('.foot-mega'), lastFp = -1;
    var vels = $$('.head h2, .big-quote blockquote, .ship h2, .pd-title').map(function (el) { return { el: el, v: 0 }; });

    tasks.push({
      read: function () {
        return {
          sp: sp.map(function (it) { return it.el.getBoundingClientRect(); }),
          vel: vels.map(function (it) { return it.el.getBoundingClientRect(); }),
          foot: foot ? foot.getBoundingClientRect() : null
        };
      },
      write: function (d) {
        var vh = innerHeight;
        sp.forEach(function (it, i) {
          var r = d.sp[i];
          if (r.bottom < -vh * 0.3 || r.top > vh * 1.3) return;
          var p = clamp((vh - r.top) / (vh + r.height), 0, 1);
          if (Math.abs(p - it.p) > 0.001) { it.p = p; it.el.style.setProperty('--sp', p.toFixed(4)); }
        });
        if (mega && d.foot) {
          var fp = clamp((vh - d.foot.top) / (d.foot.height * 0.95), 0, 1);
          if (Math.abs(fp - lastFp) > 0.001) { lastFp = fp; mega.style.setProperty('--fp', fp.toFixed(4)); }
        }
        vels.forEach(function (it, i) {
          var r = d.vel[i];
          if (r.bottom < -vh * 0.2 || r.top > vh * 1.2) return;
          var v = E.vel;
          if (v === it.v) return;
          it.v = v;
          it.el.style.setProperty('--vel', v.toFixed(3));
        });
        return false;
      }
    });
  }

  /* ---------- marquee: constant drift + speed and direction follow your scrolling ---------- */
  function marquee() {
    var rows = $$('.ticker').map(function (t) {
      var tr = $('.ticker-track', t);
      if (!tr || !tr.firstElementChild) return null;
      return { t: t, tr: tr, half: 1, pos: 0, dir: t.classList.contains('tape') ? 1 : -1, vis: false };
    }).filter(Boolean);
    if (!rows.length) return;
    function measure() { rows.forEach(function (r) { r.half = r.tr.firstElementChild.offsetWidth || 1; }); }
    measure();
    resizeCbs.push(measure);

    var io = new IntersectionObserver(function (es) {
      es.forEach(function (en) { rows.forEach(function (r) { if (r.t === en.target) r.vis = en.isIntersecting; }); });
    });
    rows.forEach(function (r) { io.observe(r.t); });

    var last = 0;
    (function loop(now) {
      var dt = last ? Math.min(now - last, 64) / 1000 : 0;
      last = now;
      var boost = 1 + Math.abs(E.vel) * 9;
      rows.forEach(function (r) {
        if (!r.vis) return;
        r.pos += r.dir * E.sgn * 64 * boost * dt;
        if (r.pos <= -r.half) r.pos += r.half; else if (r.pos > 0) r.pos -= r.half;
        r.tr.style.translate = r.pos.toFixed(1) + 'px 0';
      });
      requestAnimationFrame(loop);
    })(performance.now());
  }

  /* ---------- pinned horizontal journey ---------- */
  function pinned() {
    var sec = $('#journey'), pn = sec && $('.pin', sec);
    if (!pn) return false;
    var stick = $('.pin-stick', pn), track = $('.timeline', pn), cards = $$('.tl-item', track);
    var ui = $('.pin-ui', pn), cnt = ui && $('.pin-count b', ui), bar = ui && $('.pin-bar i', ui);
    var mq = matchMedia('(min-width:56rem) and (min-height:34rem)');
    var on = false, max = 0, offs = [], wrapLeft = 0, vw = 0, total = cards.length, cur = -1, lastP = -1;

    function off() {
      if (!on) return;
      on = false;
      pn.classList.remove('on');
      pn.style.height = ''; stick.style.height = ''; track.style.translate = '';
      cards.forEach(function (c) { c.style.removeProperty('--o'); c.style.removeProperty('--o2'); c.classList.remove('now'); });
    }
    function setup() {
      off();
      if (!mq.matches) return;
      on = true; cur = -1; lastP = -1;
      pn.classList.add('on');
      var nav = $('.nav'), vh = innerHeight, wrap = $('.wrap', stick), cs = getComputedStyle(wrap);
      pn.style.setProperty('--navh', (nav ? nav.offsetHeight : 100) + 'px');
      stick.style.height = vh + 'px';
      var padL = parseFloat(cs.paddingLeft) || 0, padR = parseFloat(cs.paddingRight) || 0;
      var cw = wrap.clientWidth - padL - padR;
      vw = stick.clientWidth;
      max = Math.max(0, track.offsetWidth - cw);
      wrapLeft = wrap.getBoundingClientRect().left + padL;
      offs = cards.map(function (c) { return c.offsetLeft + c.offsetWidth / 2; });
      pn.style.height = Math.round(max + vh * 1.3) + 'px';
      cards.forEach(function (c) { c.removeAttribute('data-fx'); c.classList.remove('is-in'); });
    }
    setup();
    resizeCbs.unshift(setup);
    try { mq.addEventListener('change', function () { setup(); onResize(); }); } catch (e) { try { mq.addListener(setup); } catch (e2) {} }

    tasks.push({
      read: function () { return on ? pn.getBoundingClientRect().top : 0; },
      write: function (top) {
        if (!on) return false;
        var span = Math.max(1, pn.offsetHeight - innerHeight);
        var raw = clamp(-top / span, 0, 1);
        var p = clamp((raw - 0.04) / 0.9, 0, 1);
        var tx = -p * max, mid = vw / 2, best = 0, bd = 1e9, i;
        track.style.translate = tx.toFixed(1) + 'px 0';
        for (i = 0; i < total; i++) {
          var cx = wrapLeft + offs[i] + tx, o = clamp((cx - mid) / mid, -1.2, 1.2), ad = Math.abs(cx - mid);
          cards[i].style.setProperty('--o', o.toFixed(3));
          cards[i].style.setProperty('--o2', (o * o).toFixed(3));
          if (ad < bd) { bd = ad; best = i; }
        }
        if (best !== cur) {
          cards.forEach(function (c, k) { c.classList.toggle('now', k === best); });
          cur = best;
          if (cnt) cnt.textContent = pad(best + 1);
        }
        if (bar && Math.abs(p - lastP) > 0.0005) { lastP = p; bar.style.scale = p.toFixed(4) + ' 1'; }
        return false;
      }
    });
    return mq.matches;
  }

  /* ---------- tilt cards + magnetic buttons (mouse only) ---------- */
  function pointerFx() {
    if (!FINE) return;
    var TILT = '.card, .browser, .about-card, .honest';
    var MAG = '.btn, .nav-cta, .totop, .nav-tool, .clock-fmt, .pfilter label';
    var tCur = null, mCur = null, ev = null, raf = 0;

    function resetTilt(el) { if (!el) return; ['--rx', '--ry', '--gx', '--gy'].forEach(function (p) { el.style.removeProperty(p); }); }
    function resetMag(el) { if (!el) return; el.style.removeProperty('--tx'); el.style.removeProperty('--ty'); }
    function apply() {
      raf = 0;
      if (!tCur || !ev) return;
      var r = tCur.getBoundingClientRect(), x = (ev.clientX - r.left) / r.width, y = (ev.clientY - r.top) / r.height;
      tCur.style.setProperty('--ry', ((x - 0.5) * 10).toFixed(2) + 'deg');
      tCur.style.setProperty('--rx', ((0.5 - y) * 8).toFixed(2) + 'deg');
      tCur.style.setProperty('--gx', (x * 100).toFixed(1) + '%');
      tCur.style.setProperty('--gy', (y * 100).toFixed(1) + '%');
    }
    D.addEventListener('pointermove', function (e) {
      var tg = e.target, c = tg.closest ? tg.closest(TILT) : null, m = tg.closest ? tg.closest(MAG) : null;
      if (c !== tCur) { resetTilt(tCur); tCur = c; }
      if (m !== mCur) { resetMag(mCur); mCur = m; }
      if (c) { ev = e; if (!raf) raf = requestAnimationFrame(apply); }
      if (m) {
        var r = m.getBoundingClientRect();
        m.style.setProperty('--tx', clamp((e.clientX - (r.left + r.width / 2)) * 0.22, -9, 9).toFixed(1) + 'px');
        m.style.setProperty('--ty', clamp((e.clientY - (r.top + r.height / 2)) * 0.28, -7, 7).toFixed(1) + 'px');
      }
    }, { passive: true });
    D.documentElement.addEventListener('mouseleave', function () { resetTilt(tCur); resetMag(mCur); tCur = mCur = null; });
  }

  /* ---------- follower cursor (mouse only) ---------- */
  function cursor() {
    if (!FINE) return;
    var c = D.createElement('div');
    c.className = 'cur'; c.setAttribute('aria-hidden', 'true'); c.innerHTML = '<i></i>';
    D.body.appendChild(c);
    var x = -100, y = -100, cx = x, cy = y, shown = false, raf = 0;
    function loop() {
      cx = lerp(cx, x, 0.22); cy = lerp(cy, y, 0.22);
      c.style.translate = (cx - 17).toFixed(1) + 'px ' + (cy - 17).toFixed(1) + 'px';
      raf = (Math.abs(cx - x) > 0.1 || Math.abs(cy - y) > 0.1) ? requestAnimationFrame(loop) : 0;
    }
    addEventListener('pointermove', function (e) {
      x = e.clientX; y = e.clientY;
      if (!shown) { shown = true; cx = x; cy = y; c.classList.add('show'); }
      if (!raf) raf = requestAnimationFrame(loop);
      var t = e.target;
      c.classList.toggle('on', !!(t.closest && t.closest('a,button,label,select,summary,input,textarea,.card,.btn')));
    }, { passive: true });
    addEventListener('pointerdown', function () { c.classList.add('down'); });
    addEventListener('pointerup', function () { c.classList.remove('down'); });
    D.documentElement.addEventListener('mouseleave', function () { shown = false; c.classList.remove('show'); });
  }

  /* ---------- eased anchor scrolling ---------- */
  function anchors() {
    var anim = 0;
    function stop() { if (anim) { cancelAnimationFrame(anim); anim = 0; } }
    ['wheel', 'touchstart', 'keydown', 'mousedown'].forEach(function (n) { addEventListener(n, stop, { passive: true }); });

    D.addEventListener('click', function (e) {
      if (e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var a = e.target.closest && e.target.closest('a[href^="#"]');
      if (!a) return;
      var id = a.getAttribute('href').slice(1);
      try { id = decodeURIComponent(id); } catch (er) {}
      var t = id && id !== 'home' ? D.getElementById(id) : null;
      if (id && id !== 'home' && !t) return;

      var from = W.pageYOffset || 0, nav = $('.nav'), navH = nav ? nav.offsetHeight : 0, to;
      if (!t) to = 0;
      else {
        to = t.getBoundingClientRect().top + from;
        if (to < from) to -= navH;                     // scrolling up: the nav is about to reappear
      }
      to = Math.max(0, Math.round(to));
      e.preventDefault();
      stop();
      var dist = Math.abs(to - from);
      if (dist < 2) return;
      var dur = clamp(520 + dist * 0.32, 640, 1500), t0 = 0;
      (function step(now) {
        if (!t0) t0 = now;
        var k = clamp((now - t0) / dur, 0, 1);
        var ease = k < 0.5 ? 8 * k * k * k * k : 1 - Math.pow(-2 * k + 2, 4) / 2;
        W.scrollTo(0, from + (to - from) * ease);
        if (k < 1) { anim = requestAnimationFrame(step); return; }
        anim = 0;
        try { history.pushState(null, '', id ? '#' + id : W.location.pathname + W.location.search); } catch (er) {}
        if (t) { t.classList.add('is-target'); setTimeout(function () { t.classList.remove('is-target'); }, 1000); }
      })(performance.now());
    });
  }

  /* ======================================================== v16 feature modules (work with or without motion) */
  var I18 = {
    en: { ph: 'Type a command or search…', none: 'No results', goto: 'Go to', theme: 'Theme', lang: 'Switch language', fmt: 'Toggle 12 / 24-hour clock',
          mail: 'Copy email address', copied: 'Copied', cv: 'Download CV', proj: 'Project', top: 'Back to top', menu: 'Command menu', chaos: 'Toggle chaos mode',
          share: 'Share this page', act: 'Action', keys: '↑ ↓ move · Enter select · Esc close', chaosOn: 'Chaos mode ON', chaosOff: 'Chaos mode off',
          saved: 'Draft restored', night: 'Good night', morn: 'Good morning', aft: 'Good afternoon', eve: 'Good evening', sending: 'Sending…', hint: 'Menu',
          edT: 'How would you like to see this site?', edC: 'Classic (grunge)', edM: 'Motion Edition \u2726', edX: 'Close', edDefM: 'Make Motion Edition my default', edDefC: 'Make Classic my default', edSetM: 'Motion Edition is now your default', edSetC: 'Classic is now your default',
          nextTheme: 'Next theme', rndTheme: 'Random theme', txt: 'Text size', txtN: ['Normal', 'Large', 'Extra large'],
          calm: 'Calm mode (turn motion effects off / on)', calmOn: 'Calm mode ON, reloading…', calmOff: 'Calm mode off, reloading…',
          install: 'Install as app', installIos: 'Install: tap Share, then Add to Home Screen', installed: 'Installed', print: 'Print / save as PDF',
          secLink: 'Copy link to this section', pageLink: 'Copy page link', vcard: 'Save contact card', orbit: 'Open Orbit page',
          online: 'Back online', offline: 'You are offline', swipe: 'Swipe left / right for more projects', copyMail: 'Copy email',
          help: 'Keyboard shortcuts', helpClose: 'Close', next: 'Next', prev: 'Previous', link: 'Link',
          hk: [['Ctrl K  or  /', 'Command menu'], ['J  /  K', 'Next / previous section'], ['1 – 9', 'Jump to a nav item'], ['T', 'Next theme'],
               ['G  /  Shift G', 'Top / bottom of the page'], ['←  →', 'Previous / next project (project pages)'], ['?', 'This help'], ['Esc', 'Close']] },
    ja: { ph: 'コマンドまたは検索…', none: '結果なし', goto: '移動', theme: 'テーマ', lang: '言語を切り替え', fmt: '12／24時間表示を切り替え',
          mail: 'メールアドレスをコピー', copied: 'コピーしました', cv: 'CVをダウンロード', proj: 'プロジェクト', top: 'トップへ戻る', menu: 'コマンドメニュー', chaos: 'カオスモード切り替え',
          share: 'このページを共有', act: '操作', keys: '↑ ↓ 移動 · Enter 決定 · Esc 閉じる', chaosOn: 'カオスモード ON', chaosOff: 'カオスモード OFF',
          saved: '下書きを復元しました', night: 'おやすみなさい', morn: 'おはようございます', aft: 'こんにちは', eve: 'こんばんは', sending: '送信中…', hint: 'メニュー',
          edT: 'どちらの版で見ますか？', edC: 'クラシック（グランジ）', edM: 'モーション版 \u2726', edX: '閉じる', edDefM: 'モーション版を既定にする', edDefC: 'クラシック版を既定にする', edSetM: 'モーション版を既定にしました', edSetC: 'クラシック版を既定にしました',
          nextTheme: '次のテーマ', rndTheme: 'ランダムなテーマ', txt: '文字サイズ', txtN: ['標準', '大', '特大'],
          calm: 'カームモード（動きの演出をオフ／オン）', calmOn: 'カームモード ON、再読み込み中…', calmOff: 'カームモード OFF、再読み込み中…',
          install: 'アプリとして追加', installIos: '追加：共有ボタン →「ホーム画面に追加」', installed: '追加しました', print: '印刷／PDFとして保存',
          secLink: 'このセクションのリンクをコピー', pageLink: 'ページのリンクをコピー', vcard: '連絡先カードを保存', orbit: 'Orbitページを開く',
          online: 'オンラインに戻りました', offline: 'オフラインです', swipe: '左右にスワイプで他のプロジェクトへ', copyMail: 'メールをコピー',
          help: 'キーボードショートカット', helpClose: '閉じる', next: '次', prev: '前', link: 'リンク',
          hk: [['Ctrl K  または  /', 'コマンドメニュー'], ['J  /  K', '次／前のセクション'], ['1 – 9', 'ナビ項目へ移動'], ['T', '次のテーマ'],
               ['G  /  Shift G', 'ページの先頭／末尾'], ['←  →', '前／次のプロジェクト（プロジェクトページ）'], ['?', 'このヘルプ'], ['Esc', '閉じる']] }
  };
  var T = I18[LANG] || I18.en;

  function toast(msg) {
    var t = $('.toast');
    if (!t) { t = D.createElement('div'); t.className = 'toast'; t.setAttribute('role', 'status'); t.setAttribute('aria-live', 'polite'); D.body.appendChild(t); }
    t.textContent = msg;
    void t.offsetWidth;
    t.classList.add('show');
    clearTimeout(t._h);
    t._h = setTimeout(function () { t.classList.remove('show'); }, 2300);
  }
  function copy(text, label) {
    function ok() { buzz(10); toast(T.copied + ': ' + (label || text)); }
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(ok, fallback); } else fallback();
    function fallback() {
      var ta = D.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      D.body.appendChild(ta); ta.select();
      try { D.execCommand('copy'); ok(); } catch (e) {}
      D.body.removeChild(ta);
    }
  }

  /* ---------- click-to-copy handles (Discord names etc.) ---------- */
  function copyables() {
    $$('.handles .tag').forEach(function (el) {
      el.setAttribute('role', 'button'); el.tabIndex = 0; el.title = T.copied.replace(/!$/, '') + '?';
      el.classList.add('copyable');
      function go() { copy(el.textContent.trim()); }
      el.addEventListener('click', go);
      el.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
    });
  }

  /* ---------- greeting in the big clock ---------- */
  function greeting() {
    var top = $('.clock-top'), btn = top && $('.clock-fmt', top);
    if (!top) return;
    var g = D.createElement('span'); g.className = 'clock-greet';
    top.insertBefore(g, btn);
    function upd() {
      var h = new Date().getHours();
      var t = h < 5 ? T.night : h < 12 ? T.morn : h < 18 ? T.aft : T.eve;
      if (g.textContent !== t) g.textContent = t;
    }
    upd(); setInterval(upd, 30000);
  }

  /* ---------- contact form: character counter, local draft, sending state ---------- */
  function formHelpers() {
    var form = $('form.form');
    if (!form) return;
    var name = $('[name=name]', form), email = $('[name=email]', form), msg = $('[name=message]', form), btn = $('button[type=submit]', form);
    var KEY = 'portfolio-draft';
    if (/[?&]sent=1/.test(location.search)) { try { localStorage.removeItem(KEY); } catch (e) {} }
    if (msg) {
      var max = parseInt(msg.getAttribute('maxlength'), 10) || 5000, c = D.createElement('span');
      c.className = 'count'; c.setAttribute('aria-hidden', 'true');
      msg.parentNode.appendChild(c);
      var upd = function () { c.textContent = msg.value.length + ' / ' + max; c.classList.toggle('warn', msg.value.length > max * 0.9); };
      msg.addEventListener('input', upd); upd();
    }
    var restored = false;
    try {
      var d = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (d) {
        [[name, 'name'], [email, 'email'], [msg, 'message']].forEach(function (p) { if (p[0] && !p[0].value && d[p[1]]) { p[0].value = d[p[1]]; restored = true; } });
        if (restored && msg) msg.dispatchEvent(new Event('input'));
      }
    } catch (e) {}
    if (restored && /#contact/.test(location.hash)) toast(T.saved);
    var save = debounce(function () {
      try { localStorage.setItem(KEY, JSON.stringify({ name: name ? name.value : '', email: email ? email.value : '', message: msg ? msg.value : '' })); } catch (e) {}
    }, 400);
    form.addEventListener('input', save);
    form.addEventListener('submit', function () {
      if (!btn) return;
      btn.setAttribute('aria-busy', 'true'); btn.classList.add('busy');
      setTimeout(function () { btn.disabled = true; btn.textContent = T.sending; }, 0);
    });
  }

  /* ---------- command palette (Ctrl/Cmd + K, or "/") ---------- */
  function palette() {
    var items = [], seen = {};
    function add(label, hint, run, key) { if (!label || (key && seen[key])) return; if (key) seen[key] = 1; items.push({ label: label, hint: hint, run: run, hay: (label + ' ' + hint).toLowerCase() }); }

    $$('.nav-links a').forEach(function (a) { add(a.textContent.trim(), T.goto, function () { a.click(); }, 'n' + a.getAttribute('href')); });
    add(T.top, T.goto, function () { W.scrollTo({ top: 0, behavior: FX ? 'smooth' : 'auto' }); }, 'top');
    $$('a[href^="project.php?p="]').forEach(function (a) {
      var box = a.closest('.card, .featured'), h = box && $('h2, h3', box), lbl = ((h && h.textContent) || a.textContent).trim();
      add(lbl, T.proj, function () { location.href = a.href; }, 'p' + a.getAttribute('href'));
    });
    $$('.th-opt').forEach(function (o) {
      var inp = $('input', o), nm = $('.th-name', o);
      if (inp && nm) add(nm.textContent.trim(), T.theme, function () { inp.click(); toast(T.theme + ': ' + nm.textContent.trim()); }, 't' + inp.value);
    });
    var lang = $('.nav-lang'); if (lang) add(T.lang + ' (' + lang.textContent.trim() + ')', T.act, function () { location.href = lang.href; }, 'lang');
    var fmt = $('.clock-fmt'); if (fmt) add(T.fmt, T.act, function () { fmt.click(); }, 'fmt');
    var chaos = $('#chaos'), cl = $('label[for=chaos]'); if (chaos) add((cl && cl.textContent.trim()) || T.chaos, T.act, function () { chaos.click(); toast(chaos.checked ? T.chaosOn : T.chaosOff); }, 'chaos');
    var mail = $('a[href^="mailto:"]'); if (mail) { var em = mail.getAttribute('href').replace(/^mailto:/, ''); add(T.mail + ' — ' + em, T.act, function () { copy(em); }, 'mail'); }
    var cv = $('a[href="cv.pdf"]'); if (cv) add(T.cv, T.act, function () { var a = D.createElement('a'); a.href = 'cv.pdf'; a.download = ''; D.body.appendChild(a); a.click(); a.remove(); }, 'cv');
    if (navigator.share) add(T.share, T.act, function () { navigator.share({ title: D.title, url: location.href.split('#')[0] }).catch(function () {}); }, 'share');
    PAL_ADD = add;
    safe(function () { extraPalette(add); }, 'palette-extra');

    var root = D.createElement('div');
    root.className = 'pal'; root.hidden = true;
    root.innerHTML = '<div class="pal-box" role="dialog" aria-modal="true" aria-label="' + T.menu + '"><span class="pal-grab" aria-hidden="true"></span>' +
      '<input class="pal-in" type="text" role="combobox" aria-expanded="true" aria-controls="pal-list" aria-autocomplete="list" autocomplete="off" spellcheck="false" placeholder="' + T.ph + '">' +
      '<ul class="pal-list" id="pal-list" role="listbox"></ul><p class="pal-foot">' + T.keys + '</p></div>';
    D.body.appendChild(root);
    var inp = $('.pal-in', root), list = $('.pal-list', root), box = $('.pal-box', root), sel = 0, shown = [], prev = null;

    function score(it, q) {
      if (!q) return 1;
      var i = it.hay.indexOf(q);
      if (i > -1) return 100 - i;
      var k = 0, j; for (j = 0; j < it.hay.length && k < q.length; j++) { if (it.hay.charAt(j) === q.charAt(k)) k++; }
      return k === q.length ? 1 : 0;
    }
    function draw() {
      var q = inp.value.trim().toLowerCase();
      shown = items.map(function (it) { return { it: it, s: score(it, q) }; }).filter(function (x) { return x.s > 0; });
      if (q) shown.sort(function (a, b) { return b.s - a.s; });
      shown = shown.map(function (x) { return x.it; });
      sel = clamp(sel, 0, Math.max(0, shown.length - 1));
      list.innerHTML = '';
      if (!shown.length) { var li = D.createElement('li'); li.className = 'pal-none'; li.textContent = T.none; list.appendChild(li); return; }
      shown.forEach(function (it, i) {
        var li = D.createElement('li'); li.id = 'pal-o' + i; li.setAttribute('role', 'option');
        li.setAttribute('aria-selected', i === sel ? 'true' : 'false');
        var b = D.createElement('b'); b.textContent = it.label; var s = D.createElement('span'); s.textContent = it.hint;
        li.appendChild(b); li.appendChild(s);
        li.addEventListener('mousemove', function () { if (sel !== i) { sel = i; mark(); } });
        li.addEventListener('click', function () { run(i); });
        list.appendChild(li);
      });
      mark();
    }
    function mark() {
      var els = $$('[role=option]', list);
      els.forEach(function (e, i) { e.setAttribute('aria-selected', i === sel ? 'true' : 'false'); });
      if (els[sel]) { inp.setAttribute('aria-activedescendant', els[sel].id); els[sel].scrollIntoView({ block: 'nearest' }); }
    }
    function open() {
      if (!root.hidden) return;
      prev = D.activeElement; root.hidden = false; H.classList.add('pal-open');
      inp.value = ''; sel = 0; draw(); buzz(8); box.style.translate = '';
      if (FINE) inp.focus(); else { box.setAttribute('tabindex', '-1'); box.focus(); }   // touch: don't pop the keyboard up until they tap the field
    }
    function close() {
      if (root.hidden) return;
      root.hidden = true; H.classList.remove('pal-open'); box.style.translate = '';
      if (prev && prev.focus) prev.focus();
    }
    function run(i) { var it = shown[i]; if (!it) return; close(); setTimeout(it.run, 30); }

    inp.addEventListener('input', function () { sel = 0; draw(); });
    root.addEventListener('mousedown', function (e) { if (e.target === root) close(); });
    root.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.preventDefault(); close(); }
      else if (e.key === 'ArrowDown') { e.preventDefault(); sel = (sel + 1) % Math.max(1, shown.length); mark(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); sel = (sel - 1 + shown.length) % Math.max(1, shown.length); mark(); }
      else if (e.key === 'Enter') { e.preventDefault(); run(sel); }
      else if (e.key === 'Tab') { e.preventDefault(); }
    });
    D.addEventListener('keydown', function (e) {
      var tg = e.target, typing = tg && (tg.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(tg.tagName));
      if ((e.key === 'k' || e.key === 'K') && (e.ctrlKey || e.metaKey)) { e.preventDefault(); root.hidden ? open() : close(); }
      else if (e.key === '/' && !typing && !e.ctrlKey && !e.metaKey && !e.altKey) { e.preventDefault(); open(); }
    });

    var hint = D.createElement('button');
    hint.type = 'button'; hint.className = 'kbd-hint'; hint.setAttribute('aria-label', T.menu);
    hint.innerHTML = '<i class="kbd-ico" aria-hidden="true">☰</i><kbd>' + (/Mac|iPhone|iPad/.test(navigator.platform || '') ? '⌘' : 'Ctrl') + '</kbd><kbd>K</kbd><span>' + T.hint + '</span>';
    hint.addEventListener('click', open);
    D.body.appendChild(hint);
    PAL_OPEN = open;

    /* phones: the palette is a bottom sheet, drag the handle down to dismiss */
    var grab = $('.pal-grab', root), gy = 0, gd = 0, gOn = false;
    grab.addEventListener('touchstart', function (e) { gOn = true; gy = e.touches[0].clientY; gd = 0; }, { passive: true });
    grab.addEventListener('touchmove', function (e) { if (!gOn) return; gd = Math.max(0, e.touches[0].clientY - gy); box.style.translate = '0 ' + gd + 'px'; }, { passive: true });
    function gEnd() { if (!gOn) return; gOn = false; if (gd > 90) close(); else box.style.translate = ''; }
    grab.addEventListener('touchend', gEnd); grab.addEventListener('touchcancel', gEnd);
  }

  /* ---------- Konami code: toggles the site's "make it worse" chaos mode ---------- */
  function konami() {
    var seq = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'], pos = 0;
    D.addEventListener('keydown', function (e) {
      var k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      pos = (k === seq[pos]) ? pos + 1 : (k === seq[0] ? 1 : 0);
      if (pos < seq.length) return;
      pos = 0;
      var chaos = $('#chaos'); if (chaos) { chaos.click(); toast(chaos.checked ? T.chaosOn : T.chaosOff); }
      if (FX) confetti();
    });
  }
  function confetti() {
    var wrap = D.createElement('div'); wrap.className = 'confetti'; wrap.setAttribute('aria-hidden', 'true');
    for (var i = 0; i < 48; i++) {
      var p = D.createElement('i');
      p.style.setProperty('--x', (Math.random() * 100).toFixed(1) + 'vw');
      p.style.setProperty('--r', ((Math.random() - 0.5) * 900).toFixed(0) + 'deg');
      p.style.setProperty('--dx', ((Math.random() - 0.5) * 30).toFixed(1) + 'vw');
      p.style.setProperty('--t', (1.4 + Math.random() * 1.4).toFixed(2) + 's');
      p.style.setProperty('--c', i % 3 === 0 ? 'var(--red)' : i % 3 === 1 ? 'var(--text)' : 'var(--mute)');
      wrap.appendChild(p);
    }
    D.body.appendChild(wrap);
    setTimeout(function () { wrap.remove(); }, 3200);
  }


  /* ======================================================== v17 feature modules */
  var PAL_ADD = null, PAL_OPEN = null, deferredInstall = null, BUZZ = false;
  try { BUZZ = !!navigator.vibrate && matchMedia('(pointer:coarse)').matches; } catch (e) {}
  function buzz(ms) { if (BUZZ) { try { navigator.vibrate(ms || 8); } catch (e) {} } }
  var COARSE = false;
  try { COARSE = matchMedia('(pointer:coarse)').matches; } catch (e) {}
  var STANDALONE = false;
  try { STANDALONE = !!(navigator.standalone || matchMedia('(display-mode:standalone)').matches); } catch (e) {}

  /* install-as-app: Chrome/Edge/Android fire this event; iOS has no prompt, so it gets a how-to toast */
  addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferredInstall = e; if (PAL_ADD) addInstall(PAL_ADD); });
  addEventListener('appinstalled', function () { deferredInstall = null; toast(T.installed); });
  function addInstall(add) {
    if (STANDALONE) return;
    if (deferredInstall) add(T.install, T.act, function () { var d = deferredInstall; if (!d) return; deferredInstall = null; try { d.prompt(); } catch (e) {} }, 'install');
    else if (/iPhone|iPad|iPod/.test(navigator.userAgent || '')) add(T.install, T.act, function () { toast(T.installIos); }, 'install');
  }

  /* offline / back online */
  addEventListener('offline', function () { toast(T.offline); });
  addEventListener('online', function () { toast(T.online); });
  D.addEventListener('change', function (e) { if (e.target && e.target.type === 'radio') buzz(6); });

  /* ---------- helpers: themes, text size, calm mode, sections ---------- */
  function themeInputs() { return $$('input[name=theme]'); }
  function curTheme() { var l = themeInputs(), k; for (k = 0; k < l.length; k++) { if (l[k].checked) return k; } return 0; }
  function pickTheme(i) {
    var l = themeInputs(); if (!l.length) return;
    var el = l[(i + l.length) % l.length], nm = el.parentNode && $('.th-name', el.parentNode);
    el.click(); buzz(10);
    toast(T.theme + ': ' + ((nm && nm.textContent.trim()) || el.value));
  }
  function getTxt() { try { return localStorage.getItem('txt') || '0'; } catch (e) { return '0'; } }
  function cycleTxt() {
    var n = (parseInt(getTxt(), 10) + 1) % 3;
    H.classList.remove('txt-1', 'txt-2'); if (n) H.classList.add('txt-' + n);
    try { localStorage.setItem('txt', '' + n); } catch (e) {}
    toast(T.txt + ': ' + T.txtN[n]); onResize();
  }
  function toggleCalm() {
    var on = true;
    try { on = localStorage.getItem('calm') !== '1'; localStorage.setItem('calm', on ? '1' : '0'); } catch (e) {}
    toast(on ? T.calmOn : T.calmOff);
    setTimeout(function () { location.reload(); }, 900);
  }
  function pageSections() { return $$('main > section'); }
  function currentSec() {
    var list = pageSections(), cur = null, k;
    for (k = 0; k < list.length; k++) { if (list[k].getBoundingClientRect().top <= innerHeight * 0.35) cur = list[k]; }
    return cur;
  }
  function pageUrl(id) { return location.href.split('#')[0] + (id ? '#' + id : ''); }

  function extraPalette(add) {
    add(T.nextTheme, T.theme, function () { pickTheme(curTheme() + 1); }, 'x-nt');
    add(T.rndTheme, T.theme, function () { var n = themeInputs().length; if (n > 1) { var k = curTheme(); while (k === curTheme()) { pickTheme(Math.floor(Math.random() * n)); } } }, 'x-rt');
    add(T.txt + ': ' + T.txtN[parseInt(getTxt(), 10)] + ' →', T.act, cycleTxt, 'x-txt');
    add(T.calm, T.act, toggleCalm, 'x-calm');
    add(T.pageLink, T.act, function () { copy(pageUrl(''), T.link); }, 'x-pl');
    add(T.secLink, T.act, function () { var s = currentSec(); if (s && s.id) copy(pageUrl(s.id), '#' + s.id); else copy(pageUrl(''), T.link); }, 'x-sl');
    add(T.print, T.act, function () { W.print(); }, 'x-print');
    var vc = $('a[href="contact.vcf"]'); if (vc) add(T.vcard, T.act, function () { vc.click(); }, 'x-vc');
    var mo = $('a[href="motion.php"]'); if (mo) add(mo.textContent.replace(/^\s*\u2726\s*/, '').trim(), T.goto, function () { location.href = mo.href; }, 'x-motion');
    add(edition() === 'motion' ? T.edDefC : T.edDefM, T.act, function () { var m = edition() !== 'motion'; setEdition(m ? 'motion' : 'classic'); toast(m ? T.edSetM : T.edSetC); }, 'x-ed');
    var ob = $('a[href="orbit.html"]'); if (ob) add(T.orbit, T.goto, function () { location.href = ob.href; }, 'x-orbit');
    if (FINE) add(T.help, T.act, showHelp, 'x-help');
    addInstall(add);
  }

  /* ---------- reading-progress bar (top edge) ---------- */
  function progress() {
    var bar = D.createElement('div'), fill = D.createElement('i'), max = 1, last = -1;
    bar.className = 'rp'; bar.setAttribute('aria-hidden', 'true'); bar.appendChild(fill);
    D.body.appendChild(bar);
    function measure() { max = Math.max(1, H.scrollHeight - innerHeight); }
    measure(); resizeCbs.push(measure);
    tasks.push({ write: function (_, y) {
      var p = clamp(y / max, 0, 1);
      if (Math.abs(p - last) > 0.0004) { last = p; fill.style.scale = p.toFixed(4) + ' 1'; bar.classList.toggle('on', y > 8); }
      return false;
    } });
  }

  /* ---------- click / tap a section number to copy a deep link to that section ---------- */
  function sectionLinks() {
    $$('main > section[id] .head .no').forEach(function (el) {
      var sec = el.closest('section');
      if (!sec) return;
      el.setAttribute('role', 'button'); el.tabIndex = 0; el.title = T.secLink; el.classList.add('copyable');
      function go() { copy(pageUrl(sec.id), '#' + sec.id); }
      el.addEventListener('click', go);
      el.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
    });
  }

  /* ---------- contact: copy-email button, auto-growing message box, Ctrl/Cmd+Enter to send ---------- */
  function contactExtras() {
    var links = $('#contact .links'), mail = links && $('a[href^="mailto:"]', links);
    if (mail) {
      var em = mail.getAttribute('href').replace(/^mailto:/, ''), b = D.createElement('button');
      b.type = 'button'; b.className = 'btn btn-ghost'; b.textContent = T.copyMail;
      b.addEventListener('click', function () { copy(em); });
      mail.parentNode.insertBefore(b, mail.nextSibling);
    }
    var form = $('form.form'), msg = form && $('textarea', form);
    if (!msg) return;
    function fit() {
      var cap = innerHeight * 0.7;
      msg.style.height = 'auto';
      msg.style.height = Math.min(msg.scrollHeight + 2, cap) + 'px';
      msg.style.overflowY = msg.scrollHeight > cap ? 'auto' : 'hidden';
    }
    msg.addEventListener('input', fit);
    resizeCbs.push(fit);
    setTimeout(fit, 80);
    msg.addEventListener('keydown', function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); if (form.requestSubmit) form.requestSubmit(); else form.submit(); }
    });
  }

  /* ---------- keyboard shortcuts + help sheet ---------- */
  var helpRoot = null, helpPrev = null;
  function hideHelp() { if (!helpRoot || helpRoot.hidden) return; helpRoot.hidden = true; H.classList.remove('pal-open'); if (helpPrev && helpPrev.focus) helpPrev.focus(); }
  function showHelp() {
    if (!helpRoot) {
      helpRoot = D.createElement('div'); helpRoot.className = 'pal help'; helpRoot.hidden = true;
      var rows = T.hk.map(function (r) { return '<dt><kbd>' + r[0].split(/\s{2,}/).join('</kbd> <kbd>') + '</kbd></dt><dd>' + r[1] + '</dd>'; }).join('');
      helpRoot.innerHTML = '<div class="pal-box" role="dialog" aria-modal="true" aria-label="' + T.help + '" tabindex="-1"><p class="help-t">' + T.help + '</p><dl class="help-l">' + rows + '</dl>' +
        '<p class="pal-foot"><button type="button" class="help-x">' + T.helpClose + ' · Esc</button></p></div>';
      D.body.appendChild(helpRoot);
      helpRoot.addEventListener('mousedown', function (e) { if (e.target === helpRoot) hideHelp(); });
      helpRoot.addEventListener('keydown', function (e) { if (e.key === 'Escape' || e.key === '?') { e.preventDefault(); hideHelp(); } else if (e.key === 'Tab') { e.preventDefault(); } });
      $('.help-x', helpRoot).addEventListener('click', hideHelp);
    }
    helpPrev = D.activeElement; helpRoot.hidden = false; H.classList.add('pal-open');
    $('.pal-box', helpRoot).focus();
  }

  function shortcuts() {
    function go(dir) {
      var list = pageSections(); if (!list.length) return;
      var y = W.pageYOffset || 0, tops = list.map(function (s) { return s.getBoundingClientRect().top + y; }), nav = $('.nav'), navH = nav ? nav.offsetHeight : 0, i, cur = -1;
      for (i = 0; i < tops.length; i++) { if (tops[i] <= y + 8) cur = i; }
      var to, t = clamp(cur + dir, 0, list.length - 1);
      if (dir > 0 && cur === list.length - 1) to = H.scrollHeight;     // already at the last section: go to the footer
      else { to = tops[t]; if (to < y) to -= navH; }
      W.scrollTo({ top: Math.max(0, Math.round(to)), behavior: FX ? 'smooth' : 'auto' });
    }
    var nxt = D.body.getAttribute('data-next'), prv = D.body.getAttribute('data-prev');
    D.addEventListener('keydown', function (e) {
      if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey || H.classList.contains('pal-open')) return;
      var tg = e.target, typing = tg && (tg.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(tg.tagName));
      if (typing) return;
      var k = e.key;
      if (k === 'j') { e.preventDefault(); go(1); }
      else if (k === 'k') { e.preventDefault(); go(-1); }
      else if (k === 't') { pickTheme(curTheme() + 1); }
      else if (k === 'g') { W.scrollTo({ top: 0, behavior: FX ? 'smooth' : 'auto' }); }
      else if (k === 'G') { W.scrollTo({ top: H.scrollHeight, behavior: FX ? 'smooth' : 'auto' }); }
      else if (k === '?') { e.preventDefault(); showHelp(); }
      else if (/^[1-9]$/.test(k)) { var a = $$('.nav-links a')[parseInt(k, 10) - 1]; if (a) { e.preventDefault(); a.click(); } }
      else if (k === 'ArrowRight' && nxt) { location.href = nxt; }
      else if (k === 'ArrowLeft' && prv) { location.href = prv; }
    });
  }

  /* ---------- project pages: swipe left / right on a phone to move between projects ---------- */
  function swipeNav() {
    var b = D.body, nx = b.getAttribute('data-next'), pv = b.getAttribute('data-prev');
    if (!nx || !pv) return;
    var x0 = 0, y0 = 0, t0 = 0, ok = false;
    D.addEventListener('touchstart', function (e) {
      var t = e.target;
      ok = e.touches.length === 1 && !(t.closest && t.closest('input,textarea,select,.nav-links,.pal,.th-panel,.shots,pre,table'));
      x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; t0 = Date.now();
      if (x0 < 22 || x0 > innerWidth - 22) ok = false;               // leave the system back-gesture edges alone
    }, { passive: true });
    D.addEventListener('touchcancel', function () { ok = false; }, { passive: true });
    D.addEventListener('touchend', function (e) {
      if (!ok) return; ok = false;
      var c = e.changedTouches[0], dx = c.clientX - x0, dy = c.clientY - y0;
      if (Math.abs(dx) < 90 || Math.abs(dy) > 50 || Math.abs(dx) < Math.abs(dy) * 2.2 || Date.now() - t0 > 650) return;
      var fwd = dx < 0;
      buzz(12);
      toast((fwd ? T.next : T.prev) + ': ' + (b.getAttribute(fwd ? 'data-next-t' : 'data-prev-t') || ''));
      setTimeout(function () { location.href = fwd ? nx : pv; }, 220);
    }, { passive: true });
    var host = $('.pd-next .wrap');
    if (host && COARSE) { var p = D.createElement('p'); p.className = 'swipe-hint'; p.textContent = '← ' + T.swipe + ' →'; host.appendChild(p); }
  }

  /* ---------- edition choice: Classic or Motion (remembered; first-time visitors get a small chooser) ---------- */
  function edition() { try { return localStorage.getItem('edition') || ''; } catch (e) { return ''; } }
  function setEdition(v) { try { localStorage.setItem('edition', v); } catch (e) {} }
  function editionBanner() {
    if (edition() || !$('#top, .hero') || /[?&]e=/.test(location.search)) return;
    var b = D.createElement('div');
    b.className = 'ed-banner'; b.setAttribute('role', 'dialog'); b.setAttribute('aria-label', T.edT);
    b.innerHTML = '<p>' + T.edT + '</p><div><button type="button" class="ed-c">' + T.edC + '</button><a class="ed-m" href="motion.php?e=m">' + T.edM + '</a></div><button type="button" class="ed-x" aria-label="' + T.edX + '">&times;</button>';
    function bye() { b.classList.remove('on'); setTimeout(function () { if (b.parentNode) b.parentNode.removeChild(b); }, 400); }
    $('.ed-c', b).addEventListener('click', function () { setEdition('classic'); bye(); });
    $('.ed-x', b).addEventListener('click', function () { setEdition('classic'); bye(); });
    D.addEventListener('keydown', function (e) { if (e.key === 'Escape' && b.parentNode) { setEdition('classic'); bye(); } });
    setTimeout(function () { D.body.appendChild(b); void b.offsetWidth; b.classList.add('on'); }, 2600);
  }
  safe(function () {
    if (/[?&]e=c(&|$)/.test(location.search) && W.history && history.replaceState) {
      history.replaceState(null, '', location.pathname + location.search.replace(/([?&])e=[^&]*&?/, '$1').replace(/[?&]$/, '') + location.hash);
    }
    if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
      addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); });
    }
  }, 'edition');

  /* ------------------------------------------------------------------- boot */
  safe(clock, 'clock');
  safe(themeColor, 'theme-color');
  safe(function () { fitHero(); resizeCbs.push(fitHero); }, 'fitHero');

  var isPinned = false;
  if (FX && HAS_IO) {
    safe(function () { isPinned = pinned(); }, 'pinned');
    safe(function () { reveal(isPinned); }, 'reveal');
    safe(counters, 'counters');
    safe(hero, 'hero');
    safe(scrollVars, 'scrollVars');
    safe(marquee, 'marquee');
    safe(pointerFx, 'pointerFx');
    safe(cursor, 'cursor');
    safe(anchors, 'anchors');
  }
  safe(copyables, 'copyables');
  safe(greeting, 'greeting');
  safe(formHelpers, 'form');
  safe(palette, 'palette');
  safe(konami, 'konami');
  safe(editionBanner, 'editionBanner');
  safe(progress, 'progress');
  safe(sectionLinks, 'sectionLinks');
  safe(contactExtras, 'contactExtras');
  safe(shortcuts, 'shortcuts');
  safe(swipeNav, 'swipeNav');
  safe(spy, 'spy');   // after pinned(): section positions already include the pinned height
  resizeCbs.push(function () {});
  kick();
})();
