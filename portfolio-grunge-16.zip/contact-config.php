<?php
/* contact-config.php: the one place for the contact address. Used by index.php, motion.php and motion-contact.php.
   CONTACT_TO = where messages are delivered. MAIL_FROM = an address on YOUR OWN domain (free hosts reject others). */
const CONTACT_TO = 'moinhamza32@gmail.com';
const MAIL_FROM  = 'noreply@moinhamza.gt.tc';
