<?php
/* ---------------------------------------------------------------------------
   Portfolio — index.php
   Contact form is processed here (it works without JavaScript; no separate API file).
   Edit the two constants below if your address or domain changes.
   --------------------------------------------------------------------------- */
require __DIR__ . '/lib.php';
require_once __DIR__ . '/contact-config.php';   // CONTACT_TO / MAIL_FROM live there now

$values = ['name' => '', 'email' => '', 'message' => '', 'topic' => 'project'];
$errors = [];
$failed = false;
$sent   = isset($_GET['sent']) && $_GET['sent'] === '1';

function clean_line($v) { return trim(preg_replace('/[\x00-\x1F\x7F]+/', ' ', (string) $v)); }
function text_len($v)   { return function_exists('mb_strlen') ? mb_strlen($v, 'UTF-8') : strlen($v); }
/* typewriter width in 'ch' columns: Japanese / full-width characters are about two columns wide (validation keeps using text_len) */
function type_cols($v)  {
    $wide = preg_match_all('/[\x{1100}-\x{115F}\x{2E80}-\x{A4CF}\x{AC00}-\x{D7A3}\x{F900}-\x{FAFF}\x{FE30}-\x{FE6F}\x{FF00}-\x{FF60}\x{FFE0}-\x{FFE6}]/u', (string) $v);
    return text_len($v) + (int) $wide;
}
function e($v)          { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $values['name']    = clean_line($_POST['name'] ?? '');
    $values['email']   = clean_line($_POST['email'] ?? '');
    $values['message'] = trim(str_replace("\r\n", "\n", (string) ($_POST['message'] ?? '')));

    $tp = (string) ($_POST['topic'] ?? '');
    $values['topic'] = isset($TOPIC_EN[$tp]) ? $tp : 'project';

    // Honeypot: real visitors never see or fill this field. Pretend success to bots.
    if (trim((string) ($_POST['website'] ?? '')) !== '') {
        header('Location: index.php?sent=1#contact', true, 303);
        exit;
    }

    if ($values['name'] === '' || text_len($values['name']) > 100) {
        $errors['name'] = t('e.name');
    }
    if ($values['email'] === '' || text_len($values['email']) > 150 || !filter_var($values['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = t('e.email');
    }
    if (text_len($values['message']) < 5 || text_len($values['message']) > 5000) {
        $errors['message'] = t('e.msg');
    }

    if (!$errors && !token_ok($_POST['tk'] ?? '')) { $errors['form'] = t('e.token'); }
    if (!$errors && rate_limited())                  { $errors['form'] = t('e.rate'); }

    if (!$errors) {
        $subject = '=?UTF-8?B?' . base64_encode('[Portfolio] ' . $TOPIC_EN[$values['topic']] . ' - message from ' . $values['name']) . '?=';
        $body    = "Topic: {$TOPIC_EN[$values['topic']]}\nName: {$values['name']}\nEmail: {$values['email']}\n\n{$values['message']}\n";
        $headers = "From: Portfolio <" . MAIL_FROM . ">\r\n"
                 . "Reply-To: {$values['email']}\r\n"
                 . "MIME-Version: 1.0\r\n"
                 . "Content-Type: text/plain; charset=UTF-8\r\n";

        if (@mail(CONTACT_TO, $subject, $body, $headers)) {
            rate_record();
            header('Location: index.php?sent=1#contact', true, 303);   // POST/redirect/GET: refresh won't resend
            exit;
        }
        $failed = true;
    }
}
?>
<!DOCTYPE html>
<html lang="<?= e($L) ?>" data-theme="<?= e($THEME) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="description" content="Mohammed Moin Hamza (Dino/n6ble) — Developer, AI Enthusiast &amp; Builder.">
<meta name="theme-color" content="#0A0A0A">
<meta name="color-scheme" content="dark">
<title>Mohammed Moin Hamza — Developer &amp; AI Enthusiast</title>
<link rel="icon" type="image/jpeg" href="dino-logo.jpg">
<link rel="apple-touch-icon" href="icon-192.png">
<link rel="manifest" href="site.webmanifest">
<link rel="canonical" href="<?= e(SITE_URL) ?>/">
<meta property="og:type" content="website">
<meta property="og:title" content="Mohammed Moin Hamza — Developer &amp; AI Enthusiast">
<meta property="og:description" content="Discord bots, AI integrations and web projects built from scratch.">
<meta property="og:url" content="<?= e(SITE_URL) ?>/">
<meta property="og:image" content="<?= e(SITE_URL) ?>/dino-logo.jpg">
<meta name="twitter:card" content="summary">
<script type="application/ld+json"><?= json_encode([
  '@context' => 'https://schema.org', '@type' => 'Person', 'name' => 'Mohammed Moin Hamza',
  'alternateName' => ['Dino', 'n6ble'], 'url' => SITE_URL . '/', 'image' => SITE_URL . '/dino-logo.jpg',
  'jobTitle' => 'Developer', 'description' => 'Developer and AI enthusiast building Discord bots, AI integrations and web projects.',
  'knowsAbout' => ['Python', 'Discord bots', 'PHP', 'JavaScript', 'AI integrations', 'Web development'],
  'sameAs' => ['https://github.com/moinhamza', 'https://www.instagram.com/epichamzax'],
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?></script>
<link rel="stylesheet" href="style.css?v=18">
<?= site_js() ?>
</head>
<body>
<input type="checkbox" id="chaos" class="vh" aria-label="<?= e(t('chaos')) ?>">
<a class="skip" href="#about"><?= t('skip') ?></a>

<p class="print-id">Mohammed Moin Hamza &mdash; <?= e(SITE_URL) ?></p>
<header class="nav">
  <a href="#home" class="logo"><img src="dino-logo.jpg" alt="" width="58" height="58"><span>Hamza</span></a>
  <nav class="nav-links" aria-label="Primary">
    <a href="#about"><?= t('n.about') ?></a><a href="#skills"><?= t('n.skills') ?></a><a href="#services"><?= t('n.services') ?></a><a href="#projects"><?= t('n.projects') ?></a>
    <a href="#journey"><?= t('n.journey') ?></a><a href="#now"><?= t('n.now') ?></a><a href="#tools"><?= t('n.tools') ?></a><a href="#contact"><?= t('n.contact') ?></a>
  </nav>
  <div class="nav-clock" data-clock="mini" aria-hidden="true"><b class="nc-time">--:--:--</b><span class="nc-date">&nbsp;</span></div>
  <?= theme_picker() ?>
  <label class="nav-tool theme-lbl" for="th-menu" title="<?= e(t('themes')) ?>"><span class="vh"><?= t('theme') ?></span><i aria-hidden="true"></i></label>
  <a class="nav-tool nav-lang" href="<?= lang_url() ?>" lang="<?= $L === 'ja' ? 'en' : 'ja' ?>" hreflang="<?= $L === 'ja' ? 'en' : 'ja' ?>"><?= $L === 'ja' ? 'EN' : '日本語' ?></a>
  <a href="#contact" class="nav-cta"><?= t('n.talk') ?></a>
</header>

<main id="home">

<section class="sec dark hero">
  <div class="hero-ghost" aria-hidden="true">DINO</div>
  <div class="wrap hero-grid">
    <div>
      <div class="hero-meta">
        <p class="status"><span class="type" style="--len:<?= (int) type_cols(html_entity_decode(t('status'), ENT_QUOTES, 'UTF-8')) ?>"><?= t('status') ?></span></p>
        <p class="hero-time" data-clock="chip" aria-hidden="true"></p>
      </div>
      <h1><span>Mohammed</span><span class="r"><mark>Moin</mark></span><span>Hamza</span></h1>
      <ul class="roles" aria-label="Roles"><li><?= t('r1') ?></li><li><?= t('r2') ?></li><li><?= t('r3') ?></li></ul>
      <p class="tagline"><?= t('tagline') ?></p>
      <div class="btn-row">
        <a href="#projects" class="btn btn-primary"><?= t('viewwork') ?></a>
        <a href="#contact" class="btn btn-ghost"><?= t('contactme') ?></a>
        <a href="motion.php" class="btn btn-ghost btn-motion">&#10022; <?= t('motion') ?></a>
        <?php if (is_file(__DIR__ . '/cv.pdf')): ?><a href="cv.pdf" class="btn btn-ghost" download><?= t('cv') ?></a><?php endif; ?>
      </div>
    </div>
    <aside class="collage" aria-label="Quick facts">
      <div class="photo"><img src="dino-logo.jpg" alt="Mohammed Moin Hamza" width="400" height="400"></div>
      <div class="fact">
        <div class="nm">Mohammed Moin Hamza</div>
        <p>Developer from the Discord community</p>
        <ul class="facts">
          <li><b>Discord</b> Dino &amp; n6ble</li>
          <li><b>GitHub</b> moinhamza</li>
          <li><b>Status</b> Student, 19</li>
          <li><b>Stack</b> Python Dev</li>
        </ul>
      </div>
    </aside>
  </div>

  <div class="wrap clock-wrap">
    <section class="clock" id="clock" data-clock="big" aria-label="<?= e(t('ck.sr')) ?>">
      <div class="clock-top">
        <span class="clock-live"><?= t('ck.live') ?></span>
        <span class="clock-label"><?= t('ck.label') ?></span>
        <button type="button" class="clock-fmt" aria-pressed="false" aria-label="<?= e(t('ck.fmt')) ?>" title="<?= e(t('ck.fmt')) ?>">24H</button>
      </div>
      <div class="clock-digits" aria-hidden="true">
        <span class="d" data-d="h1">0</span><span class="d" data-d="h2">0</span><i class="colon">:</i><span class="d" data-d="m1">0</span><span class="d" data-d="m2">0</span><i class="colon">:</i><span class="d s" data-d="s1">0</span><span class="d s" data-d="s2">0</span><span class="ampm" hidden>AM</span>
      </div>
      <div class="clock-date" aria-hidden="true"><b class="cd-day">&nbsp;</b><span class="cd-date">&nbsp;</span><span class="cd-tz">&nbsp;</span></div>
      <div class="clock-bar" aria-hidden="true"><span class="cb-fill"></span><span class="cb-text"></span></div>
      <time class="vh" datetime=""></time>
    </section>
  </div>
</section>

<ul class="stats" aria-label="Stats">
  <li><b style="--to:2" data-s="+">2+</b><span><?= t('s1') ?></span></li>
  <li><b style="--to:3" data-s="+">3+</b><span><?= t('s2') ?></span></li>
  <li><b style="--to:5" data-s="+">5+</b><span><?= t('s3') ?></span></li>
  <li><b style="--to:6" data-s="+">6+</b><span><?= t('s4') ?></span></li>
  <li><b style="--to:1000" data-s="+">1000+</b><span><?= t('s5') ?></span></li>
</ul>

<div class="ticker" aria-hidden="true"><div class="ticker-track"><div class="tk"><span>Python</span><i></i><span>Discord Bots</span><i></i><span>AI &amp; LLMs</span><i></i><span>Web Dev</span><i></i><span>Automation</span><i></i><span>Groq</span><i></i><span>Gemini</span><i></i><span>PHP</span><i></i></div><div class="tk"><span>Python</span><i></i><span>Discord Bots</span><i></i><span>AI &amp; LLMs</span><i></i><span>Web Dev</span><i></i><span>Automation</span><i></i><span>Groq</span><i></i><span>Gemini</span><i></i><span>PHP</span><i></i></div></div></div>

<section id="about" class="sec paper">
  <div class="wrap">
    <div class="head"><span class="no">01</span><h2><?= t('h.about') ?></h2><p><?= t('hp.about') ?></p></div>
    <div class="about-grid">
      <div class="about-card">
        <img src="dino-logo.jpg" alt="Dino" width="112" height="112" loading="lazy">
        <div class="nm">Mohammed Moin Hamza</div>
        <div class="handles"><span class="tag">Dino</span><span class="tag">n6ble</span><span class="tag">zenthorn</span></div>
        <p>Student &mdash; 19 years old<br>Developer from the Discord community</p>
        <div class="mini">
          <div><b>5+</b><span>Languages</span></div><div><b>6+</b><span>Projects</span></div>
          <div><b>2+</b><span>Years Coding</span></div><div><b>&infin;</b><span>Curiosity</span></div>
        </div>
      </div>
      <div class="about-text">
        <p>It started on <strong>Discord</strong>. Hours spent in communities, managing servers, discovering how bots worked &mdash; that curiosity became everything.</p>
        <p>What began as a fascination with bots turned into real programming. I started with <strong>Python</strong>, then moved into <strong>HTML, CSS, JavaScript, and PHP</strong> &mdash; building websites, automation scripts, AI integrations, and Discord bots.</p>
        <p>I built my first <strong>live website</strong> for my own Discord bot, integrated <strong>Groq and Gemini AI APIs</strong>, and shipped real projects that real people use.</p>
        <p>Today I focus on <strong>AI, machine learning, web development</strong>, and building things that actually work.</p>
        <blockquote class="quote"><p>I didn't start with a roadmap. I started with Discord, curiosity, and a lot of questions. The code came later &mdash; and it never stopped.</p></blockquote>
      </div>
    </div>
  </div>
</section>

<section id="skills" class="sec dark">
  <div class="wrap">
    <div class="head"><span class="no">02</span><h2><?= t('h.skills') ?></h2><p><?= t('hp.skills') ?></p></div>
    <ul class="grid g-skills">
      <li class="card skill"><span class="mono-tile" aria-hidden="true">Py</span><b>Python</b><span>Primary language</span></li>
      <li class="card skill"><span class="mono-tile" aria-hidden="true">JS</span><b>JavaScript</b><span>Frontend logic</span></li>
      <li class="card skill"><span class="mono-tile" aria-hidden="true">H5</span><b>HTML5</b><span>Structure</span></li>
      <li class="card skill"><span class="mono-tile" aria-hidden="true">C3</span><b>CSS3</b><span>Styling</span></li>
      <li class="card skill"><span class="mono-tile" aria-hidden="true">PHP</span><b>PHP</b><span>Backend</span></li>
      <li class="card skill"><span class="mono-tile" aria-hidden="true">ML</span><b>AI / ML</b><span>Models &amp; APIs</span></li>
      <li class="card skill"><span class="mono-tile" aria-hidden="true">DC</span><b>Discord API</b><span>Bots</span></li>
      <li class="card skill"><span class="mono-tile" aria-hidden="true">API</span><b>REST API</b><span>Integrations</span></li>
      <li class="card skill"><span class="mono-tile" aria-hidden="true">Au</span><b>Automation</b><span>Scripts</span></li>
      <li class="card skill"><span class="mono-tile" aria-hidden="true">Web</span><b>Web Dev</b><span>Full-stack</span></li>
    </ul>
  </div>
</section>

<section id="services" class="sec paper">
  <div class="wrap">
    <div class="head"><span class="no">03</span><h2><?= t('h.services') ?></h2><p><?= t('hp.services') ?></p></div>
    <div class="grid g-cards">
      <article class="card"><span class="num">01</span><h3>Discord Bots</h3><p>Full-featured bots with moderation, economy, leveling, AI chat, and custom systems. Built in Python using discord.py.</p><div class="tags"><span class="tag">Python</span><span class="tag">discord.py</span><span class="tag">Groq AI</span></div></article>
      <article class="card"><span class="num">02</span><h3>Web Applications</h3><p>Responsive dark-themed web apps and portfolios built from scratch using PHP, HTML, CSS, and vanilla JavaScript.</p><div class="tags"><span class="tag">PHP</span><span class="tag">HTML5</span><span class="tag">CSS3</span></div></article>
      <article class="card"><span class="num">03</span><h3>AI Integrations</h3><p>Connecting Groq, Gemini, and other LLM APIs into web apps and bots for conversational AI and automation.</p><div class="tags"><span class="tag">Groq API</span><span class="tag">Gemini</span><span class="tag">Python</span></div></article>
      <article class="card"><span class="num">04</span><h3>Automation Scripts</h3><p>Python scripts for automating tasks &mdash; monitoring, notifications, file management, and webhook integrations.</p><div class="tags"><span class="tag">Python</span><span class="tag">REST API</span><span class="tag">Webhooks</span></div></article>
      <article class="card"><span class="num">05</span><h3>Backend Development</h3><p>Secure PHP/Python backends with validation, authentication, session management, and clean REST endpoints.</p><div class="tags"><span class="tag">PHP</span><span class="tag">Python</span><span class="tag">MySQL</span></div></article>
      <article class="card"><span class="num">06</span><h3>AI-Powered Tools</h3><p>Browser-based tools using AI APIs for practical tasks &mdash; chatbots, text tools, and creative experiments.</p><div class="tags"><span class="tag">JavaScript</span><span class="tag">AI APIs</span><span class="tag">PHP</span></div></article>
    </div>
  </div>
</section>

<section id="projects" class="sec dark alt">
  <div class="wrap">
    <div class="head"><span class="no">04</span><h2><?= t('h.projects') ?></h2><p><?= t('hp.projects') ?></p></div>

    <article class="featured" data-t="py ai php">
      <div>
        <span class="feat-label"><?= t('live') ?></span>
        <h3 class="feat-title">Dino Bot &mdash; Discord Bot</h3>
        <p>Full-featured Discord bot with moderation, utility, AI chat, image tools, and server management. Built in Python. Has a live website at <strong>dino-bot.gt.tc</strong> &mdash; designed and built by me.</p>
        <div class="tags"><span class="tag">Python</span><span class="tag">discord.py</span><span class="tag">Groq AI</span><span class="tag">Gemini</span><span class="tag">PHP Website</span></div>
        <?php $bs = bot_stats(); if ($bs) { ?>
        <ul class="botstats" aria-label="<?= e(t('botstats')) ?>"><?php foreach (['servers', 'users', 'uptime'] as $k) { if (isset($bs[$k])) { ?><li><b><?= e($bs[$k]) ?></b><span><?= t($k) ?></span></li><?php } } ?></ul>
        <?php } ?>
        <div class="btn-row">
          <a href="https://dino-bot.gt.tc/?i=1" target="_blank" rel="noopener" class="btn btn-primary"><?= t('livesite') ?> &#8599;</a>
          <a href="project.php?p=dino-bot" class="btn btn-ghost"><?= t('details') ?></a>
          <a href="https://github.com/moinhamza" target="_blank" rel="noopener" class="btn btn-ghost">GitHub &#8599;</a>
        </div>
      </div>
      <a class="browser" href="https://dino-bot.gt.tc/?i=1" target="_blank" rel="noopener" aria-label="Open the Dino Bot website">
        <div class="browser-bar" aria-hidden="true"><i></i><i></i><i></i><span>dino-bot.gt.tc</span></div>
        <div class="browser-body" aria-hidden="true">
          <img src="dino-logo.jpg" alt="" width="80" height="80" loading="lazy">
          <b>Dino Bot</b><small>Premium Discord Bot</small>
          <em><span>Invite</span><span>Commands</span></em>
        </div>
      </a>
    </article>

    <div class="pfilter" role="radiogroup" aria-label="<?= e(t('pf.label')) ?>">
      <input type="radio" name="pf" id="pf-all" class="vh" checked><label for="pf-all"><?= t('pf.all') ?></label>
      <input type="radio" name="pf" id="pf-py" class="vh"><label for="pf-py">Python</label>
      <input type="radio" name="pf" id="pf-php" class="vh"><label for="pf-php">PHP</label>
      <input type="radio" name="pf" id="pf-ai" class="vh"><label for="pf-ai">AI</label>
      <input type="radio" name="pf" id="pf-js" class="vh"><label for="pf-js">JavaScript</label>
    </div>

    <div class="grid g-cards">
      <article class="card proj" data-t="py ai">
        <div class="thumb logo"><span class="tear" aria-hidden="true"><b>Discord Bot</b></span><picture><source srcset="loyal-logo.webp" type="image/webp"><img src="loyal-logo.png" alt="Loyal Bot logo" width="150" height="82" loading="lazy"></picture></div>
        <div class="proj-body"><h3>Loyal Bot</h3><p>Feature-rich multi-cog Discord bot with moderation, economy, leveling, music, and AI-powered chat.</p>
          <div class="tags"><span class="tag">Python</span><span class="tag">discord.py</span><span class="tag">Groq AI</span></div>
          <div class="btn-row"><a href="project.php?p=loyal-bot" class="btn btn-primary btn-sm"><?= t('details') ?></a><a href="https://github.com/moinhamza" target="_blank" rel="noopener" class="btn btn-ghost btn-sm">View on GitHub &#8599;</a></div></div>
      </article>

      <article class="card proj" data-t="php">
        <div class="thumb"><span class="tear" aria-hidden="true"><b>Website</b></span>
          <svg viewBox="0 0 400 164" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Code snippet: portfolio design grunge brutalism, stack PHP and CSS">
            <text x="28" y="58" font-family="Courier New, monospace" font-size="13" style="fill:var(--red)">&lt;portfolio&gt;</text>
            <text x="46" y="86" font-family="Courier New, monospace" font-size="12" style="fill:var(--mute)">  design: grunge brutalism</text>
            <text x="46" y="108" font-family="Courier New, monospace" font-size="12" style="fill:var(--mute)">  stack: PHP/CSS</text>
            <text x="28" y="136" font-family="Courier New, monospace" font-size="13" style="fill:var(--red)">&lt;/portfolio&gt;</text>
          </svg><span class="live-badge">Live</span>
        </div>
        <div class="proj-body"><h3>This Portfolio</h3><p>Personal portfolio built from scratch. Grunge brutalist theme, CSS-first with a small script for motion and the live clock.</p>
          <div class="tags"><span class="tag">HTML</span><span class="tag">CSS3</span><span class="tag">PHP</span></div>
          <div class="btn-row"><a href="project.php?p=portfolio" class="btn btn-primary btn-sm"><?= t('details') ?></a><a href="https://github.com/moinhamza" target="_blank" rel="noopener" class="btn btn-ghost btn-sm">GitHub &#8599;</a></div></div>
      </article>

      <article class="card proj" data-t="php ai js">
        <div class="thumb"><span class="tear" aria-hidden="true"><b>Web App</b></span>
          <svg viewBox="0 0 400 164" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Chat sample: a user asks about Python and the AI replies">
            <rect x="20" y="16" width="360" height="132" fill="none" style="stroke:var(--text)" stroke-width="2"/>
            <text x="34" y="52" font-family="Courier New, monospace" font-size="10.5" style="fill:var(--mute)">user &gt; tell me about Python</text>
            <text x="34" y="76" font-family="Courier New, monospace" font-size="10.5" style="fill:var(--red)">AI   &gt; Python is a high-level...</text>
            <text x="34" y="100" font-family="Courier New, monospace" font-size="10.5" style="fill:var(--mute)">user &gt; give me an example</text>
            <text x="34" y="124" font-family="Courier New, monospace" font-size="10.5" style="fill:var(--red)">AI   &gt; Sure! Here is one: &#9611;</text>
          </svg>
        </div>
        <div class="proj-body"><h3>AI Chat Platform</h3><p>ChatGPT-style interface powered by Groq LLMs. Multi-model, history, markdown rendering.</p>
          <div class="tags"><span class="tag">PHP</span><span class="tag">Groq API</span><span class="tag">JavaScript</span></div>
          <div class="btn-row"><a href="project.php?p=ai-chat" class="btn btn-primary btn-sm"><?= t('details') ?></a><a href="https://github.com/moinhamza" target="_blank" rel="noopener" class="btn btn-ghost btn-sm">View on GitHub &#8599;</a></div></div>
      </article>

      <article class="card proj" data-t="js ai py">
        <div class="thumb"><span class="tear" aria-hidden="true"><b>Web Tools</b></span>
          <svg viewBox="0 0 400 164" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Decorative star outline labelled AI Tools">
            <polygon points="200,28 220,78 272,78 230,108 247,158 200,128 153,158 170,108 128,78 180,78" fill="none" style="stroke:var(--text)" stroke-width="3"/>
            <polygon points="200,44 216,80 250,80 222,102 234,138 200,116 166,138 178,102 150,80 184,80" style="fill:var(--red)"/>
          </svg>
        </div>
        <div class="proj-body"><h3>AI Web Tools</h3><p>Collection of browser-based AI tools and experiments using LLM and vision APIs.</p>
          <div class="tags"><span class="tag">JavaScript</span><span class="tag">Groq API</span><span class="tag">Python</span></div>
          <div class="btn-row"><a href="project.php?p=ai-tools" class="btn btn-primary btn-sm"><?= t('details') ?></a><a href="https://github.com/moinhamza" target="_blank" rel="noopener" class="btn btn-ghost btn-sm">View on GitHub &#8599;</a></div></div>
      </article>

      <article class="card proj" data-t="py">
        <div class="thumb"><span class="tear" aria-hidden="true"><b>Scripts</b></span>
          <svg viewBox="0 0 400 164" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Terminal sample: a Python bot manager connecting to Discord">
            <text x="32" y="52" font-family="Courier New, monospace" font-size="11" style="fill:var(--red)">$ python bot_manager.py</text>
            <text x="32" y="76" font-family="Courier New, monospace" font-size="10" style="fill:var(--mute)">[INFO] Connecting to Discord...</text>
            <text x="32" y="98" font-family="Courier New, monospace" font-size="10" style="fill:var(--text)">[OK]   Bot online. 3 servers</text>
            <text x="32" y="120" font-family="Courier New, monospace" font-size="10" style="fill:var(--text)">[AUTO] Running tasks... &#9611;</text>
          </svg>
        </div>
        <div class="proj-body"><h3>Discord Automation</h3><p>Python scripts for Discord automation &mdash; monitoring, scheduled notifications, and webhook pipelines.</p>
          <div class="tags"><span class="tag">Python</span><span class="tag">REST API</span><span class="tag">Webhooks</span></div>
          <div class="btn-row"><a href="project.php?p=discord-automation" class="btn btn-primary btn-sm"><?= t('details') ?></a><a href="https://github.com/moinhamza" target="_blank" rel="noopener" class="btn btn-ghost btn-sm">View on GitHub &#8599;</a></div></div>
      </article>
    </div>
  </div>
</section>

<aside class="ship dark" aria-labelledby="ship-h">
  <div class="wrap">
    <h2 id="ship-h"><?= t('shipped') ?></h2>
    <ol>
      <?php foreach ($CHANGELOG as $c) { ?><li><time datetime="<?= e($c[0]) ?>"><?= e($c[0]) ?></time><span><?= e($c[1]) ?></span></li>
      <?php } ?>
    </ol>
  </div>
</aside>

<?php if ($TESTIMONIALS) { ?>
<aside class="quotes paper" aria-labelledby="q-h">
  <div class="wrap">
    <h2 id="q-h"><?= t('quotes') ?></h2>
    <div class="q-grid">
      <?php foreach ($TESTIMONIALS as $q) { ?>
      <figure class="card"><blockquote><p><?= e($q['quote'] ?? '') ?></p></blockquote><figcaption><b><?= e($q['name'] ?? '') ?></b><?= !empty($q['role']) ? ' &mdash; ' . e($q['role']) : '' ?></figcaption></figure>
      <?php } ?>
    </div>
  </div>
</aside>
<?php } ?>

<section id="journey" class="sec paper">
  <div class="wrap">
    <div class="head"><span class="no">05</span><h2><?= t('h.journey') ?></h2><p><?= t('hp.journey') ?></p></div>
  </div>
  <div class="pin">
    <div class="pin-stick">
      <div class="wrap">
        <ol class="timeline">
          <li class="tl-item card"><div class="step">Origin</div><h3>Discord Communities</h3><p>Hours in servers, discovering communities and how digital spaces work.</p></li>
          <li class="tl-item card"><div class="step">Spark</div><h3>Curiosity Ignites</h3><p>Questions about bots triggered a genuine drive to understand code.</p></li>
          <li class="tl-item card"><div class="step">First Steps</div><h3>Coding Experiments</h3><p>First scripts in Python. Breaking things, fixing them, learning by doing.</p></li>
          <li class="tl-item card"><div class="step">Language</div><h3>Python</h3><p>Chose Python as home. Automation, APIs, bots &mdash; built it all here.</p></li>
          <li class="tl-item card"><div class="step">Web</div><h3>HTML, CSS &amp; PHP</h3><p>Moved into the web. Structure, style, backend logic, and databases.</p></li>
          <li class="tl-item card"><div class="step">Bots</div><h3>Discord Bot Development</h3><p>Shipped Dino Bot &amp; Loyal Bot with live websites people actually use.</p></li>
          <li class="tl-item card"><div class="step">AI</div><h3>Groq &amp; Gemini APIs</h3><p>Integrated LLMs into real tools. Not demos &mdash; shipped applications.</p></li>
          <li class="tl-item card"><div class="step">Now</div><h3>Bigger Projects</h3><p>Building larger, more complex systems across AI, web, and automation.</p></li>
        </ol>
        <div class="pin-ui" aria-hidden="true"><span class="pin-count"><b>01</b> / 08</span><span class="pin-bar"><i></i></span><span class="pin-hint"><?= t('pin.hint') ?> &rarr;</span></div>
      </div>
    </div>
  </div>
</section>

<section id="learning" class="sec dark">
  <div class="wrap">
    <div class="head"><span class="no">06</span><h2><?= t('h.learning') ?></h2><p><?= t('hp.learning') ?></p></div>
    <div class="grid g-cards">
      <article class="card"><span class="badge b-learning">Learning</span><h3>Python</h3><p>Advanced algorithms, design patterns, and complex applications.</p></article>
      <article class="card"><span class="badge b-exploring">Exploring</span><h3>Data Science</h3><p>Data analysis, pandas, numpy, and visualization techniques.</p></article>
      <article class="card"><span class="badge b-learning">Learning</span><h3>Machine Learning</h3><p>Neural networks, model training, and practical ML application.</p></article>
      <article class="card"><span class="badge b-building">Building</span><h3>AI &amp; LLMs</h3><p>Integrating large language models into real tools and bots.</p></article>
      <article class="card"><span class="badge b-building">Building</span><h3>Advanced Web Dev</h3><p>Complex full-stack projects and modern frontend patterns.</p></article>
      <article class="card"><span class="badge b-building">Building</span><h3>APIs &amp; Automation</h3><p>Data pipelines, system connections, and workflow automation.</p></article>
    </div>
  </div>
</section>

<section id="now" class="sec paper">
  <div class="wrap">
    <div class="head"><span class="no">07</span><h2><?= t('h.now') ?></h2><p><?= t('hp.now') ?></p></div>
    <div class="grid g-cards">
      <article class="card"><span class="num">01</span><h3>Student</h3><p>Studying and building at the same time. Every project extends what I learn.</p></article>
      <article class="card"><span class="num">02</span><h3>Active Discord Dev</h3><p>Maintaining Dino Bot &amp; Loyal Bot. Adding features, fixing bugs, shipping updates.</p></article>
      <article class="card"><span class="num">03</span><h3>Building This Portfolio</h3><p>This site is a live project, constantly improved as I grow as a developer.</p></article>
      <article class="card"><span class="num">04</span><h3>Learning AI &amp; ML</h3><p>ML fundamentals, neural networks, and connecting models to real projects.</p></article>
      <article class="card"><span class="num">05</span><h3>Integrating LLMs</h3><p>Using Groq and Gemini APIs in real applications &mdash; not experiments.</p></article>
      <article class="card"><span class="num">06</span><h3>Writing Python Daily</h3><p>Automation scripts, bot logic, API wrappers &mdash; Python is home.</p></article>
    </div>
    <div class="honest"><p><strong>No fake credentials.</strong> I'm a 19-year-old student who started coding out of curiosity on Discord. I don't have corporate experience &mdash; I have real projects, genuine learning, and a drive to build things that work. Every line on this site was written by me.</p></div>
  </div>
</section>

<section id="tools" class="sec dark alt">
  <div class="wrap">
    <div class="head"><span class="no">08</span><h2><?= t('h.tools') ?></h2><p><?= t('hp.tools') ?></p></div>
    <ul class="chips">
      <li class="chip">Python</li><li class="chip">VS Code</li><li class="chip">GitHub</li><li class="chip">Git</li>
      <li class="chip">Discord</li><li class="chip">PHP</li><li class="chip">JavaScript</li><li class="chip">HTML5</li>
      <li class="chip">CSS3</li><li class="chip">MySQL</li><li class="chip">Terminal</li><li class="chip">Groq AI</li>
      <li class="chip">Gemini</li><li class="chip">InfinityFree</li><li class="chip">DevTools</li><li class="chip">Notepad++</li>
    </ul>
  </div>
</section>

<figure class="big-quote" id="quote">
  <div class="ghost" aria-hidden="true">BUILD</div>
  <blockquote>Don't just use technology.<br>Build with it.</blockquote>
  <figcaption><cite>&mdash; Mohammed Moin Hamza</cite></figcaption>
</figure>

<div class="ticker tape" aria-hidden="true"><div class="ticker-track"><div class="tk"><span>Build with it</span><i></i><span>Ship it</span><i></i><span>Stay curious</span><i></i><span>Never stop</span><i></i><span>Dino</span><i></i><span>n6ble</span><i></i><span>Make things</span><i></i><span>Learn loud</span><i></i></div><div class="tk"><span>Build with it</span><i></i><span>Ship it</span><i></i><span>Stay curious</span><i></i><span>Never stop</span><i></i><span>Dino</span><i></i><span>n6ble</span><i></i><span>Make things</span><i></i><span>Learn loud</span><i></i></div></div></div>

<section id="contact" class="sec paper">
  <div class="wrap">
    <div class="head"><span class="no">09</span><h2><?= t('h.contact') ?></h2><p><?= t('hp.contact') ?></p></div>

    <div class="links">
      <a href="https://github.com/moinhamza" target="_blank" rel="noopener" class="btn btn-ghost">GitHub</a>
      <a href="https://discord.com" target="_blank" rel="noopener" class="btn btn-ghost">Discord</a>
      <a href="https://www.instagram.com/epichamzax" target="_blank" rel="noopener" class="btn btn-ghost">Instagram</a>
      <a href="https://www.snapchat.com/add/epichamzax?share_id=_AvzZhvAk4A&amp;locale=en-US" target="_blank" rel="noopener" class="btn btn-ghost">Snapchat</a>
      <a href="mailto:<?= obf(CONTACT_TO) ?>" class="btn btn-ghost">Email</a>
      <?php if (is_file(__DIR__ . '/cv.pdf')): ?><a href="cv.pdf" class="btn btn-ghost" download><?= t('cv') ?></a><?php endif; ?>
      <?php if (is_file(__DIR__ . '/contact.vcf')): ?><a href="contact.vcf" class="btn btn-ghost" download><?= t('vcard') ?></a><?php endif; ?>
    </div>

    <?php if ($sent): ?>
      <div class="notice ok" role="status">
        <strong><?= t('f.ok') ?></strong>
        <p><?= t('f.okp') ?> <a href="index.php#contact"><?= t('f.again') ?></a></p>
      </div>
    <?php else: ?>
      <?php if (isset($errors['form'])): ?>
        <div class="notice bad" role="alert"><strong><?= e($errors['form']) ?></strong></div>
      <?php endif; ?>
      <?php if ($failed): ?>
        <div class="notice bad" role="alert">
          <strong><?= t('f.bad') ?></strong>
          <p><?= t('f.badp') ?> <a href="mailto:<?= obf(CONTACT_TO) ?>"><?= obf(CONTACT_TO) ?></a>.</p>
        </div>
      <?php endif; ?>

      <form class="form" method="post" action="index.php#contact" autocomplete="on">
        <h3><?= t('f.title') ?></h3>

        <div class="field">
          <label for="f-name"><?= t('f.name') ?></label>
          <input id="f-name" type="text" name="name" placeholder="<?= e(t('f.ph.name')) ?>" required maxlength="100" autocomplete="name"
                 value="<?= e($values['name']) ?>"<?= isset($errors['name']) ? ' aria-invalid="true" aria-describedby="e-name"' : '' ?>>
          <?php if (isset($errors['name'])): ?><span class="err" id="e-name"><?= e($errors['name']) ?></span><?php endif; ?>
        </div>

        <div class="field">
          <label for="f-email"><?= t('f.email') ?></label>
          <input id="f-email" type="email" name="email" placeholder="your@email.com" required maxlength="150" autocomplete="email"
                 value="<?= e($values['email']) ?>"<?= isset($errors['email']) ? ' aria-invalid="true" aria-describedby="e-email"' : '' ?>>
          <?php if (isset($errors['email'])): ?><span class="err" id="e-email"><?= e($errors['email']) ?></span><?php endif; ?>
        </div>

        <div class="field">
          <label for="f-topic"><?= t('f.topic') ?></label>
          <select id="f-topic" name="topic">
            <?php foreach ($TOPIC_EN as $k => $en) { ?><option value="<?= e($k) ?>"<?= $values['topic'] === $k ? ' selected' : '' ?>><?= e(strip_tags(t('tp.' . $k))) ?></option><?php } ?>
          </select>
        </div>

        <div class="field">
          <label for="f-message"><?= t('f.msg') ?></label>
          <textarea id="f-message" name="message" placeholder="<?= e(t('f.ph.msg')) ?>" required minlength="5" maxlength="5000"<?= isset($errors['message']) ? ' aria-invalid="true" aria-describedby="e-message"' : '' ?>><?= e($values['message']) ?></textarea>
          <?php if (isset($errors['message'])): ?><span class="err" id="e-message"><?= e($errors['message']) ?></span><?php endif; ?>
        </div>

        <input type="hidden" name="tk" value="<?= e(form_token()) ?>">
        <div class="hp" aria-hidden="true">
          <label for="f-website">Leave this field empty</label>
          <input id="f-website" type="text" name="website" tabindex="-1" autocomplete="off">
        </div>

        <button type="submit" class="btn btn-primary"><?= t('f.send') ?></button>
        <p class="hint"><?= t('f.hint') ?></p>
      </form>
    <?php endif; ?>
  </div>
</section>

</main>

<footer class="footer">
  <div class="wrap">
    <div class="foot-logo"><img src="dino-logo.jpg" alt="" width="64" height="64" loading="lazy"><span>Mohammed Moin Hamza</span></div>
    <nav class="foot-nav" aria-label="Footer">
      <a href="#about">About</a><a href="#projects">Projects</a><a href="#contact">Contact</a><a href="motion.php">&#10022; <?= t('motion') ?></a><a href="orbit.html">Orbit</a>
      <a href="https://github.com/moinhamza" target="_blank" rel="noopener">GitHub</a>
      <a href="https://www.instagram.com/epichamzax" target="_blank" rel="noopener">Instagram</a>
      <a href="https://www.snapchat.com/add/epichamzax?share_id=_AvzZhvAk4A&amp;locale=en-US" target="_blank" rel="noopener">Snapchat</a>
      <a href="https://discord.com" target="_blank" rel="noopener">Discord</a>
      <a href="https://dino-bot.gt.tc/?i=1" target="_blank" rel="noopener">Dino Bot</a>
      <a href="#home"><?= t('top') ?> &#8593;</a>
    </nav>
    <p class="foot-copy">&copy; <?= date('Y') ?> Mohammed Moin Hamza &mdash; Dino / n6ble</p>
    <label class="chaos-lbl" for="chaos"><?= t('chaos') ?></label>
    <p class="foot-sub"><?= t('sub') ?></p>
    <p class="foot-sub"><?= t('updated') ?>: <?= e(last_updated()) ?></p>
  </div>
  <div class="foot-mega" aria-hidden="true">HAMZA</div>
</footer>
<a class="totop" href="#home" aria-label="<?= e(t('top')) ?>">&uarr;</a>
</body>
</html>
