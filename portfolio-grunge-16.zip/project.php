<?php
/* project.php — one page per project: project.php?p=<slug>. Data lives in lib.php ($PROJECTS). */
require __DIR__ . '/lib.php';
function e($v) { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }

$slug = (string) ($_GET['p'] ?? '');
if (!isset($PROJECTS[$slug])) {
    http_response_code(404);
    readfile(__DIR__ . '/404.html');
    exit;
}
$P = $PROJECTS[$slug];
$keys = array_keys($PROJECTS);
$next = $keys[(array_search($slug, $keys, true) + 1) % count($keys)];
$prev = $keys[(array_search($slug, $keys, true) - 1 + count($keys)) % count($keys)];
?>
<!DOCTYPE html>
<html lang="<?= e($L) ?>" data-theme="<?= e($THEME) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="description" content="<?= e($P['summary']) ?>">
<meta name="theme-color" content="#0A0A0A">
<meta name="color-scheme" content="dark">
<title><?= e($P['title']) ?> — Mohammed Moin Hamza</title>
<link rel="icon" type="image/jpeg" href="dino-logo.jpg">
<link rel="canonical" href="<?= e(SITE_URL) ?>/project.php?p=<?= e($slug) ?>">
<meta property="og:type" content="article">
<meta property="og:title" content="<?= e($P['title']) ?> — Mohammed Moin Hamza">
<meta property="og:description" content="<?= e($P['summary']) ?>">
<meta property="og:url" content="<?= e(SITE_URL) ?>/project.php?p=<?= e($slug) ?>">
<meta property="og:image" content="<?= e(SITE_URL) ?>/dino-logo.jpg">
<meta name="twitter:card" content="summary">
<link rel="stylesheet" href="style.css?v=18">
<?= site_js() ?>
</head>
<body data-prev="project.php?p=<?= e($prev) ?>" data-next="project.php?p=<?= e($next) ?>" data-prev-t="<?= e($PROJECTS[$prev]['title']) ?>" data-next-t="<?= e($PROJECTS[$next]['title']) ?>">
<a class="skip" href="#main"><?= t('skip') ?></a>

<header class="nav">
  <a href="index.php" class="logo"><img src="dino-logo.jpg" alt="" width="58" height="58"><span>Hamza</span></a>
  <nav class="nav-links" aria-label="Primary">
    <a href="index.php#about"><?= t('n.about') ?></a><a href="index.php#skills"><?= t('n.skills') ?></a><a href="index.php#projects" aria-current="page"><?= t('n.projects') ?></a><a href="index.php#contact"><?= t('n.contact') ?></a>
  </nav>
  <div class="nav-clock" data-clock="mini" aria-hidden="true"><b class="nc-time">--:--:--</b><span class="nc-date">&nbsp;</span></div>
  <?= theme_picker() ?>
  <label class="nav-tool theme-lbl" for="th-menu" title="<?= e(t('themes')) ?>"><span class="vh"><?= t('theme') ?></span><i aria-hidden="true"></i></label>
  <a class="nav-tool nav-lang" href="<?= lang_url() ?>" lang="<?= $L === 'ja' ? 'en' : 'ja' ?>" hreflang="<?= $L === 'ja' ? 'en' : 'ja' ?>"><?= $L === 'ja' ? 'EN' : '日本語' ?></a>
  <a href="index.php#contact" class="nav-cta"><?= t('n.talk') ?></a>
</header>

<main id="main">
  <section class="sec dark pd">
    <div class="wrap">
      <a class="pd-back" href="index.php#projects">&larr; <?= t('p.back') ?></a>
      <p class="pd-kind"><span class="feat-label"><?= e($P['kind']) ?></span><?php if ($P['status'] !== '') { ?> <span class="live-badge static"><?= e($P['status']) ?></span><?php } ?></p>
      <h1 class="pd-title"><?= e($P['title']) ?></h1>
      <p class="pd-sum"><?= e($P['summary']) ?></p>
      <div class="btn-row">
        <?php foreach ($P['links'] as $i => $l) { ?>
          <a href="<?= e($l[1]) ?>" target="_blank" rel="noopener" class="btn <?= $i === 0 ? 'btn-primary' : 'btn-ghost' ?>"><?= e($l[0]) ?> &#8599;</a>
        <?php } ?>
      </div>
      <?php
        $pu = SITE_URL . '/project.php?p=' . $slug;
        $pt = $P['title'] . ' - ' . $P['kind'];
      ?>
      <p class="share"><span><?= t('share') ?>:</span>
        <a href="https://wa.me/?text=<?= rawurlencode($pt . ' ' . $pu) ?>" target="_blank" rel="noopener">WhatsApp</a>
        <a href="https://t.me/share/url?url=<?= rawurlencode($pu) ?>&amp;text=<?= rawurlencode($pt) ?>" target="_blank" rel="noopener">Telegram</a>
        <a href="https://twitter.com/intent/tweet?text=<?= rawurlencode($pt) ?>&amp;url=<?= rawurlencode($pu) ?>" target="_blank" rel="noopener">X</a>
        <a href="mailto:?subject=<?= rawurlencode($pt) ?>&amp;body=<?= rawurlencode($pu) ?>">Email</a>
      </p>
    </div>
  </section>

  <section class="sec paper pd-body">
    <div class="wrap pd-grid">
      <div>
        <h2><?= t('p.what') ?></h2>
        <ul class="pd-list">
          <?php foreach ($P['points'] as $pt) { ?><li><?= e($pt) ?></li><?php } ?>
        </ul>
      </div>
      <div>
        <h2><?= t('p.stack') ?></h2>
        <div class="tags"><?php foreach ($P['tags'] as $tg) { ?><span class="tag"><?= e($tg) ?></span><?php } ?></div>
        <?php if ($P['shots']) { ?>
          <h2 class="pd-h2"><?= t('p.shots') ?></h2>
          <div class="shots">
            <?php foreach ($P['shots'] as $sh) { ?><img src="<?= e($sh[0]) ?>" alt="<?= e($sh[1]) ?>" width="640" height="400" loading="lazy"><?php } ?>
          </div>
        <?php } ?>
      </div>
    </div>
  </section>

  <section class="sec dark pd-next">
    <div class="wrap">
      <a class="btn btn-primary" href="project.php?p=<?= e($next) ?>"><?= t('p.next') ?>: <?= e($PROJECTS[$next]['title']) ?> &rarr;</a>
    </div>
  </section>
</main>

<footer class="footer">
  <div class="wrap">
    <nav class="foot-nav" aria-label="Footer">
      <a href="index.php"><?= t('p.back') ?></a><a href="index.php#contact"><?= t('n.contact') ?></a><a href="motion.php">&#10022; <?= t('motion') ?></a>
      <a href="https://github.com/moinhamza" target="_blank" rel="noopener">GitHub</a>
    </nav>
    <p class="foot-sub"><?= t('updated') ?>: <?= e(last_updated()) ?></p>
    <p class="foot-copy">&copy; <?= date('Y') ?> Mohammed Moin Hamza &mdash; Dino / n6ble</p>
  </div>
  <div class="foot-mega" aria-hidden="true">HAMZA</div>
</footer>
</body>
</html>
