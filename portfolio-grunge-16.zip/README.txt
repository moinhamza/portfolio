UPLOAD (InfinityFree)
1. File Manager (or FTP) -> open htdocs/ and delete the default index2.html if present.
2. Upload everything in this folder INTO htdocs/ (index.php, orbit.html, 404.html, style.css, dino-logo.jpg, loyal-logo.png, .htaccess). Keep .htaccess's leading dot.
3. Visit your domain (hard-refresh or clear the browser cache once). Test: nav links, Orbit page, /nonexistent (404), and the contact form.
4. Contact form: CONTACT_TO / MAIL_FROM are at the top of index.php. MAIL_FROM should be an address on your own domain.
5. If you see a 500 error, delete .htaccess and retry.

NOT RETAINED (no-JavaScript rule)
- Scroll animations are back, still with NO JavaScript: they are pure CSS scroll-driven animations (Chrome/Edge/Safari 26+). Browsers without support simply show the static page, and the tickers fall back to a normal looping marquee. Page-to-page transitions use CSS view transitions the same way. Everything is switched off for visitors with 'reduce motion' enabled.
- Fixed bottom mobile tab bar replaced by a big two-row nav: logo row + horizontally scrollable link row (pure CSS).
- Nothing else depended on JavaScript. Text mentioning JavaScript is just skill/project copy.

OPTIONAL SCRIPT (index.php <head>)
- A ~30-line fallback script reveals sections on scroll in browsers WITHOUT CSS scroll-driven animations (Firefox, older Safari). It never runs in supporting browsers, and the site works without it. Delete the <script> block in index.php's head to return to zero JavaScript.

==================== v10: NEW FEATURES + INFINITYFREE NOTES ====================
New files: lib.php, project.php, stats.json, cv.pdf, loyal-logo.webp. Upload them into htdocs/ with the rest.

INFINITYFREE LIMITS THIS BUILD IS DESIGNED AROUND
- Hits: ~50,000 requests/day. Every file counts (page, CSS, each image). Project pages add no extra images by default; keep screenshots few and small (WebP, under ~150 KB).
- Files: 30,000 files/folders max, 10 MB per file. Fine here.
- Browser-check security: only real browsers get through. Bots, cURL and other servers can't call your site, so your Discord bot cannot PUSH stats to it, and social crawlers may not be able to read the Open Graph tags (link previews can fail on the free subdomain).
- Outgoing requests from PHP can be slow or blocked, and there are no cron jobs. So bot stats are read from stats.json (edit by hand), and optionally pulled from STATS_URL in lib.php (a public JSON file your bot writes somewhere else, e.g. a GitHub gist/raw file). Pulls use a 2 s timeout and a 10-minute cache, and fall back to stats.json if they fail.
- No file hosting / API hosting allowed: cv.pdf is fine as part of a personal site; don't use the host as a download server.

WHERE THINGS ARE
- Typewriter line, counting stats, hover tear, light/dark toggle: pure CSS (needs a modern browser; others just see the plain version).
- Theme choice: see v14 below (multi-theme switcher).
- Hide-on-scroll nav: ~5-line optional script in index.php <head>. Delete it to stay at zero JS for this feature.
- Sticky stacking: only the big quote is pinned (the contact section slides over it) on larger screens, because sticky sections taller than the screen would cut content off.
- EN/Japanese: see v14 below (replaced the old Hinglish version).
- Project pages: project.php?p=<slug>. Edit $PROJECTS in lib.php; add screenshots as ['file.webp','alt text'] in 'shots'.
- Changelog strip: edit $CHANGELOG in lib.php (two entries are examples based on this site's own files; edit or replace them).
- Testimonials: not added (no real quotes to use). Don't invent them.
- cv.pdf: one page generated from the facts on this site. Replace it with your own file anytime (same name). The button hides itself if cv.pdf is missing.
- Print: compact version (nav, forms, motion, decorative sections hidden). Not guaranteed to fit one page.
- WebP: loyal-logo.webp is used with PNG fallback. You can delete the PNG only if you also remove the fallback <img> in index.php.
- Not tested on a live PHP server (no PHP here). If you see a 500 error: first delete .htaccess, then check lib.php.

==================== v11: MORE FEATURES ====================
- Project filter (All / Python / PHP / AI / JavaScript): pure CSS, no extra requests. Tags are the data-t attributes on the cards in index.php.
- "Make it worse" (footer): CSS-only chaos mode (heavier grain, tilted cards, glitchy headings, harsher images).
- Contact form protection: a signed timestamp in the form (rejects instant bots and replays) + a per-visitor rate limit (3 per hour, 20 s apart) stored in tiny files under .rl/ (created automatically; if the host blocks writing, the limit is simply skipped). If many visitors share one IP on the host, raise the 3 in lib.php (rate_limited).
- SEO pack: Person JSON-LD in index.php, robots.txt, sitemap.xml, humans.txt. InfinityFree's browser check may stop some crawlers anyway; this can't hurt.
- 404 page: glitching code plus quick links.
New files: robots.txt, sitemap.xml, humans.txt. Upload them to htdocs/ with the rest.

==================== v12: EVEN MORE ====================
- Contact form: new "Topic" dropdown (Project idea / Discord bot / Collab / Just saying hi). The topic is added to the email subject and body.
- "Save contact" button: contact.vcf (name, email, site, GitHub). Edit the file to change what gets saved.
- Install-to-home-screen polish: site.webmanifest + icon-192.png / icon-512.png (cropped from dino-logo.jpg).
- Share buttons on project pages: WhatsApp, Telegram, X, Email (plain links, no scripts, no tracking).
- Back-to-top button: fades in after scrolling (pure CSS, needs a modern browser; otherwise hidden).
- Footer shows "Last updated" automatically from the site files' modified dates.
- Accessibility: high-contrast (prefers-contrast) and forced-colors styles.
- Skipped on purpose: QR code (no generator available here), guestbook, live Discord status, GitHub stats (database writes / outside requests are blocked or unreliable on free hosting).
New files: contact.vcf, site.webmanifest, icon-192.png, icon-512.png.

==================== v13: MORE ====================
- Theme choice is now remembered: the checkbox still works with no JavaScript, and the optional inline script (site_js() in lib.php, shared with the hide-on-scroll nav) saves it in a cookie so every page opens in your last choice.
- Testimonials: the section exists but stays hidden. Add REAL quotes to $TESTIMONIALS in lib.php ('quote', 'name', optional 'role') and it appears automatically.
- Email address is written as HTML entities (readable by browsers, harder for simple scrapers).
- Crosshair cursor on desktop (normal pointer on links and form fields).
- Printing / saving as PDF now starts with your name and site URL.
- This Portfolio project page lists the new features.
Note: lib.php now holds the only inline script, so index.php and project.php both call site_js() in the <head>.

==================== v14: JAPANESE + MULTI-THEME SWITCHER ====================
- Hinglish is gone, Japanese replaces it. Nav button "日本語" / "EN" (?lang=ja / ?lang=en), remembered with a cookie. The old file i18n-hi.php is replaced by i18n-ja.php: delete i18n-hi.php from htdocs/ if it is still there and upload i18n-ja.php. Short UI text is in lib.php ($I18N['ja']); long copy is in i18n-ja.php ('exact English text' => '日本語'); anything not listed stays English. Visitors with an old lang=hi cookie simply see English.
- Japanese typography: CJK fallback fonts, heavier weight, looser line height and phrase-aware line breaks (end of style.css's THEMES section). The typewriter line counts Japanese characters as two columns.
- Theme button (half-circle icon in the nav) opens a panel with 7 themes: Grunge (default), Paper (light), Toxic, Cyber, Ember, Ocean, Sakura (light). It replaces the old light/dark toggle: Paper is the old light mode. Switching is instant and needs no JavaScript (hidden radio inputs + :has()); the optional script in lib.php only saves the choice in a cookie ('theme'; old 'light' / 'dark' values still work). Browsers without :has() show the saved theme but can't switch live.
- Add a theme: one entry in $THEMES (lib.php), a 'th.<id>' label in both language tables, and one line in each of the two THEMES lists in style.css.
- Project thumbnails (the small SVG sketches) now follow the theme colours.
- 404.html and orbit.html are static files and keep the default Grunge look.
Files changed: lib.php, index.php, project.php, style.css, README.txt. New: i18n-ja.php. Removed: i18n-hi.php.

==================== v15: LIVE CLOCK + MOTION ENGINE + BUG FIXES ====================
New file: fx.js (upload next to index.php). Changed: index.php, project.php, lib.php, i18n-ja.php, style.css, .htaccess, orbit.html, 404.html.
The old "no JavaScript" rule is relaxed on purpose: everything still works with scripts off (and for visitors who prefer reduced motion),
the script only adds things. If fx.js is missing the site simply looks like v14.

NEW
- Live digital clock: big flip-tile clock under the hero (time, weekday, full date, timezone, day-progress bar, 12H/24H button that is remembered),
  a compact one in the nav (wide screens) and a chip in the hero (phones). Uses the visitor's own clock/timezone. Japanese page shows Japanese weekday/date.
- Scroll motion engine (fx.js): split-text headline reveals, staggered 3D reveals, count-up numbers, hero that splits apart and drifts away,
  parallax, pinned horizontal "Journey" (desktop; normal grid on phones), marquee that speeds up/reverses with your scrolling, velocity skew,
  tilt + glare cards, magnetic buttons, follower cursor (mouse only), eased anchor scrolling, side rail that tracks the current section,
  footer name that fills red as you reach the bottom, real film-grain noise.
- Everything above is switched off for "reduce motion" visitors (html.fx is never set), and in print.
- Edit the reveal list in fx.js (reveal() -> MAP) to change which element gets which effect.

BUGS FIXED
- Desktop nav: "Let's Talk" sat in front of the links and Tools/Contact were pushed off-screen. Nav now has explicit order; single-row layout only from 104rem.
- Phone nav: the CTA wrapped into a stray red strip. It is hidden on phones (Contact is in the link row) and the header is more compact.
- Stats showed "0+" with reduced motion / printing. Now they always show the real number.
- Hero name could break mid-word ("MOHAMM/ED") on computers without the Impact font. fx.js now auto-fits it.
- Contact form "Topic" dropdown had an invisible border.
- Invalid CSS fallback var(--d,s) removed with the old IntersectionObserver fallback (fx.js replaces it).
- Copy that said "no JavaScript" updated (English + Japanese).
- .htaccess: fx.js is cached/compressed; lib.php, i18n-ja.php and README.txt are no longer downloadable.
Not tested on a live PHP server (no PHP here). The pages were rendered to HTML and tested in Chromium (desktop + phone widths, Japanese, Sakura/Grunge themes,
reduced motion, scripts off). If you see a 500 error: delete .htaccess first, then check lib.php.

==================== v16: MORE FEATURES (all in fx.js + style.css, no PHP changes) ====================
- Command palette: press Ctrl/Cmd+K or "/" (or click the Ctrl K button, bottom-left on desktop). Type to jump to any section or project,
  switch theme, switch language, toggle the 12/24h clock, copy your email, download the CV, toggle chaos mode, share the page. Fully keyboard driven.
- Click (or press Enter on) a handle tag (Dino / n6ble / zenthorn) to copy it; a toast confirms.
- Time-aware greeting in the clock panel (Good morning / afternoon / evening / night, Japanese too).
- Contact form: live character counter, draft saved in the visitor's own browser (cleared after a successful send), "Sending..." state on submit.
- Konami code (up up down down left right left right B A) toggles "make it worse" chaos mode with confetti.
- Cache-busting bumped to ?v=16 (style.css and fx.js).

==================== v17: MORE FEATURES FOR DESKTOP AND PHONES (fx.js + style.css, small PHP touches) ====================
Cache-busting is now ?v=17. Changed: fx.js, style.css, lib.php, project.php, index.php, 404.html, orbit.html, i18n-ja.php, README.txt. No new files.

BOTH DESKTOP AND PHONE
- Reading-progress bar along the top edge (red, grows as you scroll).
- Command menu has many more actions: next / random theme, text size (Normal > Large > Extra large), calm mode, copy page link,
  copy link to the current section, print / save as PDF, save contact card, open Orbit, install as app.
- Text size: Large (112.5%) and Extra large (125%), remembered in the visitor's browser and applied before first paint (no flash).
- Calm mode: switches all motion effects off for that visitor (the page reloads once). Separate from the system "reduce motion" setting.
- Tap / click a section number (01, 02, ...) to copy a link straight to that section.
- Contact: "Copy email" button next to Email, the message box grows as you type, Ctrl/Cmd + Enter sends the form.
- Install as app: Chrome/Edge/Android show "Install as app" in the menu when the browser offers it; iPhone/iPad get a short how-to toast.
- "You are offline" / "Back online" toasts (useful once the site is installed).
- Project pages: previous / next project (see below).

DESKTOP
- Keyboard shortcuts: J / K next / previous section, 1-9 jump to a nav item, T next theme, G top, Shift+G bottom, ? shows a help sheet,
  Left / Right arrows move between projects on project pages. Ctrl/Cmd+K or / still opens the menu. Shortcuts are ignored while typing in a field.
- "Keyboard shortcuts" entry in the command menu.

PHONE
- Menu button (bottom left, square with a hamburger) opens the command menu. It is now a bottom sheet: drag the handle down to close it,
  larger tap targets, and the keyboard only appears when you tap the search field.
- The scrolling link row at the top follows the section you are reading (the current link is kept centred).
- Project pages: swipe left / right to go to the next / previous project (ignored near the screen edges so the system back-swipe still works,
  and inside the screenshots / form fields). A small hint line appears under the "Next project" button.
- Light haptic taps (where the phone allows it) when copying, switching theme, opening the menu and swiping between projects.

NOTES
- Nothing new needs the server; everything degrades gracefully if fx.js is missing or scripts are off.
- Add or remove palette actions in extraPalette() in fx.js; add shortcut keys in shortcuts(). Texts for both languages live in the I18 table at the top of the v16 section.
- Not tested on a live PHP server (no PHP here). If you see a 500 error: delete .htaccess first, then check lib.php.

==================== v18: MOTION EDITION (new file: motion.html) ====================
A second, premium "motion-first" version of the site that sits NEXT TO the grunge one. Nothing was replaced.
- Buttons: "Motion Edition" in the hero button row, in the footer links (home + project pages) and in the Ctrl/Cmd+K menu / mobile menu sheet.
  motion.html has its own "Classic site" buttons (top bar, mobile menu, footer) that go back to index.php.
- motion.html is one static file (no PHP, no build step, no libraries), so it uploads to htdocs/ like everything else. Content comes from the real site copy.
- Sequence: hero intro (background > label > split headline > text > buttons) with slow gradient orbs and a small particle field,
  statement that lights up word by word, featured Dino Bot with clip-mask reveal, interactive feature tabs with animated text swap,
  sticky "how it started" story (large screens; normal stacked list on phones and short screens), accordion capabilities,
  six project cards with pointer tilt, contact, footer. Scroll progress bar, nav that hides on scroll, full-screen animated menu,
  page-transition veil when leaving to the classic site or a project page (the back button still works).
- Desktop only: custom cursor ring, magnetic buttons, card tilt. Phones: none of those, fewer particles, no connecting lines.
- "Reduce motion" (system setting): everything is shown immediately with no animation. If scripts fail, content is still visible.
- Uses Google Fonts (Syne + Inter) with system fallbacks. Edit the colours at the top of motion.html (:root).
- Smooth-scroll libraries were left out on purpose: native scrolling stays untouched.
Also changed: index.php, project.php, lib.php (label), fx.js (menu entry), sitemap.xml, README.txt.

HTTPS NOTE: the browser warning in your screenshots ("not secure") is because the site is served over http://. In InfinityFree's control panel
(Free SSL Certificates), install a free certificate for moinhamza.gt.tc, then change SITE_URL in lib.php and the URLs in sitemap.xml to https://.
Install-as-app and the service features in the menu only work on https.

==================== v19: MOTION EDITION, UPGRADE + BUG FIXES (motion.html only) ====================
BUGS FIXED
- The Dino Bot image never appeared (the clip-mask hid it from the scroll observer). Now it reveals properly.
- Magnetic buttons broke their own fill/border while hovered (a CSS variable name clashed with the text-colour token).
- A white "toast" pill peeked out at the bottom edge of every screen.
- The intro label overflowed the screen on phones (its words could not wrap). Fixed.
- The "Classic site" button wrapped onto two lines on phones and crowded the header. Fixed.
- Tall elements and short landscape screens could leave content un-revealed. Reveal trigger is now size-independent.
- The cursor label stayed stuck on screen after scrolling away from a card. Fixed.
- Menu: the page behind it was still tabbable. It is now inert while the menu is open and Tab is trapped inside; Esc closes it.
- Closed accordion text was still readable by screen readers. Now hidden until opened.
- The particle canvas was re-created on every phone address-bar resize (jank). Now only on width changes.
NEW
- Accent colours: the round colour button in the top bar cycles Violet / Ember / Aurora / Solar, remembered per visitor, cross-faded where the browser supports it.
- Hero reacts to the pointer on desktop: spotlight, parallax orbs, particles that scatter from the cursor and connect to it.
- Cursor shows labels ("View", "Open") over project cards and the main case-study button.
- Scrolling marquee of skills between the intro and the Dino Bot section (pauses on hover and when off-screen).
- Dino Bot frame tilts in 3D with the pointer and has orbiting tech chips.
- Project cards have their own colour and an art disc that spins on hover.
- Section rail on wide screens (clickable dots with labels) and the top nav highlights the current section.
- Giant HAMZA wordmark in the footer that rises in letter by letter.
- Open Graph tags for nicer link previews.
Tested in Chromium at 320, 360, 390, 768, 1024, 1440 and 800x360 landscape: no sideways scrolling, no console errors, all content visible with
scripts off and with "reduce motion" on.

==================== v20: THE BIG ONE - MOTION EDITION GROWS UP ====================
UPLOAD EVERYTHING in this zip (same folder as index.php). New files: motion.php, motion-project.php, motion-contact.php, motion-lib.php,
motion-i18n.php, motion.css, motion.js, contact-config.php, sw.js, offline.html, dino-logo.webp, dino-logo-192.webp, shots/ (empty folder + README).
motion.html is now just a redirect to motion.php (old links keep working). Changed: index.php, project.php, lib.php, fx.js, style.css, .htaccess,
site.webmanifest, sitemap.xml, i18n-ja.php, 404.html, orbit.html.

WHAT IS NEW
1. HTTPS: nothing to code. In InfinityFree > Free SSL Certificates install a certificate for moinhamza.gt.tc, check https://moinhamza.gt.tc opens
   without a warning, then (a) remove the "# " from the 6 commented lines at the bottom of .htaccess, (b) change SITE_URL in lib.php and the URLs in
   sitemap.xml to https://. Until then the offline worker and install-as-app stay inactive (browsers require https).
2. Real screenshots / clips: drop files into shots/ named after the project (see shots/README.txt). They appear on the Motion project cards and case pages.
3. Motion case-study pages: motion-project.php?p=<slug>. Cards open a full-screen preview first (tap the card), then "Open case study".
   Arrow keys (desktop) and swipe left/right (phones) move between projects. Text comes from $PROJECTS in lib.php, so edit it in one place.
4. Edition choice: first-time visitors on the classic home page get a small "Classic or Motion?" card. The menu (Ctrl/Cmd+K or the menu button) has
   "Make Motion Edition my default" / "Make Classic my default". Visitors who chose Motion are sent to motion.php when they open the home page
   (never when they follow the "Classic site" buttons, a language link, or come from another page of this site).
5. Live Dino Bot stats: the numbers under the Dino Bot section come from bot_stats() (stats.json) automatically and count up on scroll.
6. Interactive demo: a simulated Discord chat (/help, /ask, /moderation, /utility, /image, /ping). It is labelled as a simulation and is not connected to the bot.
7. Card-to-fullscreen project preview (described above).
8. Sound: a small button in the top bar (desktop/tablet) toggles very quiet ticks. Off by default, remembered.
9. Time of day: hero lighting tints with the visitor's local time (dawn / day / dusk / night) and a greeting with their local time.
10. Testimonials: the "Kind words" section appears automatically as soon as $TESTIMONIALS in lib.php contains real quotes. It is empty on purpose:
    no invented quotes. Format: ['quote' => '...', 'name' => '...', 'role' => '...'].
11. "Right now" section (same facts as the classic Now section).
12. Contact form inside the Motion Edition: same protections as the classic form (hidden trap field, signed timer, per-visitor rate limit). Sends through
    motion-contact.php without leaving the page; works with plain form posting when JavaScript is off. The address lives in contact-config.php.
13. CV panel: slide-out preview of cv.pdf (loaded only when opened). Browsers that cannot show PDFs inline show a download button instead.
14. Offline worker (sw.js + offline.html): after one visit over https, pages and files open without a connection. Bump V in sw.js to force a refresh.
15. English / Japanese for the Motion Edition: button in the top bar. All text is in motion-i18n.php (edit the right-hand side).
16. Speed: dino-logo.webp (about 80% smaller than the JPG) is used automatically with the JPG as fallback. New .htaccess lines cache clips and scripts.
17. Surprises: type "dino" anywhere, or enter the Konami code.
NOT DONE ON PURPOSE: a visit counter (needs server-side writing and privacy notes; say if you want it).

TESTED: every PHP template was rendered offline with a test interpreter (no PHP was available here) and the output checked in Chromium on desktop and phone sizes in
English and Japanese; the real PHP files themselves were not executed. If a page shows a blank screen: temporarily rename .htaccess, then check the PHP error log.
