<?php
/* motion-contact.php: receives the Motion Edition contact form.
   Called by fetch() (answers JSON) or by a plain form post when JavaScript is off (redirects back to motion.php).
   Uses the same protections as index.php: honeypot, signed timestamp, per-visitor rate limit. */
require __DIR__ . '/motion-lib.php';

function mc_line($v) { return trim(preg_replace('/[\x00-\x1F\x7F]+/', ' ', (string) $v)); }
function mc_len($v)  { return function_exists('mb_strlen') ? mb_strlen($v, 'UTF-8') : strlen($v); }

$wantsJson = (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
          || (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'fetch');

function mc_done($ok, $msg = '') {
    global $wantsJson;
    if ($wantsJson) {
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        echo json_encode(['ok' => $ok, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    } else {
        header('Location: motion.php?' . ($ok ? 'sent=1' : 'err=1') . '#contact', true, 303);
    }
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { header('Location: motion.php#contact', true, 303); exit; }

$name  = mc_line($_POST['name'] ?? '');
$email = mc_line($_POST['email'] ?? '');
$msg   = trim(str_replace("\r\n", "\n", (string) ($_POST['message'] ?? '')));
$tp    = (string) ($_POST['topic'] ?? '');
$topic = isset($TOPIC_EN[$tp]) ? $tp : 'project';

if (trim((string) ($_POST['website'] ?? '')) !== '') { mc_done(true); }           // honeypot: pretend success to bots

if ($name === '' || mc_len($name) > 100)                                            { mc_done(false, strip_tags(t('e.name'))); }
if ($email === '' || mc_len($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL)) { mc_done(false, strip_tags(t('e.email'))); }
if (mc_len($msg) < 5 || mc_len($msg) > 5000)                                        { mc_done(false, strip_tags(t('e.msg'))); }
if (!token_ok($_POST['tk'] ?? ''))                                                  { mc_done(false, strip_tags(t('e.token'))); }
if (rate_limited())                                                                 { mc_done(false, strip_tags(t('e.rate'))); }

$subject = '=?UTF-8?B?' . base64_encode('[Portfolio] ' . $TOPIC_EN[$topic] . ' - message from ' . $name) . '?=';
$body    = "Topic: {$TOPIC_EN[$topic]}\nName: $name\nEmail: $email\nVia: Motion Edition\n\n$msg\n";
$headers = "From: Portfolio <" . MAIL_FROM . ">\r\n"
         . "Reply-To: $email\r\n"
         . "MIME-Version: 1.0\r\n"
         . "Content-Type: text/plain; charset=UTF-8\r\n";

if (@mail(CONTACT_TO, $subject, $body, $headers)) { rate_record(); mc_done(true); }
mc_done(false, strip_tags(t('f.bad')));
