(function () {
  'use strict';
  var D = document, H = D.documentElement, W = window;
  var RM = H.classList.contains('rm');
  var FINE = false, SMALL = false;
  try { FINE = matchMedia('(hover:hover) and (pointer:fine)').matches; SMALL = matchMedia('(max-width:55.99rem)').matches; } catch (e) {}
  var HAS_IO = 'IntersectionObserver' in W;
  function $(s, c) { return (c || D).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || D).querySelectorAll(s)); }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  var PTR = { x: -999, y: -999 }, ACC = [124, 92, 255], ACCB = [45, 168, 255];
  function readAcc() {
    function hex(v, d) { v = (v || '').trim(); var m = /^#([0-9a-f]{6})$/i.exec(v); return m ? [parseInt(m[1].slice(0, 2), 16), parseInt(m[1].slice(2, 4), 16), parseInt(m[1].slice(4), 16)] : d; }
    var cs = getComputedStyle(H); ACC = hex(cs.getPropertyValue('--a'), ACC); ACCB = hex(cs.getPropertyValue('--b'), ACCB);
  }
  readAcc();
  var MI = W.MI18N || {};
  function S(k, d) { return MI[k] || d; }
  var LANG = H.getAttribute('lang') || 'en';
  function safe(f, n) { try { f(); } catch (e) { if (W.console) console.warn('[motion] ' + n, e); } }

  /* ----- never leave the page hidden behind an intro that failed ----- */
  function ready() { H.classList.add('ready'); }
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', ready); else ready();
  setTimeout(ready, 1500);
  var year = $('#yr'); if (year) year.textContent = new Date().getFullYear();

  $$('[data-d]').forEach(function (e) { e.style.setProperty('--d', e.getAttribute('data-d')); });

  /* ----- split text into masked words / characters ----- */
  function splitWords(el) {
    var idx = 0;
    (function walk(node) {
      Array.prototype.slice.call(node.childNodes).forEach(function (k) {
        if (k.nodeType === 3) {
          var frag = D.createDocumentFragment();
          k.nodeValue.split(/(\s+)/).forEach(function (p) {
            if (!p) return;
            if (/^\s+$/.test(p)) { frag.appendChild(D.createTextNode(' ')); return; }
            var w = D.createElement('span'), i = D.createElement('span');
            w.className = 'w'; w.setAttribute('aria-hidden', 'true'); i.className = 'wi'; i.style.setProperty('--i', idx++); i.textContent = p; w.appendChild(i); frag.appendChild(w);
          });
          node.replaceChild(frag, k);
        } else if (k.nodeType === 1 && !k.classList.contains('w')) { walk(k); }
      });
    })(el);
    el.setAttribute('aria-label', el.textContent.replace(/\s+/g, ' ').trim());
  }
  function splitChars(el) {
    var t = el.textContent, n = 0, cs = D.createElement('span'); el.textContent = ''; cs.className = 'cs'; el.appendChild(cs);
    var sr = D.createElement('span'); sr.className = 'vh'; sr.textContent = t; cs.appendChild(sr);
    t.split(' ').forEach(function (word, wi) {
      if (wi) cs.appendChild(D.createTextNode(' '));
      var cw = D.createElement('span'); cw.className = 'cw'; cw.setAttribute('aria-hidden', 'true');
      word.split('').forEach(function (c) { var x = D.createElement('span'); x.className = 'ch'; x.style.setProperty('--i', n++); x.textContent = c; cw.appendChild(x); });
      cs.appendChild(cw);
    });
  }
  if (!RM) {
    $$('[data-split]').forEach(function (el) { safe(function () { splitWords(el); }, 'split'); });
    $$('[data-chars], [data-mark]').forEach(function (el) { safe(function () { splitChars(el); }, 'chars'); });
    $$('[data-mark]').forEach(function (el) { el.classList.add('chars'); });
  }

  /* ----- reveals (IntersectionObserver); hero starts with the page ----- */
  function startHero() { $$('.hero .split, .hero .chars, .phero .split, .phero .chars').forEach(function (e) { e.classList.add('in'); }); }
  if (!RM && HAS_IO) {
    ready(); setTimeout(startHero, 250);
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (en) {
        if (!en.isIntersecting) return;
        io.unobserve(en.target);
        en.target.classList.add('in');
      });
    }, { threshold: 0.01, rootMargin: '0px 0px -8% 0px' });
    $$('[data-r], [data-r-clip], .split, .chars, [data-mark]').forEach(function (el) { if (!el.closest('.hero, .phero')) io.observe(el); });
    /* safety net: anything still hidden after 6 s becomes visible */
    setTimeout(function () { $$('[data-r], [data-r-clip], .split, .chars').forEach(function (e) { e.classList.add('in'); }); }, 6000);
  } else {
    $$('[data-r], [data-r-clip], .split, .chars, [data-mark]').forEach(function (e) { e.classList.add('in'); });
  }

  /* ----- count-up numbers ----- */
  safe(function () {
    var items = $$('[data-count]');
    if (RM || !HAS_IO) return;
    var co = new IntersectionObserver(function (es) {
      es.forEach(function (en) {
        if (!en.isIntersecting) return; co.unobserve(en.target);
        var el = en.target, to = +el.getAttribute('data-count'), suf = el.getAttribute('data-suf') || '', t0 = 0;
        (function s(now) { if (!t0) t0 = now; var k = clamp((now - t0) / 1400, 0, 1); el.textContent = Math.round(to * (1 - Math.pow(1 - k, 4))) + suf; if (k < 1) requestAnimationFrame(s); })(performance.now());
      });
    }, { threshold: 0.8 });
    items.forEach(function (el) { co.observe(el); });
  }, 'count');

  /* ----- scroll engine: progress bar, nav hide, statement words, drifting word, story ----- */
  var words = [], stSec = $('.state'), bigword = $('[data-drift]'), story = $('#story'), rings = {};
  (function prep() {
    var p = $('[data-words]');
    if (p && !RM) {
      var txt = [];
      (function walk(n) { Array.prototype.slice.call(n.childNodes).forEach(function (k) {
        if (k.nodeType === 3) { var f = D.createDocumentFragment(); k.nodeValue.split(/(\s+)/).forEach(function (w) { if (!w) return; if (/^\s+$/.test(w)) f.appendChild(D.createTextNode(' ')); else { var s = D.createElement('span'); s.className = 'sw'; s.textContent = w; f.appendChild(s); words.push(s); } }); n.replaceChild(f, k); }
      }); })(p);
    }
    ['r1', 'r2', 'r3', 'r4', 'r5'].forEach(function (id) { rings[id] = $('#' + id); });
  })();

  var bar = $('.prog i'), rail = $('.rail'), lastY = 0, ticking = false, step = -1;
  var sticky = function () { try { return matchMedia('(min-width:56rem) and (min-height:34rem)').matches; } catch (e) { return false; } };

  function frame() {
    ticking = false;
    var y = W.pageYOffset || 0, vh = W.innerHeight, max = Math.max(1, H.scrollHeight - vh);
    if (bar) bar.style.scale = clamp(y / max, 0, 1).toFixed(4) + ' 1';
    if (!H.classList.contains('menu-open')) {
      if (y > lastY + 6 && y > 300) H.classList.add('hide'); else if (y < lastY - 6 || y < 300) H.classList.remove('hide');
    }
    lastY = y;
    if (rail) rail.classList.toggle('on', y > vh * 0.6);
    if (RM) return;
    if (words.length && stSec) {
      var r = stSec.getBoundingClientRect(), p = clamp((vh * 0.8 - r.top - 60) / (r.height * 0.55), 0, 1), n = Math.round(p * words.length);
      for (var i = 0; i < words.length; i++) { var on = i < n; if (words[i].classList.contains('lit') !== on) words[i].classList.toggle('lit', on); }
    }
    if (bigword && !SMALL) {
      var b = bigword.parentNode.getBoundingClientRect();
      bigword.style.transform = 'translate3d(' + ((b.top / vh) * -14).toFixed(2) + '%,0,0)';
    }
    if (story && sticky()) {
      var sr = story.getBoundingClientRect(), sp = clamp(-sr.top / (sr.height - vh), 0, 1), s = clamp(Math.floor(sp * 4), 0, 3);
      if (s !== step) { step = s; story.setAttribute('data-step', s); }
      var rot = sp * 360;
      if (rings.r1) rings.r1.style.transform = 'rotate(' + (-rot * 0.5).toFixed(1) + 'deg)';
      if (rings.r3) rings.r3.style.transform = 'rotate(' + (rot * 1.5).toFixed(1) + 'deg)';
      if (rings.r2) rings.r2.style.transform = 'scale(' + (0.9 + sp * 0.12).toFixed(3) + ')';
      if (rings.r4) rings.r4.style.transform = 'scale(' + (0.7 + sp * 0.7).toFixed(3) + ')';
      if (rings.r5) { var a = sp * Math.PI * 2 * 1.5; rings.r5.setAttribute('transform', 'rotate(' + (a * 180 / Math.PI).toFixed(1) + ' 200 200)'); }
    } else if (story && step !== -2) { step = -2; story.setAttribute('data-step', '0'); }
  }
  function req() { if (!ticking) { ticking = true; requestAnimationFrame(frame); } }
  addEventListener('scroll', req, { passive: true });
  addEventListener('resize', req);
  frame();

  /* ----- menu ----- */
  safe(function () {
    var btn = $('.burger'), menu = $('#menu');
    function set(on) {
      H.classList.toggle('menu-open', on); [$('#main'), $('footer'), $('.rail')].forEach(function (e) { if (!e) return; if (on) e.setAttribute('inert', ''); else e.removeAttribute('inert'); });
      btn.setAttribute('aria-expanded', on ? 'true' : 'false'); btn.setAttribute('aria-label', on ? S('menu_close', 'Close menu') : S('menu_open', 'Open menu'));
      if (on) { H.classList.remove('hide'); var f = $('a.m', menu); if (f) setTimeout(function () { f.focus({ preventScroll: true }); }, 450); } else btn.focus({ preventScroll: true });
    }
    btn.addEventListener('click', function () { set(!H.classList.contains('menu-open')); });
    menu.addEventListener('click', function (e) { var a = e.target.closest('a'); if (a && !a.hasAttribute('data-leave')) set(false); });
    D.addEventListener('keydown', function (e) {
      if (!H.classList.contains('menu-open')) return;
      if (e.key === 'Escape') { set(false); return; }
      if (e.key !== 'Tab') return;
      var f = $$('.bar a[href], .bar button, #menu a[href]').filter(function (x) { return x.offsetParent !== null; });
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && D.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && D.activeElement === last) { e.preventDefault(); first.focus(); }
    });
  }, 'menu');

  /* ----- tabs (animated text swap) ----- */
  safe(function () {
    if (!$('#stage')) return;
    var DATA = [0, 1, 2, 3].map(function (i) { return ['0' + (i + 1), S('tab' + i + 't', ''), S('tab' + i + 'p', '')]; });
    var tabs = $$('.tab'), stage = $('#stage'), n = $('.n', stage), h = $('h3', stage), p = $('p', stage), m = $$('.meter i', stage), cur = 0, tm = 0;
    function show(i, focus) {
      if (i === cur && !focus) return;
      cur = i;
      tabs.forEach(function (t, k) { t.setAttribute('aria-selected', k === i ? 'true' : 'false'); t.tabIndex = k === i ? 0 : -1; });
      stage.setAttribute('aria-labelledby', 't' + i);
      m.forEach(function (x, k) { x.classList.toggle('on', k <= i); });
      if (focus) tabs[i].focus();
      var els = [n, h, p];
      if (RM) { n.textContent = DATA[i][0]; h.textContent = DATA[i][1]; p.textContent = DATA[i][2]; return; }
      els.forEach(function (e) { e.classList.add('out'); });
      clearTimeout(tm);
      tm = setTimeout(function () { n.textContent = DATA[i][0]; h.textContent = DATA[i][1]; p.textContent = DATA[i][2]; els.forEach(function (e) { e.classList.remove('out'); }); }, 230);
    }
    tabs.forEach(function (t, i) {
      t.addEventListener('click', function () { show(i); });
      t.addEventListener('keydown', function (e) {
        var k = e.key; if (k === 'ArrowRight' || k === 'ArrowDown') { e.preventDefault(); show((i + 1) % 4, true); }
        else if (k === 'ArrowLeft' || k === 'ArrowUp') { e.preventDefault(); show((i + 3) % 4, true); }
        else if (k === 'Home') { e.preventDefault(); show(0, true); } else if (k === 'End') { e.preventDefault(); show(3, true); }
      });
    });
  }, 'tabs');

  /* ----- accordion ----- */
  safe(function () {
    var bs = $$('.acc-b');
    bs.forEach(function (b) { b.addEventListener('click', function () {
      var open = b.getAttribute('aria-expanded') === 'true';
      bs.forEach(function (o) { o.setAttribute('aria-expanded', 'false'); });
      b.setAttribute('aria-expanded', open ? 'false' : 'true');
    }); });
  }, 'accordion');

  /* ----- copy handle ----- */
  var toastEl = $('.toast'), tt = 0;
  function toast(msg) { toastEl.textContent = msg; toastEl.classList.add('show'); clearTimeout(tt); tt = setTimeout(function () { toastEl.classList.remove('show'); }, 2200); }
  $$('[data-copy]').forEach(function (b) { b.addEventListener('click', function () {
    var v = b.getAttribute('data-copy');
    function ok() { toast(S('copied', 'Copied') + ': ' + v); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(v).then(ok, ok); else ok();
  }); });

  /* ----- page transitions: cover, then navigate. Back/forward cache restores the page uncovered. ----- */
  $$('a[data-leave]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      if (e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || a.target === '_blank') return;
      if (RM) return;
      var href = a.href; e.preventDefault();
      H.classList.remove('menu-open'); H.classList.add('leaving');
      setTimeout(function () { location.href = href; }, 480);
    });
  });
  addEventListener('pageshow', function (e) { if (e.persisted) H.classList.remove('leaving'); });

  /* ----- desktop only: cursor, magnetic buttons, card tilt ----- */
  if (FINE && !RM) safe(function () {
    var c = $('.cur'), x = -100, y = -100, cx = x, cy = y, raf = 0;
    function loop() { cx += (x - cx) * 0.2; cy += (y - cy) * 0.2; c.style.translate = cx.toFixed(1) + 'px ' + cy.toFixed(1) + 'px'; raf = (Math.abs(x - cx) > 0.1 || Math.abs(y - cy) > 0.1) ? requestAnimationFrame(loop) : 0; }
    addEventListener('pointermove', function (e) {
      x = e.clientX; y = e.clientY; c.classList.add('show'); if (!raf) raf = requestAnimationFrame(loop);
      var t = e.target, lb = t.closest && t.closest('[data-cursor]');
      c.classList.toggle('on', !!(t.closest && t.closest('a,button,.tab,.acc-b')));
      if (lb) { c.firstChild.textContent = lb.getAttribute('data-cursor'); c.classList.add('lbl'); } else c.classList.remove('lbl');
    }, { passive: true });
    var recheck = 0;
    addEventListener('scroll', function () {
      if (recheck || !c.classList.contains('show')) return;
      recheck = requestAnimationFrame(function () {
        recheck = 0;
        var t = D.elementFromPoint(x, y), lb = t && t.closest && t.closest('[data-cursor]');
        c.classList.toggle('on', !!(t && t.closest && t.closest('a,button,.tab,.acc-b')));
        if (lb) { c.firstChild.textContent = lb.getAttribute('data-cursor'); c.classList.add('lbl'); } else c.classList.remove('lbl');
      });
    }, { passive: true });
    addEventListener('pointerdown', function () { c.classList.add('down'); }); addEventListener('pointerup', function () { c.classList.remove('down'); });
    D.documentElement.addEventListener('mouseleave', function () { c.classList.remove('show'); });

    $$('.mag').forEach(function (m) {
      m.addEventListener('pointermove', function (e) { var r = m.getBoundingClientRect(); m.style.setProperty('--mx', clamp((e.clientX - r.left - r.width / 2) * 0.18, -8, 8).toFixed(1) + 'px'); m.style.setProperty('--my', clamp((e.clientY - r.top - r.height / 2) * 0.25, -6, 6).toFixed(1) + 'px'); });
      m.addEventListener('pointerleave', function () { m.style.removeProperty('--mx'); m.style.removeProperty('--my'); });
    });
    var fw = $('.fwrap'), fr = fw && $('.frame', fw);
    if (fw && fr) {
      fw.addEventListener('pointermove', function (e) { var r = fw.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height; fr.style.setProperty('--ry', ((px - 0.5) * 10).toFixed(2) + 'deg'); fr.style.setProperty('--rx', ((0.5 - py) * 8).toFixed(2) + 'deg'); });
      fw.addEventListener('pointerleave', function () { fr.style.removeProperty('--rx'); fr.style.removeProperty('--ry'); });
    }
    var hero = $('.hero') || $('.phero'), orbs = hero && $('.orbs', hero);
    if (hero) hero.addEventListener('pointermove', function (e) {
      var r = hero.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      PTR.x = x; PTR.y = y; hero.classList.add('pt'); hero.style.setProperty('--px', x + 'px'); hero.style.setProperty('--py', y + 'px');
      if (orbs) orbs.style.transform = 'translate3d(' + ((0.5 - x / r.width) * 40).toFixed(1) + 'px,' + ((0.5 - y / r.height) * 30).toFixed(1) + 'px,0)';
    });
    if (hero) hero.addEventListener('pointerleave', function () { PTR.x = PTR.y = -999; hero.classList.remove('pt'); if (orbs) orbs.style.transform = ''; });
    $$('.tilt').forEach(function (t) {
      t.addEventListener('pointermove', function (e) {
        var r = t.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
        t.style.setProperty('--ry', ((px - 0.5) * 8).toFixed(2) + 'deg'); t.style.setProperty('--rx', ((0.5 - py) * 6).toFixed(2) + 'deg');
        t.style.setProperty('--gx', (px * 100).toFixed(1) + '%'); t.style.setProperty('--gy', (py * 100).toFixed(1) + '%');
      });
      t.addEventListener('pointerleave', function () { ['--rx', '--ry'].forEach(function (p) { t.style.removeProperty(p); }); });
    });
  }, 'pointer');


  /* ----- accent colour switcher (remembered; cross-fades where View Transitions exist) ----- */
  safe(function () {
    var ACCS = ['violet', 'ember', 'aurora', 'solar'], NAMES = ['Violet', 'Ember', 'Aurora', 'Solar'], b = $('.acc-btn');
    if (!b) return;
    function idx() { var a = H.getAttribute('data-acc') || 'violet', i = ACCS.indexOf(a); return i < 0 ? 0 : i; }
    b.addEventListener('click', function () {
      var i = (idx() + 1) % ACCS.length;
      function apply() { if (i === 0) H.removeAttribute('data-acc'); else H.setAttribute('data-acc', ACCS[i]); try { localStorage.setItem('macc', ACCS[i]); } catch (e) {} readAcc(); }
      if (!RM && D.startViewTransition) { try { D.startViewTransition(apply); } catch (e) { apply(); } } else apply();
      toast(S('accent', 'Accent') + ': ' + NAMES[i]);
    });
  }, 'accent');

  /* ----- section spy: rail dots + top-nav current link ----- */
  safe(function () {
    if (!HAS_IO) return;
    var ids = ['top', 'showcase', 'features', 'demo', 'story', 'capabilities', 'work', 'now', 'contact'], rl = $$('.rail a'), nl = $$('.bar nav a.l');
    var so = new IntersectionObserver(function (es) {
      es.forEach(function (en) {
        if (!en.isIntersecting) return;
        var id = en.target.id, h = '#' + id;
        rl.forEach(function (a) { if (a.getAttribute('href') === h) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current'); });
        nl.forEach(function (a) { if (a.getAttribute('href') === h) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current'); });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    ids.forEach(function (i) { var e = D.getElementById(i); if (e) so.observe(e); });
    var tk = $('.tick'); if (tk) new IntersectionObserver(function (es) { tk.classList.toggle('paused', !es[0].isIntersecting); }).observe(tk);
  }, 'spy');

  /* ----- hero particles: few, slow, paused when off-screen or hidden ----- */
  if (!RM) safe(function () {
    var cv = $('#fx'); if (!cv) return; var g = cv.getContext('2d'); if (!g) return;
    var N = SMALL ? 22 : 54, dots = [], w = 0, h = 0, dpr = Math.min(W.devicePixelRatio || 1, 1.5), run = true, vis = true, hero = $('.hero');
    function size() { w = hero.clientWidth; h = hero.clientHeight; cv.width = w * dpr; cv.height = h * dpr; g.setTransform(dpr, 0, 0, dpr, 0, 0); }
    size(); var lastW = w; addEventListener('resize', function () { if (hero.clientWidth !== lastW) { lastW = hero.clientWidth; size(); } });
    for (var i = 0; i < N; i++) dots.push({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - 0.5) * 0.18, vy: (Math.random() - 0.5) * 0.18, r: Math.random() * 1.4 + 0.5 });
    function draw() {
      if (run && vis) {
        g.clearRect(0, 0, w, h);
        for (var i = 0; i < N; i++) {
          var a = dots[i]; a.x += a.vx; a.y += a.vy;
          if (PTR.x > -900) { var px = a.x - PTR.x, py = a.y - PTR.y, pd = px * px + py * py; if (pd < 19600) { var f = (1 - pd / 19600) * 0.9, pl = Math.sqrt(pd) || 1; a.x += (px / pl) * f; a.y += (py / pl) * f; g.strokeStyle = 'rgba(' + ACCB[0] + ',' + ACCB[1] + ',' + ACCB[2] + ',' + (0.35 * (1 - pd / 19600)).toFixed(3) + ')'; g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(PTR.x, PTR.y); g.stroke(); } } if (a.x < 0) a.x = w; else if (a.x > w) a.x = 0; if (a.y < 0) a.y = h; else if (a.y > h) a.y = 0;
          g.fillStyle = 'rgba(244,241,234,.55)'; g.beginPath(); g.arc(a.x, a.y, a.r, 0, 6.2832); g.fill();
          if (!SMALL) for (var j = i + 1; j < N; j++) { var b = dots[j], dx = a.x - b.x, dy = a.y - b.y, d = dx * dx + dy * dy; if (d < 11000) { g.strokeStyle = 'rgba(' + ACC[0] + ',' + ACC[1] + ',' + ACC[2] + ',' + (0.3 * (1 - d / 11000)).toFixed(3) + ')'; g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke(); } }
        }
      }
      requestAnimationFrame(draw);
    }
    draw();
    if (HAS_IO) new IntersectionObserver(function (es) { vis = es[0].isIntersecting; }).observe(hero);
    D.addEventListener('visibilitychange', function () { run = !D.hidden; });
  }, 'particles');

  /* ======================================================== v20 modules */
  var SND = function () {};
  function typingTarget(e) { var t = e.target; return !!(t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))); }
  function setInert(on) { [$('#main'), $('footer'), $('.rail')].forEach(function (e) { if (!e) return; if (on) e.setAttribute('inert', ''); else e.removeAttribute('inert'); }); }
  function leaveTo(u) { if (RM) { location.href = u; return; } H.classList.add('leaving'); setTimeout(function () { location.href = u; }, 480); }

  /* ----- "?e=m" remembers the edition choice, then the parameter is removed from the address bar ----- */
  safe(function () {
    if (/[?&]e=m(&|$)/.test(location.search)) { try { localStorage.setItem('edition', 'motion'); } catch (e) {} }
    if (/[?&]e=/.test(location.search) && W.history && history.replaceState) {
      var q = location.search.replace(/([?&])e=[^&]*&?/, '$1').replace(/[?&]$/, '');
      history.replaceState(null, '', location.pathname + q + location.hash);
    }
  }, 'edition');

  /* ----- offline worker (https only) + connection toasts ----- */
  safe(function () {
    if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
      addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); });
    }
    addEventListener('offline', function () { toast(S('offline', 'You are offline')); });
    addEventListener('online', function () { toast(S('online', 'Back online')); });
  }, 'sw');

  /* ----- sound: very quiet ticks, off by default, remembered ----- */
  safe(function () {
    var b = $('.snd-btn'); if (!b) return;
    var ctx = null, on = false, lastHover = null;
    try { on = localStorage.getItem('msnd') === '1'; } catch (e) {}
    function ensure() { if (!ctx) { var AC = W.AudioContext || W.webkitAudioContext; if (AC) { try { ctx = new AC(); } catch (e) {} } } if (ctx && ctx.state === 'suspended') ctx.resume(); }
    function tick(f, d, v) {
      if (!on || !ctx) return;
      var o = ctx.createOscillator(), g = ctx.createGain(), t = ctx.currentTime; d = d || 0.09;
      o.type = 'sine'; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(v || 0.03, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + d + 0.02);
    }
    SND = tick;
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
    b.addEventListener('click', function () {
      on = !on; b.setAttribute('aria-pressed', on ? 'true' : 'false');
      try { localStorage.setItem('msnd', on ? '1' : '0'); } catch (e) {}
      if (on) { ensure(); tick(660, 0.14, 0.04); }
      toast(on ? S('sound_on', 'Sound on') : S('sound_off', 'Sound off'));
    });
    D.addEventListener('pointerdown', function () { if (on) ensure(); }, { once: true });
    D.addEventListener('click', function (e) { var t = e.target.closest && e.target.closest('a,button,.tab,.acc-b'); if (t && !t.closest('.snd-btn')) tick(520, 0.08, 0.025); });
    if (FINE) D.addEventListener('pointerover', function (e) { var t = e.target.closest && e.target.closest('a,button,.tab,.acc-b'); if (t && t !== lastHover) { lastHover = t; tick(880, 0.05, 0.012); } else if (!t) lastHover = null; });
  }, 'sound');

  /* ----- time-of-day greeting (the hero lighting itself is set by data-tod in the page head) ----- */
  safe(function () {
    var el = $('#tod'); if (!el) return;
    function up() {
      var d = new Date(), h = d.getHours(), m = d.getMinutes(), mm = (m < 10 ? '0' : '') + m;
      var g = h >= 5 && h < 12 ? S('morn', 'Good morning') : h >= 12 && h < 17 ? S('aft', 'Good afternoon') : h >= 17 && h < 21 ? S('eve', 'Good evening') : S('night', 'Good night');
      var t = LANG === 'ja' ? h + ':' + mm : (h % 12 || 12) + ':' + mm + ' ' + (h < 12 ? 'AM' : 'PM');
      el.textContent = g + ' \u00b7 ' + S('local', 'your local time') + ' ' + t;
    }
    up(); setInterval(up, 30000);
  }, 'tod');

  /* ----- simulated Dino Bot chat (scripted replies; labelled as a demo on the page) ----- */
  safe(function () {
    var log = $('#dlog'), form = $('#dform'), inp = $('#dinp'); if (!log || !form || !inp) return;
    var busy = false;
    function add(who, text, me) {
      var m = D.createElement('div'), a = D.createElement('span'), b = D.createElement('div'), n = D.createElement('b'), p = D.createElement('p');
      m.className = 'dm' + (me ? ' me' : ''); a.className = 'av'; a.setAttribute('aria-hidden', 'true'); a.textContent = me ? 'Y' : 'D';
      n.textContent = who; p.textContent = text; b.appendChild(n); b.appendChild(p); m.appendChild(a); m.appendChild(b); log.appendChild(m);
      log.scrollTop = log.scrollHeight; return m;
    }
    function answer(c) {
      var l = c.toLowerCase(), key = 'unknown', m;
      if (l === '/help' || l === 'help') key = 'help';
      else if (/^\/ask(\s|$)/.test(l)) key = 'ask';
      else if ((m = /^\/(moderation|utility|image|ping)$/.exec(l))) key = m[1];
      return S(key, 'Try /help');
    }
    function send(text) {
      text = (text || '').trim(); if (!text || busy) return;
      add(S('you', 'you'), text, true); busy = true;
      var t = add(S('bot', 'Dino Bot'), '', false), p = $('p', t); t.classList.add('typing'); p.innerHTML = '<i></i><i></i><i></i>';
      setTimeout(function () { t.classList.remove('typing'); p.textContent = answer(text); log.scrollTop = log.scrollHeight; busy = false; }, RM ? 0 : 600 + Math.random() * 350);
    }
    add(S('bot', 'Dino Bot'), S('help', 'Try /help'), false);
    form.addEventListener('submit', function (e) { e.preventDefault(); send(inp.value); inp.value = ''; });
    $$('.dc-chips button').forEach(function (c) { c.addEventListener('click', function () { send(c.getAttribute('data-cmd')); if (FINE) inp.focus({ preventScroll: true }); }); });
  }, 'demo');

  /* ----- project cards expand into a full-screen preview ----- */
  safe(function () {
    var pv = $('#pvw'); if (!pv) return;
    var box = $('.pvw-box', pv), xb = $('.pvw-x', pv), go = $('.pvw-a', pv), cardEl = null, back = null, tm = 0;
    function clip(r) { return 'inset(' + Math.max(0, r.top) + 'px ' + Math.max(0, innerWidth - r.right) + 'px ' + Math.max(0, innerHeight - r.bottom) + 'px ' + Math.max(0, r.left) + 'px round 18px)'; }
    function open(card) {
      clearTimeout(tm); cardEl = card; back = D.activeElement;
      $('.pvw-k', pv).textContent = card.getAttribute('data-kind') || ''; $('.pvw-t', pv).textContent = card.getAttribute('data-title') || '';
      $('.pvw-s', pv).textContent = card.getAttribute('data-sum') || ''; $('.pvw-g', pv).textContent = card.getAttribute('data-tags') || '';
      go.setAttribute('href', card.getAttribute('href')); box.setAttribute('aria-label', card.getAttribute('data-title') || '');
      var r = card.getBoundingClientRect();
      pv.hidden = false; H.classList.add('pv-open'); setInert(true);
      if (RM) pv.classList.add('go');
      else { pv.style.clipPath = clip(r); void pv.offsetWidth; pv.classList.add('go'); pv.style.clipPath = 'inset(0px 0px 0px 0px round 0px)'; }
      box.focus({ preventScroll: true });
    }
    function close() {
      if (pv.hidden) return;
      pv.classList.remove('go');
      function done() { pv.hidden = true; pv.style.clipPath = ''; H.classList.remove('pv-open'); setInert(false); if (back && back.focus) back.focus({ preventScroll: true }); }
      if (RM || !cardEl) { done(); return; }
      pv.style.clipPath = clip(cardEl.getBoundingClientRect()); tm = setTimeout(done, 650);
    }
    $$('[data-pv]').forEach(function (c) { c.addEventListener('click', function (e) { if (e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return; e.preventDefault(); open(c); }); });
    xb.addEventListener('click', close);
    D.addEventListener('keydown', function (e) {
      if (pv.hidden) return;
      if (e.key === 'Escape') { close(); return; }
      if (e.key === 'Tab') { var f = [xb, go]; if (e.shiftKey && D.activeElement === f[0]) { e.preventDefault(); f[1].focus(); } else if (!e.shiftKey && D.activeElement === f[1]) { e.preventDefault(); f[0].focus(); } }
    });
  }, 'preview');

  /* ----- CV slide-out panel (the PDF is only loaded when opened; browsers that cannot show PDFs get the download button) ----- */
  safe(function () {
    var cp = $('#cvp'); if (!cp) return;
    var box = $('.cvp-box', cp), obj = $('.cvp-obj', cp), loaded = false, back = null;
    function open() {
      if (H.classList.contains('menu-open')) { var bb = $('.burger'); if (bb) bb.click(); }
      back = D.activeElement;
      if (!loaded && obj) { loaded = true; if (navigator.pdfViewerEnabled !== false) obj.setAttribute('data', obj.getAttribute('data-src')); }
      cp.hidden = false; H.classList.add('cvp-lock'); setInert(true); void cp.offsetWidth; cp.classList.add('go'); box.focus({ preventScroll: true });
    }
    function close() {
      if (cp.hidden) return; cp.classList.remove('go');
      setTimeout(function () { cp.hidden = true; H.classList.remove('cvp-lock'); setInert(false); if (back && back.focus) back.focus({ preventScroll: true }); }, RM ? 0 : 450);
    }
    $$('.cv-open').forEach(function (b) { b.addEventListener('click', open); });
    $('.cvp-x', cp).addEventListener('click', close);
    cp.addEventListener('mousedown', function (e) { if (e.target === cp) close(); });
    D.addEventListener('keydown', function (e) {
      if (cp.hidden) return;
      if (e.key === 'Escape') { close(); return; }
      if (e.key === 'Tab') { var f = $$('a[href],button', box); if (!f.length) return; var a = f[0], z = f[f.length - 1]; if (e.shiftKey && D.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && D.activeElement === z) { e.preventDefault(); a.focus(); } }
    });
  }, 'cv');

  /* ----- testimonials (the section only exists when real quotes are set in lib.php) ----- */
  safe(function () {
    var qs = $('[data-qs]'); if (!qs) return;
    var items = $$('.q', qs), i = 0, hold = false, cnt = $('.qc', qs), nav = $('.qn', qs);
    if (items.length < 2) { if (nav) nav.hidden = true; return; }
    function show(n) { items[i].classList.remove('on'); i = (n + items.length) % items.length; items[i].classList.add('on'); cnt.textContent = (i + 1) + ' / ' + items.length; }
    show(0);
    $('.qp', qs).addEventListener('click', function () { show(i - 1); });
    $('.qx', qs).addEventListener('click', function () { show(i + 1); });
    qs.addEventListener('pointerenter', function () { hold = true; }); qs.addEventListener('pointerleave', function () { hold = false; });
    qs.addEventListener('focusin', function () { hold = true; }); qs.addEventListener('focusout', function () { hold = false; });
    if (!RM) setInterval(function () { if (!hold && !D.hidden) show(i + 1); }, 8000);
  }, 'quotes');

  /* ----- inline contact form (falls back to a normal post when fetch is missing or scripts fail) ----- */
  safe(function () {
    var ob = $('#cform-open'), wrap = $('#cform'), form = $('#cf'); if (!ob || !wrap || !form) return;
    var okN = $('.cf-note.ok', wrap), badN = $('.cf-note.bad', wrap), btn = $('button[type=submit]', form), lab = $('.cf-l', form), orig = lab.textContent, ta = $('textarea', form);
    ob.addEventListener('click', function () {
      var show = wrap.hidden; wrap.hidden = !show; ob.setAttribute('aria-expanded', show ? 'true' : 'false');
      if (show) { var f = $('input', form); if (f && FINE) f.focus({ preventScroll: true }); try { wrap.scrollIntoView({ behavior: RM ? 'auto' : 'smooth', block: 'nearest' }); } catch (e) {} }
    });
    ta.addEventListener('keydown', function (e) { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); if (form.requestSubmit) form.requestSubmit(); else form.submit(); } });
    form.addEventListener('submit', function (e) {
      if (!W.fetch || !W.FormData) return;
      e.preventDefault(); okN.hidden = true; badN.hidden = true; btn.disabled = true; lab.textContent = S('ct_sending', 'Sending\u2026');
      fetch(form.action, { method: 'POST', body: new FormData(form), headers: { 'Accept': 'application/json', 'X-Requested-With': 'fetch' }, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (j && j.ok) { okN.hidden = false; form.reset(); SND(660, 0.12, 0.04); }
          else { badN.textContent = (j && j.error) || S('ct_fail', 'Could not send.'); badN.hidden = false; }
        })
        .catch(function () { badN.textContent = S('ct_fail', 'Could not send.'); badN.hidden = false; })
        .then(function () { btn.disabled = false; lab.textContent = orig; });
    });
  }, 'cform');

  /* ----- case-study pages: arrow keys and swipe between projects ----- */
  safe(function () {
    var nx = D.body.getAttribute('data-next'), pv = D.body.getAttribute('data-prev'); if (!nx || !pv) return;
    D.addEventListener('keydown', function (e) {
      if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey || e.shiftKey || typingTarget(e) || H.classList.contains('menu-open') || H.classList.contains('cvp-lock')) return;
      if (e.key === 'ArrowRight') leaveTo(nx); else if (e.key === 'ArrowLeft') leaveTo(pv);
    });
    var x0 = 0, y0 = 0, t0 = 0, ok = false;
    D.addEventListener('touchstart', function (e) {
      var t = e.target;
      ok = e.touches.length === 1 && !(t.closest && t.closest('input,textarea,select,pre,table,.cvp,.pvw,.menu'));
      x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; t0 = Date.now();
      if (x0 < 22 || x0 > innerWidth - 22) ok = false;
    }, { passive: true });
    D.addEventListener('touchcancel', function () { ok = false; }, { passive: true });
    D.addEventListener('touchend', function (e) {
      if (!ok) return; ok = false;
      var c = e.changedTouches[0], dx = c.clientX - x0, dy = c.clientY - y0;
      if (Math.abs(dx) < 90 || Math.abs(dy) > 50 || Math.abs(dx) < Math.abs(dy) * 2.2 || Date.now() - t0 > 650) return;
      var fwd = dx < 0;
      toast((fwd ? S('next', 'Next') : S('prev', 'Previous')) + ': ' + (D.body.getAttribute(fwd ? 'data-next-t' : 'data-prev-t') || ''));
      setTimeout(function () { leaveTo(fwd ? nx : pv); }, 200);
    }, { passive: true });
  }, 'casenav');

  /* ----- project clips (from /shots) play only while visible ----- */
  safe(function () {
    var vs = $$('video[data-autoplay]'); if (!vs.length) return;
    if (RM || !HAS_IO) { vs.forEach(function (v) { v.controls = true; v.preload = 'metadata'; }); return; }
    var vo = new IntersectionObserver(function (es) { es.forEach(function (en) { var v = en.target; if (en.isIntersecting) { var pr = v.play(); if (pr && pr.catch) pr.catch(function () {}); } else v.pause(); }); }, { threshold: 0.25 });
    vs.forEach(function (v) { vo.observe(v); });
  }, 'video');

  /* ----- small surprises: type "dino", or the Konami code ----- */
  safe(function () {
    var buf = '', KON = 'ArrowUpArrowUpArrowDownArrowDownArrowLeftArrowRightArrowLeftArrowRightba';
    D.addEventListener('keydown', function (e) {
      if (typingTarget(e) || e.ctrlKey || e.metaKey || e.altKey || !e.key) return;
      buf = (buf + (e.key.length === 1 ? e.key.toLowerCase() : e.key)).slice(-80);
      if (/dino$/.test(buf)) { buf = ''; dino(); }
      else if (buf.slice(-KON.length) === KON) { buf = ''; party(); }
    });
    function dino() {
      toast(S('egg', 'Dino says hi.')); SND(520, 0.1, 0.04);
      if (RM) return;
      var d = D.createElement('div'); d.className = 'dinorun'; d.setAttribute('aria-hidden', 'true'); d.textContent = '\ud83e\udd96'; D.body.appendChild(d);
      setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 3300);
    }
    function party() { var b = $('.acc-btn'); if (!b) return; var n = 0, iv = setInterval(function () { b.click(); if (++n >= 8) clearInterval(iv); }, RM ? 20 : 700); }
  }, 'eggs');
})();
