<?php
/* motion-project.php?p=<slug>: Motion Edition case-study page. Data comes from $PROJECTS in lib.php. */
require __DIR__ . '/motion-lib.php';
$slug = (string) ($_GET['p'] ?? '');
if (!isset($PROJECTS[$slug])) { header('Location: motion.php#work', true, 302); exit; }
$P = $PROJECTS[$slug];
$keys = array_keys($PROJECTS);
$pos  = array_search($slug, $keys, true);
$nextS = $keys[($pos + 1) % count($keys)];
$prevS = $keys[($pos - 1 + count($keys)) % count($keys)];
$hue = ['dino-bot' => 262, 'loyal-bot' => 330, 'ai-chat' => 190, 'ai-tools' => 150, 'discord-automation' => 30, 'portfolio' => 220][$slug] ?? 260;
$media = m_media_html($slug, $P['title']);
?><!DOCTYPE html>
<html lang="<?= e($L) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= e($P['title']) ?> &mdash; Mohammed Moin Hamza</title>
<meta name="description" content="<?= e($P['summary']) ?>">
<meta name="theme-color" content="#0B0B10">
<meta name="color-scheme" content="dark">
<link rel="canonical" href="<?= e(SITE_URL) ?>/motion-project.php?p=<?= e($slug) ?>">
<meta property="og:title" content="<?= e($P['title']) ?> &mdash; Mohammed Moin Hamza">
<meta property="og:description" content="<?= e($P['summary']) ?>">
<meta property="og:type" content="article">
<meta property="og:image" content="<?= e(SITE_URL) ?>/dino-logo.jpg">
<link rel="icon" type="image/jpeg" href="dino-logo.jpg">
<link rel="apple-touch-icon" href="icon-192.png">
<link rel="manifest" href="site.webmanifest">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Syne:wght@600;800&display=swap">
<link rel="stylesheet" href="motion.css?v=20">
<script>
(function(){var h=document.documentElement;h.classList.add("js");
try{if(matchMedia("(prefers-reduced-motion:reduce)").matches)h.classList.add("rm")}catch(e){}
try{var a=localStorage.getItem("macc");if(a&&/^(ember|aurora|solar)$/.test(a))h.setAttribute("data-acc",a)}catch(e){}})();
</script>
</head>
<body class="case" data-prev="motion-project.php?p=<?= e($prevS) ?>" data-next="motion-project.php?p=<?= e($nextS) ?>" data-prev-t="<?= e($PROJECTS[$prevS]['title']) ?>" data-next-t="<?= e($PROJECTS[$nextS]['title']) ?>">
<?php m_chrome_top('motion.php'); ?>

<main id="main">
<section class="phero" style="--h:<?= (int) $hue ?>" aria-labelledby="ph-h">
  <div class="bg" aria-hidden="true"><div class="orbs"><div class="orb o1"></div><div class="orb o2"></div></div></div>
  <div class="wrap">
    <p class="eyebrow chars" data-chars style="--d:200ms"><?= e($P['kind']) ?><?= $P['status'] !== '' ? ' &middot; ' . e($P['status']) : '' ?></p>
    <h1 id="ph-h" class="split ptitle" data-split style="--d:300ms"><?= e($P['title']) ?></h1>
    <p class="plead rise" style="--d:.9s"><?= e($P['summary']) ?></p>
    <div class="tags rise" style="--d:1s"><?php foreach ($P['tags'] as $tg) { echo '<span>' . e($tg) . '</span>'; } ?></div>
    <div class="cta rise" style="--d:1.1s">
<?php foreach ($P['links'] as $i => $ln) { ?>
      <a class="btn <?= $i === 0 ? 'pri ' : '' ?>mag" href="<?= e($ln[1]) ?>" target="_blank" rel="noopener"><?= e($ln[0]) ?> <?= M_ARROW ?></a>
<?php } ?>
      <a class="ul" href="motion.php#work" data-leave>&#8592; <?= t('m.work') ?></a>
    </div>
  </div>
</section>

<section class="sec pbody" aria-labelledby="pi-h">
  <div class="wrap pgrid">
    <div class="fwrap" data-r-clip><div class="frame clip pframe"><div class="art"></div><?= $media ?: '<span class="pinit" aria-hidden="true">' . e(function_exists('mb_substr') ? mb_substr($P['title'], 0, 2, 'UTF-8') : substr($P['title'], 0, 2)) . '</span>' ?></div></div>
    <div>
      <p class="eyebrow" data-r id="pi-h"><?= t('m.f_eyebrow') ?></p>
      <ol class="plist">
<?php foreach ($P['points'] as $i => $pt) { ?>
        <li data-r data-d="<?= min($i, 5) * 0.06 ?>s"><span><?= str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) ?></span><p><?= e($pt) ?></p></li>
<?php } ?>
      </ol>
    </div>
  </div>
</section>

<section class="pnav" aria-label="Projects">
  <a class="pn" href="motion-project.php?p=<?= e($prevS) ?>" data-leave data-cursor="<?= e(m_plain('m.j_prev')) ?>"><span>&#8592; <?= t('m.j_prev') ?></span><b><?= e($PROJECTS[$prevS]['title']) ?></b></a>
  <a class="pn r" href="motion-project.php?p=<?= e($nextS) ?>" data-leave data-cursor="<?= e(m_plain('m.j_next')) ?>"><span><?= t('m.j_next') ?> &#8594;</span><b><?= e($PROJECTS[$nextS]['title']) ?></b></a>
</section>
</main>

<footer>
  <div class="wrap">
    <p>&copy; <span id="yr">2026</span> Mohammed Moin Hamza &mdash; Dino / n6ble</p>
    <div class="r"><a class="ul" href="motion.php#contact" data-leave><?= t('m.contact') ?></a><a class="ul" href="index.php?e=c" data-leave>&#8617; <?= t('m.classic') ?> <?= t('m.site') ?></a></div>
  </div>
</footer>
<?php m_chrome_bottom(); ?>
</body>
</html>
