<?php
/* motion.php: the Motion Edition home page (English / Japanese). Text lives in motion-i18n.php, data in lib.php. */
require __DIR__ . '/motion-lib.php';
$stats = bot_stats();
$sent = isset($_GET['sent']) && $_GET['sent'] === '1';
$err  = isset($_GET['err']) && $_GET['err'] === '1';
$CARDS = [
  ['dino-bot', 'k_bot', 'p1', 262], ['loyal-bot', 'k_bot', 'p2', 330], ['ai-chat', 'k_app', 'p3', 190],
  ['ai-tools', 'k_tools', 'p4', 150], ['discord-automation', 'k_scripts', 'p5', 30], ['portfolio', 'k_site', 'p6', 220],
];
?><!DOCTYPE html>
<html lang="<?= e($L) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Mohammed Moin Hamza &mdash; Motion Edition</title>
<meta name="description" content="<?= e(m_plain('m.statement')) ?>">
<meta name="theme-color" content="#0B0B10">
<meta name="color-scheme" content="dark">
<link rel="canonical" href="<?= e(SITE_URL) ?>/motion.php">
<meta property="og:title" content="Mohammed Moin Hamza &mdash; Motion Edition">
<meta property="og:description" content="<?= e(m_plain('m.statement')) ?>">
<meta property="og:type" content="website">
<meta property="og:image" content="<?= e(SITE_URL) ?>/dino-logo.jpg">
<link rel="icon" type="image/jpeg" href="dino-logo.jpg">
<link rel="apple-touch-icon" href="icon-192.png">
<link rel="manifest" href="site.webmanifest">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Syne:wght@600;800&display=swap">
<link rel="stylesheet" href="motion.css?v=20">
<script>
/* Runs before first paint. Hidden "start" states only exist when this script ran, so content is never hidden without JS. */
(function(){var h=document.documentElement;h.classList.add("js");
try{if(matchMedia("(prefers-reduced-motion:reduce)").matches)h.classList.add("rm")}catch(e){}
try{var a=localStorage.getItem("macc");if(a&&/^(ember|aurora|solar)$/.test(a))h.setAttribute("data-acc",a)}catch(e){}
try{var d=new Date().getHours();h.setAttribute("data-tod",d>=5&&d<8?"dawn":d<17&&d>=8?"day":d>=17&&d<20?"dusk":"night")}catch(e){}})();
</script>
</head>
<body>
<?php m_chrome_top(''); ?>

<main id="main">

<!-- 1. HERO -->
<section class="hero" id="top" aria-label="<?= e(m_plain('m.intro_l')) ?>">
  <div class="bg" aria-hidden="true"><div class="orbs"><div class="orb o1"></div><div class="orb o2"></div></div></div>
  <canvas id="fx" aria-hidden="true"></canvas>
  <div class="scroll" aria-hidden="true"><span><?= t('m.scroll') ?></span><i></i></div>
  <div class="wrap">
    <p class="eyebrow chars" data-chars style="--d:250ms"><?= t('m.eyebrow') ?></p>
    <h1 class="split" data-split style="--d:400ms"><span class="ln"><?= t('m.h1a') ?></span><span class="ln"><?= t('m.h1b') ?></span><span class="ln grad"><?= t('m.h1c') ?></span></h1>
    <div class="hero-foot">
      <div>
        <p class="lead rise" style="--d:1.25s"><?= t('m.lead') ?></p>
        <p class="tod rise" style="--d:1.4s" aria-hidden="true"><i></i><span id="tod"></span></p>
      </div>
      <div class="cta">
        <a class="btn pri mag pop" style="--d:1.45s" href="#work"><?= t('m.cta1') ?> <?= M_ARROW ?></a>
        <a class="ul rise" style="--d:1.55s" href="#contact"><?= t('m.cta2') ?></a>
      </div>
    </div>
  </div>
</section>

<!-- 2. STATEMENT -->
<section class="sec state" aria-labelledby="st-h">
  <div class="wrap">
    <p class="eyebrow" data-r id="st-h"><?= t('m.intro_l') ?></p>
    <p class="big" style="margin-top:1.6rem" data-words><?= t('m.statement') ?></p>
    <ul class="nums" aria-label="Numbers">
      <li data-r><b data-count="6" data-suf="+">6+</b><span><?= t('m.n1') ?></span></li>
      <li data-r data-d=".08s"><b data-count="3" data-suf="+">3+</b><span><?= t('m.n2') ?></span></li>
      <li data-r data-d=".16s"><b data-count="2" data-suf="+">2+</b><span><?= t('m.n3') ?></span></li>
      <li data-r data-d=".24s"><b data-count="5" data-suf="+">5+</b><span><?= t('m.n4') ?></span></li>
    </ul>
  </div>
</section>

<div class="tick" aria-hidden="true"><div class="tick-t"><span>Python<i></i><b><?= t('m.t1') ?></b><i></i><?= t('m.t2') ?><i></i><b><?= t('m.t3') ?></b><i></i><?= t('m.t4') ?><i></i><b>REST APIs</b><i></i></span><span>Python<i></i><b><?= t('m.t1') ?></b><i></i><?= t('m.t2') ?><i></i><b><?= t('m.t3') ?></b><i></i><?= t('m.t4') ?><i></i><b>REST APIs</b><i></i></span></div></div>

<!-- 3. SHOWCASE -->
<section class="sec show" id="showcase" aria-labelledby="sh-h">
  <div class="bigword" aria-hidden="true" data-drift>DINO BOT</div>
  <div class="wrap show-grid">
    <div class="fwrap" data-r-clip><div class="frame clip"><div class="art"></div><picture><source srcset="dino-logo.webp" type="image/webp"><img src="dino-logo.jpg" alt="Dino Bot logo" width="400" height="400" loading="lazy"></picture><div class="orbit" aria-hidden="true"><div style="--t:26s;--r:11rem"><em>Python</em></div><div style="--t:34s;--r:14rem;--p:-.33"><em>discord.py</em></div><div style="--t:30s;--r:12.5rem;--p:-.66"><em>Groq &middot; Gemini</em></div></div></div></div>
    <div>
      <p class="badge" data-r><?= t('m.badge') ?></p>
      <h2 class="h2 split" id="sh-h" data-split>Dino Bot</h2>
      <p class="d" data-r data-d=".1s"><?= t('m.dino_d') ?></p>
      <div class="tags" data-r data-d=".18s"><span>Python</span><span>discord.py</span><span>Groq AI</span><span>Gemini</span><span>PHP</span></div>
<?php if ($stats) { ?>
      <ul class="livestats" data-r data-d=".22s" aria-label="Live stats">
<?php foreach (['servers' => 'st_servers', 'users' => 'st_users', 'uptime' => 'st_uptime'] as $k => $lk) { if (isset($stats[$k])) { $raw = preg_replace('/[^0-9.]/', '', str_replace(',', '', $stats[$k])); $suf = strpos($stats[$k], '%') !== false ? '%' : ''; ?>
        <li><i></i><b data-count="<?= e($raw) ?>" data-suf="<?= e($suf) ?>"><?= e($stats[$k]) ?></b><span><?= t('m.' . $lk) ?></span></li>
<?php } } ?>
      </ul>
<?php } ?>
      <div class="cta" data-r data-d=".26s">
        <a class="btn pri mag" data-cursor="Open" href="motion-project.php?p=dino-bot" data-leave><?= t('m.case') ?> <?= M_ARROW ?></a>
        <a class="btn mag" href="#demo"><?= t('m.try') ?></a>
        <a class="ul" href="https://dino-bot.gt.tc/?i=1" target="_blank" rel="noopener"><?= t('m.live') ?></a>
      </div>
    </div>
  </div>
</section>

<!-- 4. INTERACTIVE FEATURE -->
<section class="sec feat" id="features" aria-labelledby="ft-h">
  <div class="wrap">
    <div class="feat-top">
      <p class="eyebrow" data-r><?= t('m.f_eyebrow') ?></p>
      <h2 class="h2 split" id="ft-h" data-split><?= t('m.f_h2a') ?> <span class="grad"><?= t('m.f_h2b') ?></span></h2>
    </div>
    <div class="tabs" role="tablist" aria-label="Dino Bot" data-r>
      <button class="tab" role="tab" id="t0" aria-controls="stage" aria-selected="true" tabindex="0"><?= t('m.tab0') ?></button>
      <button class="tab" role="tab" id="t1" aria-controls="stage" aria-selected="false" tabindex="-1"><?= t('m.tab1') ?></button>
      <button class="tab" role="tab" id="t2" aria-controls="stage" aria-selected="false" tabindex="-1"><?= t('m.tab2') ?></button>
      <button class="tab" role="tab" id="t3" aria-controls="stage" aria-selected="false" tabindex="-1"><?= t('m.tab3') ?></button>
    </div>
    <div class="stage" id="stage" role="tabpanel" aria-labelledby="t0" aria-live="polite" data-r>
      <div class="n swap" aria-hidden="true">01</div>
      <div>
        <h3 class="swap"><?= t('m.tab0t') ?></h3>
        <p class="swap"><?= t('m.tab0p') ?></p>
        <div class="meter" aria-hidden="true"><i class="on"></i><i></i><i></i><i></i></div>
      </div>
    </div>
  </div>
</section>

<!-- 4b. DEMO (simulated) -->
<section class="sec demo" id="demo" aria-labelledby="dm-h">
  <div class="wrap demo-grid">
    <div>
      <p class="eyebrow" data-r><?= t('m.d_eyebrow') ?></p>
      <h2 class="h2 split" id="dm-h" data-split style="margin:1.2rem 0 1.2rem"><?= t('m.d_h2a') ?> <span class="grad"><?= t('m.d_h2b') ?></span></h2>
      <p class="mu" data-r style="max-width:26rem"><?= t('m.d_note') ?></p>
    </div>
    <div class="dc" data-r data-d=".1s">
      <div class="dc-top"><span class="dc-h">#</span><b>dino-demo</b><em class="dc-live" aria-hidden="true"></em></div>
      <div class="dc-log" id="dlog" role="log" aria-live="polite" aria-relevant="additions"></div>
      <div class="dc-chips" role="group" aria-label="Commands"><button type="button" data-cmd="/help">/help</button><button type="button" data-cmd="/ask what can you do?">/ask</button><button type="button" data-cmd="/moderation">/moderation</button><button type="button" data-cmd="/utility">/utility</button><button type="button" data-cmd="/image">/image</button><button type="button" data-cmd="/ping">/ping</button></div>
      <form class="dc-form" id="dform" autocomplete="off"><label class="vh" for="dinp"><?= t('m.d_send') ?></label><input id="dinp" type="text" maxlength="120" placeholder="<?= e(m_plain('m.d_ph')) ?>" enterkeyhint="send" autocapitalize="off" spellcheck="false"><button class="btn pri" type="submit"><?= t('m.d_send') ?></button></form>
    </div>
  </div>
</section>

<!-- 5. VISUAL STORYTELLING (sticky on large screens) -->
<section class="sec story" id="story" aria-labelledby="sy-h" data-step="0">
  <div class="stick">
    <div class="wrap story-in">
      <div>
        <div class="head"><p class="eyebrow" data-r><?= t('m.s_eyebrow') ?></p><h2 class="h2 split" id="sy-h" data-split style="margin-top:1.2rem"><?= t('m.s_h2a') ?> <span class="grad"><?= t('m.s_h2b') ?></span></h2></div>
        <div class="steps">
          <article class="step"><span class="no"><?= t('m.s1n') ?></span><h3><?= t('m.s1t') ?></h3><p><?= t('m.s1p') ?></p></article>
          <article class="step"><span class="no"><?= t('m.s2n') ?></span><h3><?= t('m.s2t') ?></h3><p><?= t('m.s2p') ?></p></article>
          <article class="step"><span class="no"><?= t('m.s3n') ?></span><h3><?= t('m.s3t') ?></h3><p><?= t('m.s3p') ?></p></article>
          <article class="step"><span class="no"><?= t('m.s4n') ?></span><h3><?= t('m.s4t') ?></h3><p><?= t('m.s4p') ?></p></article>
        </div>
      </div>
      <div class="rings" aria-hidden="true">
        <svg viewBox="0 0 400 400" fill="none"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#7C5CFF"/><stop offset="1" stop-color="#2DA8FF"/></linearGradient></defs>
          <circle class="rg" id="r1" cx="200" cy="200" r="190" stroke="rgba(244,241,234,.14)" stroke-dasharray="2 10"/>
          <circle class="rg" id="r2" cx="200" cy="200" r="145" stroke="rgba(244,241,234,.22)"/>
          <circle class="rg" id="r3" cx="200" cy="200" r="100" stroke="url(#g)" stroke-width="2" stroke-dasharray="120 510"/>
          <circle class="rg" id="r4" cx="200" cy="200" r="55" fill="url(#g)" opacity=".9"/>
          <circle id="r5" cx="200" cy="10" r="7" fill="#F4F1EA"/>
        </svg>
      </div>
    </div>
    <div class="dots" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
  </div>
</section>

<!-- 6. CAPABILITIES -->
<section class="sec caps" id="capabilities" aria-labelledby="cp-h">
  <div class="wrap caps-grid">
    <div class="head">
      <p class="eyebrow" data-r><?= t('m.c_eyebrow') ?></p>
      <h2 class="h2 split" id="cp-h" data-split style="margin:1.2rem 0 1rem"><?= t('m.c_h2a') ?> <span class="grad"><?= t('m.c_h2b') ?></span></h2>
      <p class="mu" data-r style="max-width:24rem"><?= t('m.c_intro') ?></p>
    </div>
    <div class="acc" data-r>
<?php $CAPS = [['c1t', 'c1p', ['Python', 'discord.py', 'Discord API']], ['c2t', 'c2p', ['Groq', 'Gemini', 'REST APIs']], ['c3t', 'c3p', ['HTML5', 'CSS3', 'JavaScript', 'PHP']], ['c4t', 'c4p', ['Python', 'Webhooks', 'Scheduling']]];
foreach ($CAPS as $i => $c) { ?>
      <div class="acc-i"><button class="acc-b" type="button" aria-expanded="<?= $i === 0 ? 'true' : 'false' ?>" aria-controls="a<?= $i ?>" id="b<?= $i ?>"><span><em>0<?= $i + 1 ?></em><?= t('m.' . $c[0]) ?></span><span class="pm" aria-hidden="true"></span></button><div class="acc-p" id="a<?= $i ?>" role="region" aria-labelledby="b<?= $i ?>"><div><p><?= t('m.' . $c[1]) ?></p><div class="tags"><?php foreach ($c[2] as $tg) { echo '<span>' . e($tg) . '</span>'; } ?></div></div></div></div>
<?php } ?>
    </div>
  </div>
</section>

<!-- 7. SELECTED WORK -->
<section class="sec work" id="work" aria-labelledby="wk-h">
  <div class="wrap">
    <p class="eyebrow" data-r><?= t('m.w_eyebrow') ?></p>
    <h2 class="h2 split" id="wk-h" data-split style="margin-top:1.2rem"><?= t('m.w_h2a') ?> <span class="grad"><?= t('m.w_h2b') ?></span></h2>
    <div class="cards">
<?php foreach ($CARDS as $i => $c) { $slug = $c[0]; $P = $PROJECTS[$slug] ?? null; if (!$P) continue; $media = m_media_html($slug, $P['title']); ?>
      <a class="card tilt<?= $media ? ' has-shot' : '' ?>" data-cursor="<?= e(m_plain('m.pv_hint')) ?>" style="--h:<?= (int) $c[3] ?>" href="motion-project.php?p=<?= e($slug) ?>" data-r data-d="<?= ($i % 3) * 0.08 ?>s"
         data-pv data-title="<?= e($P['title']) ?>" data-kind="<?= e(m_plain('m.' . $c[1])) ?>" data-sum="<?= e(m_plain('m.' . $c[2])) ?>" data-tags="<?= e(implode(' / ', $P['tags'])) ?>">
        <?php if ($media) { echo '<div class="thumb">' . $media . '</div>'; } else { ?><span class="art2" aria-hidden="true"></span><?php } ?>
        <div class="k"><span>0<?= $i + 1 ?></span><span><?= t('m.' . $c[1]) ?></span></div>
        <div><h3><?= e($P['title']) ?></h3><p><?= t('m.' . $c[2]) ?></p><div class="go"><?= t('m.case') ?> <?= M_ARROW ?></div></div>
      </a>
<?php } ?>
    </div>
  </div>
</section>

<!-- 7b. RIGHT NOW -->
<section class="sec nowx" id="now" aria-labelledby="nw-h">
  <div class="wrap">
    <p class="eyebrow" data-r><?= t('m.n_eyebrow') ?></p>
    <h2 class="h2 split" id="nw-h" data-split style="margin:1.2rem 0 clamp(2rem,5vw,3.5rem)"><?= t('m.n_h2a') ?> <span class="grad"><?= t('m.n_h2b') ?></span></h2>
    <ul class="nowg">
<?php foreach ([1, 2, 3, 4, 5, 6] as $i) { ?>
      <li class="nc" data-r data-d="<?= (($i - 1) % 3) * 0.08 ?>s"><span class="live-dot" aria-hidden="true"></span><h3><?= t('m.n' . $i . 't') ?></h3><p><?= t('m.n' . $i . 'p') ?></p></li>
<?php } ?>
    </ul>
  </div>
</section>

<?php if ($TESTIMONIALS) { ?>
<!-- 7c. KIND WORDS (only shown when real quotes exist in lib.php) -->
<section class="sec quotesx" id="quotes" aria-labelledby="qt-h">
  <div class="wrap">
    <p class="eyebrow" data-r><?= t('m.q_eyebrow') ?></p>
    <h2 class="vh" id="qt-h"><?= t('m.q_eyebrow') ?></h2>
    <div class="qs" data-qs>
<?php foreach ($TESTIMONIALS as $i => $q) { ?>
      <figure class="q<?= $i === 0 ? ' on' : '' ?>"><blockquote><p><?= e($q['quote'] ?? '') ?></p></blockquote><figcaption><b><?= e($q['name'] ?? '') ?></b><?= !empty($q['role']) ? ' &mdash; ' . e($q['role']) : '' ?></figcaption></figure>
<?php } ?>
      <div class="qn" role="group" aria-label="Quotes"><button type="button" class="qp" aria-label="<?= e(m_plain('m.j_prev')) ?>">&#8592;</button><span class="qc" aria-hidden="true"></span><button type="button" class="qx" aria-label="<?= e(m_plain('m.j_next')) ?>">&#8594;</button></div>
    </div>
  </div>
</section>
<?php } ?>

<!-- 8. CONTACT -->
<section class="sec contact" id="contact" aria-labelledby="ct-h">
  <div class="wrap">
    <p class="eyebrow" data-r><?= t('m.ct_eyebrow') ?></p>
    <h2 id="ct-h" class="split" data-split><?= t('m.ct_h2') ?></h2>
    <div class="cta" data-r>
      <a class="btn pri mag" href="mailto:<?= obf(CONTACT_TO) ?>"><?= t('m.ct_mail') ?> <?= M_ARROW ?></a>
      <button class="btn mag" type="button" id="cform-open" aria-expanded="<?= ($sent || $err) ? 'true' : 'false' ?>" aria-controls="cform"><?= t('m.ct_form') ?></button>
    </div>

    <div class="cform" id="cform"<?= ($sent || $err) ? '' : ' hidden' ?>>
      <div class="cf-note ok" role="status"<?= $sent ? '' : ' hidden' ?>><?= t('m.ct_ok') ?></div>
      <div class="cf-note bad" role="alert"<?= $err ? '' : ' hidden' ?>><?= t('m.ct_fail') ?></div>
      <form class="cf" method="post" action="motion-contact.php" id="cf">
        <div class="cfr">
          <label class="cff"><span><?= t('f.name') ?></span><input type="text" name="name" required maxlength="100" autocomplete="name"></label>
          <label class="cff"><span><?= t('f.email') ?></span><input type="email" name="email" required maxlength="150" autocomplete="email"></label>
        </div>
        <label class="cff"><span><?= t('f.topic') ?></span><select name="topic"><?php foreach ($TOPIC_EN as $k => $en) { echo '<option value="' . e($k) . '">' . e(strip_tags(t('tp.' . $k))) . '</option>'; } ?></select></label>
        <label class="cff"><span><?= t('f.msg') ?></span><textarea name="message" required minlength="5" maxlength="5000" rows="4"></textarea></label>
        <input type="hidden" name="tk" value="<?= e(form_token()) ?>">
        <div class="hp" aria-hidden="true"><label>Leave this field empty<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
        <div class="cfa"><button class="btn pri" type="submit"><span class="cf-l"><?= t('f.send') ?></span></button><span class="mu cf-h"><?= t('m.ct_hint') ?></span></div>
      </form>
    </div>

    <div class="links" data-r>
      <a class="ul" href="https://github.com/moinhamza" target="_blank" rel="noopener">GitHub</a>
      <a class="ul" href="https://www.instagram.com/epichamzax" target="_blank" rel="noopener">Instagram</a>
      <button class="ul" type="button" data-copy="Dino"><?= t('m.ct_disc') ?></button>
      <a class="ul" href="contact.vcf" download><?= t('m.ct_vcf') ?></a>
      <button class="ul cv-open" type="button"><?= t('m.ct_cv') ?></button>
      <a class="ul" href="cv.pdf" download><?= t('m.ct_dl') ?></a>
    </div>
  </div>
</section>
</main>

<!-- 9. FOOTER -->
<footer>
  <p class="mark" aria-hidden="true" data-mark>Hamza</p>
  <div class="wrap">
    <p>&copy; <span id="yr">2026</span> Mohammed Moin Hamza &mdash; Dino / n6ble</p>
    <div class="r"><a class="ul" href="index.php?e=c" data-leave>&#8617; <?= t('m.classic') ?> <?= t('m.site') ?></a><a class="ul" href="#top"><?= t('m.f_top') ?></a></div>
  </div>
</footer>

<nav class="rail" aria-label="<?= e(m_plain('m.rail_label')) ?>"><a href="#top"><span><?= t('m.intro') ?></span><i></i></a><a href="#showcase"><span>Dino Bot</span><i></i></a><a href="#features"><span><?= t('m.features') ?></span><i></i></a><a href="#demo"><span><?= t('m.demo') ?></span><i></i></a><a href="#story"><span><?= t('m.story') ?></span><i></i></a><a href="#capabilities"><span><?= t('m.cap') ?></span><i></i></a><a href="#work"><span><?= t('m.work') ?></span><i></i></a><a href="#now"><span><?= t('m.now') ?></span><i></i></a><a href="#contact"><span><?= t('m.contact') ?></span><i></i></a></nav>

<aside class="pvw" id="pvw" hidden aria-label="<?= e(m_plain('m.pv_hint')) ?>">
  <div class="pvw-box" role="dialog" aria-modal="true" tabindex="-1">
    <button class="pvw-x" type="button" aria-label="<?= e(m_plain('m.pv_close')) ?>">&times;</button>
    <p class="pvw-k eyebrow"></p><h2 class="pvw-t"></h2><p class="pvw-s"></p><p class="pvw-g"></p>
    <div class="cta"><a class="btn pri mag pvw-a" href="#" data-leave><?= t('m.pv_open') ?> <?= M_ARROW ?></a></div>
  </div>
</aside>

<?php m_chrome_bottom(); ?>
</body>
</html>
