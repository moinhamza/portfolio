<?php
/* ---------------------------------------------------------------------------
   lib.php — shared by index.php and project.php. Outputs nothing by itself.
   Everything here is plain PHP: no database, no cron, no outside services
   needed (all of that is restricted or unreliable on InfinityFree free hosting).
   --------------------------------------------------------------------------- */

const SITE_URL  = 'https://moinhamza.gt.tc';   // used for Open Graph tags; change if the domain changes
const STATS_URL = '';                          // optional: public JSON URL your bot updates (see README). '' = use stats.json only

/* ---------- language (EN/Japanese) — cookie + ?lang= link, works without JavaScript ---------- */
$L = 'en';
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ja'], true)) {
    $L = $_GET['lang'];
    if (!headers_sent()) {
        setcookie('lang', $L, ['expires' => time() + 31536000, 'path' => '/', 'samesite' => 'Lax']);
    }
} elseif (isset($_COOKIE['lang']) && in_array($_COOKIE['lang'], ['en', 'ja'], true)) {
    $L = $_COOKIE['lang'];
}

$I18N = [
  'en' => [
    'skip' => 'Skip to content', 'theme' => 'Theme', 'themes' => 'Choose a theme',
    'th.grunge' => 'Grunge', 'th.paper' => 'Paper', 'th.toxic' => 'Toxic', 'th.cyber' => 'Cyber',
    'th.ember' => 'Ember', 'th.ocean' => 'Ocean', 'th.sakura' => 'Sakura',
    'n.about' => 'About', 'n.skills' => 'Skills', 'n.services' => 'Services', 'n.projects' => 'Projects',
    'n.journey' => 'Journey', 'n.now' => 'Now', 'n.tools' => 'Tools', 'n.contact' => 'Contact', 'n.talk' => "Let's Talk",
    'status' => 'Currently building &amp; learning',
    'r1' => 'Developer', 'r2' => 'AI Enthusiast', 'r3' => 'Builder',
    'tagline' => 'Turning curiosity into code, ideas into projects, and projects into experiences.',
    'viewwork' => 'View My Work', 'contactme' => 'Contact Me', 'cv' => 'Download CV',
    's1' => 'Live Websites', 's2' => 'Discord Bots Built', 's3' => 'Languages', 's4' => 'Projects', 's5' => 'Lines of Python',
    'h.about' => 'The story behind <mark>the code</mark>', 'hp.about' => 'About me',
    'h.skills' => 'What I <mark>work with</mark>', 'hp.skills' => 'Tech stack &mdash; languages, tools, and concepts I use to build real projects.',
    'h.services' => 'Services &amp; <mark>capabilities</mark>', 'hp.services' => 'What I build &mdash; real, functional things from scratch.',
    'h.projects' => 'My <mark>projects</mark>', 'hp.projects' => "What I've built &mdash; bots, web apps, and AI tools.",
    'h.journey' => 'How it <mark>started</mark>', 'hp.journey' => 'My story &mdash; from Discord communities to shipping real projects.',
    'h.learning' => 'Always <mark>learning</mark>', 'hp.learning' => 'Currently &mdash; active areas of exploration and building.',
    'h.now' => "What I'm <mark>doing now</mark>", 'hp.now' => 'Right now &mdash; just real, honest progress.',
    'h.tools' => 'Tools I <mark>use daily</mark>', 'hp.tools' => 'My setup &mdash; software and platforms that power my workflow.',
    'h.contact' => 'Have an idea worth <mark>building?</mark>', 'hp.contact' => "Get in touch &mdash; let's turn the idea into something real.",
    'live' => 'Live Project', 'livesite' => 'Live Website', 'details' => 'Details', 'github' => 'GitHub', 'viewgh' => 'View on GitHub',
    'botstats' => 'Dino Bot in numbers', 'servers' => 'Servers', 'users' => 'Users', 'uptime' => 'Uptime',
    'shipped' => 'What I shipped lately',
    'f.title' => 'Or send a direct message', 'f.name' => 'Name', 'f.email' => 'Email', 'f.msg' => 'Message',
    'f.ph.name' => 'Your name', 'f.ph.msg' => 'Tell me about the idea...', 'f.send' => 'Send Message',
    'f.hint' => 'Your message is emailed to me directly. Nothing is stored on this site.',
    'f.ok' => 'Message sent', 'f.okp' => "Thanks for reaching out. I'll get back to you soon.", 'f.again' => 'Send another message',
    'f.bad' => "Couldn't send your message", 'f.badp' => "The mail server didn't accept it. Please try again, or email me directly at",
    'e.name' => 'Please enter your name (up to 100 characters).', 'e.email' => 'Please enter a valid email address.',
    'e.msg' => 'Please write a message between 5 and 5000 characters.',
    'top' => 'Back to top', 'sub' => 'Built with curiosity and code.',
    'p.back' => 'All projects', 'p.what' => 'What it does', 'p.stack' => 'Stack', 'p.links' => 'Links', 'p.shots' => 'Screenshots',
    'p.next' => 'Next project', 'p.nf' => 'Project not found',
    'pf.label' => 'Filter projects', 'pf.all' => 'All', 'chaos' => 'Make it worse',
    'e.token' => 'Please reload the page and send your message again.',
    'e.rate' => 'Too many messages in a short time. Please try again in a few minutes.',
    'motion' => 'Motion Edition', 'share' => 'Share', 'vcard' => 'Save contact', 'updated' => 'Last updated', 'quotes' => 'What people say',
    'f.topic' => 'Topic', 'tp.project' => 'Project idea', 'tp.bot' => 'Discord bot', 'tp.collab' => 'Collab', 'tp.hi' => 'Just saying hi',
    'ck.live' => 'Live', 'ck.label' => 'Your local time', 'ck.sr' => 'Local time', 'ck.fmt' => 'Switch between 12-hour and 24-hour time', 'pin.hint' => 'Keep scrolling',
  ],
  'ja' => [
    'skip' => '本文へスキップ', 'theme' => 'テーマ', 'themes' => 'テーマを選ぶ',
    'th.grunge' => 'グランジ', 'th.paper' => 'ペーパー', 'th.toxic' => 'トキシック', 'th.cyber' => 'サイバー',
    'th.ember' => 'エンバー', 'th.ocean' => 'オーシャン', 'th.sakura' => '桜',
    'n.about' => '自己紹介', 'n.skills' => 'スキル', 'n.services' => 'サービス', 'n.projects' => 'プロジェクト',
    'n.journey' => '歩み', 'n.now' => '現在', 'n.tools' => 'ツール', 'n.contact' => '連絡先', 'n.talk' => 'お問い合わせ',
    'status' => '現在、開発と学習の真っ最中',
    'r1' => 'デベロッパー', 'r2' => 'AI愛好家', 'r3' => 'ビルダー',
    'tagline' => '好奇心をコードに、アイデアをプロジェクトに、プロジェクトを体験に変える。',
    'viewwork' => '実績を見る', 'contactme' => '連絡する', 'cv' => 'CVをダウンロード',
    's1' => '公開サイト', 's2' => '制作したDiscordボット', 's3' => '言語', 's4' => 'プロジェクト', 's5' => 'Pythonのコード行数',
    'h.about' => 'コードの<mark>裏側の物語</mark>', 'hp.about' => '自己紹介',
    'h.skills' => '使っている<mark>技術</mark>', 'hp.skills' => '技術スタック &mdash; 実際のプロジェクトで使う言語、ツール、概念。',
    'h.services' => 'サービス＆<mark>できること</mark>', 'hp.services' => '作れるもの &mdash; ゼロから作る、本当に動くもの。',
    'h.projects' => '私の<mark>プロジェクト</mark>', 'hp.projects' => '作ってきたもの &mdash; ボット、Webアプリ、AIツール。',
    'h.journey' => 'すべての<mark>始まり</mark>', 'hp.journey' => '私の物語 &mdash; Discordコミュニティから、実際のプロジェクトのリリースまで。',
    'h.learning' => '常に<mark>学び続ける</mark>', 'hp.learning' => '現在 &mdash; 探求し、開発している分野。',
    'h.now' => '<mark>今</mark>やっていること', 'hp.now' => 'いま &mdash; 誠実で、本物の進歩だけ。',
    'h.tools' => '毎日<mark>使うツール</mark>', 'hp.tools' => '私の環境 &mdash; ワークフローを支えるソフトウェアとプラットフォーム。',
    'h.contact' => '形にしたい<mark>アイデア</mark>はありますか？', 'hp.contact' => 'お気軽にご連絡ください &mdash; そのアイデアを本物にしましょう。',
    'live' => '公開中のプロジェクト', 'livesite' => '公開サイト', 'details' => '詳細', 'github' => 'GitHub', 'viewgh' => 'GitHubで見る',
    'botstats' => 'Dino Botの数字', 'servers' => 'サーバー', 'users' => 'ユーザー', 'uptime' => '稼働率',
    'shipped' => '最近リリースしたもの',
    'f.title' => 'またはメッセージを直接送る', 'f.name' => 'お名前', 'f.email' => 'メール', 'f.msg' => 'メッセージ',
    'f.ph.name' => 'あなたのお名前', 'f.ph.msg' => 'アイデアを聞かせてください...', 'f.send' => 'メッセージを送信',
    'f.hint' => 'メッセージは私のメールに直接届きます。このサイトには何も保存されません。',
    'f.ok' => '送信しました', 'f.okp' => 'ご連絡ありがとうございます。近いうちに返信します。', 'f.again' => 'もう一通送る',
    'f.bad' => '送信できませんでした', 'f.badp' => 'メールサーバーに受け付けられませんでした。もう一度お試しいただくか、こちらへ直接メールしてください：',
    'e.name' => 'お名前を入力してください（100文字以内）。', 'e.email' => '有効なメールアドレスを入力してください。',
    'e.msg' => 'メッセージは5〜5000文字で入力してください。',
    'top' => 'ページの先頭へ', 'sub' => '好奇心とコードで作りました。',
    'p.back' => 'すべてのプロジェクト', 'p.what' => '何をするのか', 'p.stack' => '技術スタック', 'p.links' => 'リンク', 'p.shots' => 'スクリーンショット',
    'p.next' => '次のプロジェクト', 'p.nf' => 'プロジェクトが見つかりません',
    'pf.label' => 'プロジェクトを絞り込む', 'pf.all' => 'すべて', 'chaos' => 'もっと壊す',
    'e.token' => 'ページを再読み込みして、もう一度送信してください。',
    'e.rate' => '短時間にメッセージが多すぎます。数分後にもう一度お試しください。',
    'motion' => 'モーション版', 'share' => 'シェア', 'vcard' => '連絡先を保存', 'updated' => '最終更新', 'quotes' => 'みんなの声',
    'f.topic' => 'トピック', 'tp.project' => 'プロジェクトの相談', 'tp.bot' => 'Discordボット', 'tp.collab' => 'コラボ', 'tp.hi' => 'ご挨拶',
    'ck.live' => 'ライブ', 'ck.label' => 'あなたの現地時刻', 'ck.sr' => '現地時刻', 'ck.fmt' => '12時間表示と24時間表示を切り替え', 'pin.hint' => 'そのままスクロール',
  ],
];

/* Japanese long copy: swap exact English strings for the ones in i18n-ja.php (output buffer, no JS) */
if ($L === 'ja' && is_file(__DIR__ . '/i18n-ja.php')) {
    $HI = require __DIR__ . '/i18n-ja.php';
    ob_start(function ($html) use ($HI) {
        $m = [];
        foreach ($HI as $k => $v) {
            $m[$k] = $v;
            if (strpos($k, '<') === false && strpos($k, '&') === false) {   // text that PHP prints through htmlspecialchars()
                $m[htmlspecialchars($k, ENT_QUOTES, 'UTF-8')] = htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
            }
        }
        return strtr($html, $m);
    });
}

/* t(): trusted static HTML from the table above (never put user input in it) */
function t($k) { global $L, $I18N; return $I18N[$L][$k] ?? $I18N['en'][$k] ?? $k; }

/* URL for the other language, keeping the current page and query */
function lang_url() {
    global $L;
    $q = $_GET; unset($q['lang']);
    $q['lang'] = $L === 'ja' ? 'en' : 'ja';
    return htmlspecialchars(basename(parse_url($_SERVER['REQUEST_URI'] ?? 'index.php', PHP_URL_PATH) ?: 'index.php') . '?' . http_build_query($q), ENT_QUOTES, 'UTF-8');
}

/* ---------- projects (project.php?p=<slug>). Text is taken from the site's existing copy; edit freely. ---------- */
$PROJECTS = [
  'dino-bot' => [
    'title' => 'Dino Bot', 'kind' => 'Discord Bot', 'status' => 'Live',
    'summary' => 'Full-featured Discord bot with moderation, utility, AI chat, image tools, and server management. Built in Python, with a live website designed and built by me.',
    'points' => ['Moderation and server management', 'Utility commands and image tools', 'AI chat powered by Groq and Gemini', 'Cog-based discord.py architecture', 'Live PHP website at dino-bot.gt.tc'],
    'tags' => ['Python', 'discord.py', 'Groq AI', 'Gemini', 'PHP Website'],
    'links' => [['Live Website', 'https://dino-bot.gt.tc/?i=1'], ['GitHub', 'https://github.com/moinhamza']],
    'shots' => [],
  ],
  'loyal-bot' => [
    'title' => 'Loyal Bot', 'kind' => 'Discord Bot', 'status' => '',
    'summary' => 'Feature-rich multi-cog Discord bot with moderation, economy, leveling, music, and AI-powered chat.',
    'points' => ['Moderation tools', 'Economy and leveling systems', 'Music playback', 'AI-powered chat', 'Multi-cog structure'],
    'tags' => ['Python', 'discord.py', 'Groq AI'],
    'links' => [['GitHub', 'https://github.com/moinhamza']],
    'shots' => [],
  ],
  'portfolio' => [
    'title' => 'This Portfolio', 'kind' => 'Website', 'status' => 'Live',
    'summary' => 'Personal portfolio built from scratch. Grunge brutalist theme, CSS-first with a small script for motion and the live clock.',
    'points' => ['CSS-first design: page transitions, multi-theme switcher, project filter and a full no-script fallback', 'Scroll-driven motion: split-text reveals, pinned horizontal timeline, parallax, velocity-reactive marquee and tilt cards', 'Live digital clock with day and date, 12/24-hour toggle and a day-progress bar', 'PHP contact form with honeypot, signed timestamp and rate limiting', 'English / Japanese language switch via cookie', 'One PHP page per project, with the content kept in a single data file', 'Designed around free-hosting limits: few requests, no cron jobs, no outside calls that can hang the page', 'Command palette, keyboard shortcuts and a reading-progress bar on desktop', 'Mobile menu button, swipe between projects, install-as-app, text size and calm mode on phones'],
    'tags' => ['HTML', 'CSS3', 'PHP'],
    'links' => [['GitHub', 'https://github.com/moinhamza']],
    'shots' => [],
  ],
  'ai-chat' => [
    'title' => 'AI Chat Platform', 'kind' => 'Web App', 'status' => '',
    'summary' => 'ChatGPT-style interface powered by Groq LLMs. Multi-model, history, markdown rendering.',
    'points' => ['Multiple Groq models to choose from', 'Conversation history', 'Markdown rendering of replies'],
    'tags' => ['PHP', 'Groq API', 'JavaScript'],
    'links' => [['GitHub', 'https://github.com/moinhamza']],
    'shots' => [],
  ],
  'ai-tools' => [
    'title' => 'AI Web Tools', 'kind' => 'Web Tools', 'status' => '',
    'summary' => 'Collection of browser-based AI tools and experiments using LLM and vision APIs.',
    'points' => ['Browser-based tools', 'LLM and vision API experiments'],
    'tags' => ['JavaScript', 'Groq API', 'Python'],
    'links' => [['GitHub', 'https://github.com/moinhamza']],
    'shots' => [],
  ],
  'discord-automation' => [
    'title' => 'Discord Automation', 'kind' => 'Scripts', 'status' => '',
    'summary' => 'Python scripts for Discord automation — monitoring, scheduled notifications, and webhook pipelines.',
    'points' => ['Monitoring', 'Scheduled notifications', 'Webhook pipelines'],
    'tags' => ['Python', 'REST API', 'Webhooks'],
    'links' => [['GitHub', 'https://github.com/moinhamza']],
    'shots' => [],
  ],
];

/* ---------- "what I shipped lately" strip: newest first, edit this list by hand ---------- */
$CHANGELOG = [
  ['2026-10-14', 'Portfolio: mobile menu button, progress bar, swipe between projects, install-as-app, text size and calm mode'],
  ['2026-10-14', 'Portfolio: live digital clock, advanced scroll-motion engine, navigation fixes'],
  ['2026-10-14', 'Portfolio: Japanese translation and multi-theme switcher'],
  ['2026-10-13', 'Portfolio: project pages, light/dark toggle, EN/Japanese switch, bot stats, CV download'],
  ['2026-10-12', 'Portfolio: CSS-only scroll animations and page transitions, no-JS contact form'],
];

/* ---------- bot stats ----------
   1) Edit stats.json by hand (always works), and/or
   2) set STATS_URL above to a public JSON file your bot updates (GitHub raw/gist, etc.).
   Remote results are cached 10 min in stats-cache.json with a 2 s timeout, so a slow or blocked
   request never hangs the page. Anything missing is simply not shown. */
function bot_stats() {
    $s = ['servers' => null, 'users' => null, 'uptime' => null];
    $local = @json_decode((string) @file_get_contents(__DIR__ . '/stats.json'), true);
    if (is_array($local)) $s = array_merge($s, array_intersect_key($local, $s));

    if (STATS_URL !== '') {
        $cache = __DIR__ . '/stats-cache.json';
        $remote = null;
        if (is_file($cache) && (time() - (int) @filemtime($cache)) < 600) {
            $remote = @json_decode((string) @file_get_contents($cache), true);
        } else {
            $ctx = stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true, 'header' => "User-Agent: portfolio-stats\r\n"]]);
            $raw = @file_get_contents(STATS_URL, false, $ctx);
            $remote = is_string($raw) ? json_decode($raw, true) : null;
            if (is_array($remote)) @file_put_contents($cache, json_encode($remote), LOCK_EX);
            elseif (is_file($cache)) $remote = @json_decode((string) @file_get_contents($cache), true);   // stale beats nothing
        }
        if (is_array($remote)) $s = array_merge($s, array_intersect_key($remote, $s));
    }

    $out = [];
    if (is_numeric($s['servers'])) $out['servers'] = number_format((int) $s['servers']);
    if (is_numeric($s['users']))   $out['users']   = number_format((int) $s['users']);
    if (is_string($s['uptime']) && preg_match('/^\d{1,3}(\.\d{1,2})?%?$/', $s['uptime'])) $out['uptime'] = rtrim($s['uptime'], '%') . '%';
    return $out;
}


/* ---------- contact-form protection (no database, no JS) ----------
   1) A signed timestamp is embedded in the form: bots that post instantly, or replay an old form, are rejected.
   2) Per-visitor rate limit kept in tiny files under .rl/ (max 3 messages/hour, 20 s apart), so spam can't burn
      through InfinityFree's mail quota. Both fail open if the host won't let PHP write files. */
function form_token() {
    $ts = (string) time();
    return $ts . '.' . hash_hmac('sha256', $ts, hash('sha256', __DIR__ . CONTACT_TO . MAIL_FROM));
}
function token_ok($tk) {
    $p = explode('.', (string) $tk, 2);
    if (count($p) !== 2 || !ctype_digit($p[0])) return false;
    if (!hash_equals(hash_hmac('sha256', $p[0], hash('sha256', __DIR__ . CONTACT_TO . MAIL_FROM)), $p[1])) return false;
    $age = time() - (int) $p[0];
    return $age >= 3 && $age <= 7200;
}
function rl_file() {
    $dir = __DIR__ . '/.rl';
    if (!is_dir($dir) && !@mkdir($dir, 0755)) return null;
    if (!is_file($dir . '/.htaccess')) @file_put_contents($dir . '/.htaccess', "Order allow,deny\nDeny from all\n");
    $who = ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '');
    return $dir . '/' . md5($who) . '.json';
}
function rl_hits($f) {
    $d = is_file($f) ? json_decode((string) @file_get_contents($f), true) : [];
    $now = time();
    return is_array($d) ? array_values(array_filter($d, function ($t) use ($now) { return is_int($t) && $now - $t < 3600; })) : [];
}
function rate_limited() {
    $f = rl_file(); if (!$f) return false;
    $h = rl_hits($f);
    return count($h) >= 3 || ($h && time() - end($h) < 20);
}
function rate_record() {
    $f = rl_file(); if (!$f) return;
    $h = rl_hits($f); $h[] = time();
    @file_put_contents($f, json_encode($h), LOCK_EX);
    if (mt_rand(1, 10) === 1) {   // tidy: drop visitor files older than a day
        foreach ((array) @glob(dirname($f) . '/*.json') as $x) { if (time() - (int) @filemtime($x) > 86400) @unlink($x); }
    }
}

/* contact topics: key => English label used in the email subject (the visible label comes from t('tp.<key>')) */
$TOPIC_EN = ['project' => 'Project idea', 'bot' => 'Discord bot', 'collab' => 'Collab', 'hi' => 'Just saying hi'];

/* newest modified date of the site's own files, shown in the footer (so it never goes stale by hand) */
function last_updated() {
    $t = 0;
    foreach (['index.php', 'lib.php', 'style.css', 'fx.js', 'i18n-ja.php'] as $f) { $t = max($t, (int) @filemtime(__DIR__ . '/' . $f)); }
    return $t ? gmdate('Y-m-d', $t) : '';
}

/* ---------- testimonials: add REAL quotes only. The section stays hidden while this list is empty. ----------
   Format: ['quote' => 'What they said', 'name' => 'Their name', 'role' => 'Who they are (optional)'] */
$TESTIMONIALS = [];

/* email as numeric HTML entities: readable by browsers, harder for simple scrapers (works in text and in href) */
function obf($s) {
    $o = '';
    foreach (str_split((string) $s) as $ch) { $o .= '&#' . ord($ch) . ';'; }
    return $o;
}

/* ---------- colour themes ----------
   id => [swatch background, swatch accent]. The colours themselves live in style.css (search "THEMES").
   To add a theme: add an entry here, a 'th.<id>' label in both language tables above, and a block in style.css. */
$THEMES = [
  'grunge' => ['#0A0A0A', '#FF3030'],
  'paper'  => ['#EAE5D9', '#FF3030'],
  'toxic'  => ['#050B06', '#39FF14'],
  'cyber'  => ['#0C0618', '#FF2BD6'],
  'ember'  => ['#140A04', '#FF9A1F'],
  'ocean'  => ['#04121C', '#22D3FF'],
  'sakura' => ['#FCEBEF', '#E0194F'],
];
/* remembered theme: saved by the optional script below; the server renders the matching radio as checked (no flash).
   Older cookie values 'dark' / 'light' are still understood. */
$THEME = (string) ($_COOKIE['theme'] ?? '');
if ($THEME === 'light') $THEME = 'paper';
if (!isset($THEMES[$THEME])) $THEME = 'grunge';

/* theme picker markup, shared by index.php and project.php (static HTML, labels come from the language tables) */
function theme_picker() {
    global $THEMES, $THEME;
    $e = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); };
    $o = '<input type="checkbox" id="th-menu" class="vh" aria-label="' . $e(t('themes')) . '">' . "\n";
    $o .= '<label class="th-backdrop" for="th-menu" aria-hidden="true"></label>' . "\n";
    $o .= '<div class="th-panel" role="radiogroup" aria-label="' . $e(t('themes')) . '"><p class="th-title">' . t('themes') . '</p><div class="th-list">';
    foreach ($THEMES as $id => $c) {
        $o .= '<label class="th-opt"><input type="radio" class="vh" name="theme" id="th-' . $id . '" value="' . $id . '"' . ($id === $THEME ? ' checked' : '') . '>'
            . '<span class="th-sw" style="--a:' . $c[0] . ';--b:' . $c[1] . '" aria-hidden="true"></span><span class="th-name">' . t('th.' . $id) . '</span></label>';
    }
    return $o . '</div></div>';
}

/* small inline script (runs in <head>, before first paint): marks the page as html.js (and html.fx unless the visitor prefers
   reduced motion), hides the nav while scrolling down and remembers the chosen colour theme. Then loads fx.js (clock + motion).
   The site works fully without any of it. */
function site_js() {
    return '<script>
(function(){var h=document.documentElement,y=0,t=false;
h.classList.add("js");
try{var ls=localStorage,tx=ls.getItem("txt"),q=location.search;
if(/[?&]e=c(&|$)/.test(q)){ls.setItem("edition","classic")}
else if(ls.getItem("edition")==="motion"&&!/[?&](e|lang|sent)=/.test(q)&&!location.hash&&/(^|\/)(index\.php)?$/.test(location.pathname)&&(!document.referrer||document.referrer.indexOf(location.host)<0)){location.replace("motion.php");}
if(tx==="1"||tx==="2")h.classList.add("txt-"+tx);
if(!matchMedia("(prefers-reduced-motion:reduce)").matches&&ls.getItem("calm")!=="1")h.classList.add("fx")}catch(e){try{if(!matchMedia("(prefers-reduced-motion:reduce)").matches)h.classList.add("fx")}catch(e2){}}
addEventListener("scroll",function(){if(t)return;t=true;requestAnimationFrame(function(){
var c=window.pageYOffset||0;if(c>y+8&&c>240)h.classList.add("nav-hide");else if(c<y-8||c<240)h.classList.remove("nav-hide");y=c;t=false})},{passive:true});
addEventListener("change",function(e){if(e.target&&e.target.name==="theme"){document.cookie="theme="+e.target.value+";path=/;max-age=31536000;samesite=lax"}});})();
</script><script src="fx.js?v=18" defer></script>';
}
